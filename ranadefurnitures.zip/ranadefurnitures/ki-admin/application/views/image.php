<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Image extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('image_model');
	}
	
	 public function add()
	{
		
		 		$file_array=array();
				
				$count=count($_FILES['fileimg']['size']);
				foreach($_FILES as $key=>$value)
				for($i=0;$i<=$count-1;$i++)
				{
					$_FILES['fileimg']['name']=$value['name'][$i];
					$_FILES['fileimg']['type']=$value['type'][$i];
					$_FILES['fileimg']['tmp_name']=$value['tmp_name'][$i];
					$_FILES['fileimg']['error']=$value['error'][$i];
					$_FILES['fileimg']['size']=$value['size'][$i];
				
					$config['upload_path'] = '../image/product/';
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width']  = '10240';
					$config['max_height']  = '7680';
	
				$this->load->library('upload',$config);
				$r = $this->upload->do_upload('fileimg');
				if($r)
				{
					$data=$this->upload->data();
					$file_array[]=$data-'file_name'];
					
				
				}
				else
				{
						$data['error']=$this->upload->display_errors();
						
				}
				
			}

		
	
	
}
