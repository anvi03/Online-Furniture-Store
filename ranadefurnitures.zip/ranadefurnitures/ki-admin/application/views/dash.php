<style>
.number{
	float: left;
	width:25px;
	height:20px;
	margin-top:10px;
	margin-left:10px;
	border-radius:30px;
	-webkit-border-radius:30px;
	-moz-border-radius:30px;
	-o-border-radius:30px;
	background:#35404f;
	display: inline-block;
	text-align: center;
}
.number figure {
	text-align: center;
	padding:15px 0;
}
.number figure span {
	font-size:12px;
	line-height:25px;
	color:#fff;
	display: block;
	margin:-18px;
	font-weight:bolder;
}
</style>
<div id="container">
	<div class="shell">	
		
		<!-- Small Nav -->
		<div class="small-nav">
			<?php echo anchor('dashboard','Dashboard');?>
			
		</div>
			
		<?php $this->session->set_userdata('last_login',$res[0]->last_login);?>
				
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
			<div id="content_dashborad">
				<div id="content-dash_borad">
				
				<div class="num-heading">
				<div style="color:#35404f; margin-left:10px; float:left; padding-top:10px; font-family:Arial, Helvetica, sans-serif; font-size:15px;">
				<strong>
				New Contact:
				</strong>
				

				</div>
				<div class="number">
				
				<span style="color:#FFFFFF;font-weight:bold;"><?php echo $curr_contact;?></span>
				
				
				</div>
				
				<div style="margin-right:20px; float:left;padding-top:30px;margin-left:-139px;">
				
					<table  style="margin-left:10px; margin-top:10px; text-align:center; width:150px; border:1px solid #333333;"cellspacing="0" cellpadding="0" >
                        
							<tr style="background:#4aaaa5; color:#fff; border:1px solid #333333; font-size:13px; margin-bottom:10px; border:#333333; height:25px;">
							
                                
								<th>Name</th>
								<th>Subject</th>
								
							</tr>
                
                <?php 
								 foreach ($contact_obj as $contact_data)
								{
								$user_id = $contact_data->contact_id; ?>
							<tr style="border:1px solid #333333;">
								
                                
								<td  style="border:1px solid #333333; padding-top:10px; padding-bottom:10px; padding-left:10px; padding-right:10px;"><?php echo $contact_data->contact_name; ?></td>
                                 <td style="border:1px solid #333333; padding-top:10px; padding-bottom:10px; padding-left:10px; padding-right:10px;">
									
									<?php  echo $contact_data->subject;?>
                                    
                                                             
                                 </td>
                                 
                                         
                   
							</tr>
                            <?php }
							
							 ?>
                             
								</table>		
                 </div>
				</div>				
				
				<br  />
				<br  />
					
								
				<div class="num-heading">
				<div style="color:#35404f; margin-left:10px; float:left; padding-top:10px; font-family:Arial, Helvetica, sans-serif; font-size:15px;">
				<strong>
				New Users:
				</strong>
				</div>
				<div class="number">
				
				<span style="color:#FFFFFF;font-weight:bold;">
				<?php echo $curr_user;?></span>
				</div>
				
				
					<div style="margin-right:20px; float:left;padding-top:30px;margin-left:-139px;">
						<table  style="margin-left:10px; margin-top:10px; text-align:center; width:150px; float:left; border:1px solid #333333;"cellspacing="0" cellpadding="0" >
                        
							<tr style="background:#4aaaa5; color:#fff; border:1px solid #333333; font-size:13px; margin-bottom:10px; border:#333333; height:25px;">
							
                                
								<th colspan="2">Name</th>
								
								
							</tr>
                
                <?php 
								 foreach ($user_obj as $user_data)
								{
								$user_id = $user_data->id; ?>
							<tr style="border:1px solid #333333;">
								
                                
								<td  style="border:1px solid #333333; padding-top:10px; padding-bottom:10px; padding-left:10px; padding-right:10px;"><?php echo $user_data->firstname; ?>
                                 
									
									<?php  echo $user_data->lastname;?>
                                    
                                                             
                                 </td>
                                 
                                         
                   
							</tr>
                            <?php }
							
							 ?>
                             
								</table>
                                </div>
								
				</div>				
				<div class="num-heading">
				<div style="color:#35404f; margin-left:10px; float:left; padding-top:10px; font-family:Arial, Helvetica, sans-serif; font-size:15px;">
				<strong>
				New order:
				</strong>
				</div>
				<div class="number">
				
				<span style="color:#FFFFFF;font-weight:bold;">
				<?php echo $curr_order;?>
				</span></div>
				
					<div style="margin-right:20px; float:left;padding-top:30px;margin-left:-139px;">
						<table  style="margin-left:10px; margin-top:10px; text-align:center; width:150px; float:left; border:1px solid #333333;"cellspacing="0" cellpadding="0" >
                        
							<tr style="background:#4aaaa5; color:#fff; border:1px solid #333333; font-size:13px; margin-bottom:10px; border:#333333; height:25px;">
							
                                
								<th>Order NO.</th>
								<th>status</th>
								<th>Order On</th>
								<th>Total</th>
								
							</tr>
                
                <?php 
								 foreach ($order_obj as $order_data)
								{
								//$user_id = $order_data->id; ?>
							<tr style="border:1px solid #333333;">
								
                                
								<td  style="border:1px solid #333333; padding-top:10px; padding-bottom:10px; padding-left:10px; padding-right:10px;"><?php echo $order_data->order_no; ?>    
                                                             
                                 </td>
								 <td  style="border:1px solid #333333; padding-top:10px; padding-bottom:10px; padding-left:10px; padding-right:10px;"><?php echo $order_data->status; ?>    
                                                             
                                 </td>
								 <td  style="border:1px solid #333333; padding-top:10px; padding-bottom:10px; padding-left:10px; padding-right:10px;"><?php echo $order_data->ordered_on; ?>    
                                                             
                                 </td>
								 <td  style="border:1px solid #333333; padding-top:10px; padding-bottom:10px; padding-left:10px; padding-right:10px;"><?php echo $order_data->total; ?>    
                                                             
                                 </td>
                                 
                                         
                   
							</tr>
                            <?php }
							
							 ?>
                             
								</table>
                                </div>
				</div>
				</div>
				</div>
			</div>
			
			<div class="cl">&nbsp;</div>			
			</div>
		<!-- Main -->
		</div>
</div>