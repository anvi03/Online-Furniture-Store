<div id="container">
	<div class="shell">	
		
		<div class="small-nav" style="padding:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('categories','Categories');?>
			<span>&gt;</span>
			Edit Categories
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<?php 
				if($this->session->userdata('validation_errors'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('validation_errors');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('validation_errors');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php echo anchor('categories','<span>Back To Categories</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
					</div>
			
			</div>
			
			<div id="content">
						
				<div class="box">
					<div class="box-head">
						<h2>Edit Category</h2>
					</div>
					<?php echo form_open_multipart('categories/updatecategories');?>
						
						<div class="form">
							<?php foreach($categories as $categories_data): ?>
								<p>
									<span class="req">max 100 symbols</span>
									<?php echo form_label('Categories Name');?>
									<?php echo form_input('c_name',$categories_data->c_name,'placeholder="Categories Name" class="field size1"');?>
									<?php echo form_hidden('c_id',$categories_data->c_id); ?>
								</p>	
								<p>
									<img src="<?php echo base_url();?>../uploads/categories/<?php echo $categories_data->c_image;?>" alt="categories_image" style="width:100px;height:100px;"/>
									<?php echo form_label('Image'); ?>
									<?php echo form_upload('image',$categories_data->c_image,'class="field size1" style="width:600px"');?>
								</p>
								
								<p>
									<?php echo form_label('Status');?>
									<input type="radio" name="status" value="1" <?php if($categories_data->c_status == "1") echo "checked"; ?> />&nbsp;Enabled
									<input type="radio" name="status" value="0" <?php if($categories_data->c_status == "0") echo "checked"; ?> />&nbsp;Disabled
								</p>	
							<?php endforeach ?>
							
						</div>
					
						<div class="buttons">
							<?php echo form_submit('updatebtn','Update','class="button"');?>
						</div>
					<?php echo form_close();?>
				</div>
				
				
			</div>

			<div class="cl">&nbsp;</div>			
			</div>
		</div>
</div>