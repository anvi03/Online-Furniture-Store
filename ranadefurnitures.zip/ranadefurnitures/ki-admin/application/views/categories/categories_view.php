<div id="container">
	<div class="shell">	
		
		<!-- Small Nav -->
		<div class="small-nav">
		<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('categories','Categories');?>
			
		</div>
		
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-close" class="msg msg-ok" style="margin-bottom:20px">
				<p><strong><?php echo $this->session->userdata('msg');?></strong></p>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closediv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>
			
			
			<?php 
				if($this->session->userdata('err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px; color:#FF0000; background-color:#FDC9C1;height:35px; ">
				<strong><p><?php echo $this->session->userdata('err');?></p></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('err');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>

			
			<!-- Content -->
			
			<div id="content">
				
					<div class="box">
						<div class="box-head">
							<h2 class="left">Current Categories</h2>
							<?php /*?><div class="right">
								<?php echo form_open('categories/searchcategories'); ?>
								<?php echo form_label('search news');?>
								<?php echo form_input('srchterm',set_value('srchterm'),'class="field small-field"');?>
								<?php echo form_submit('srchbtn','Search','class="button"');?>
						</div><?php */?>
						</div>
	
						<div class="table">
						<?php echo form_open('categories/checkbox');?>
							<table width="100%" border="0" id="myTable" cellspacing="0" cellpadding="0">
								<thead>
									<tr>
										<th width="13"><input type="checkbox" name="chk" onclick='ToggleAll(this);'/></th>
										<th>Id</th>
										<th>Name<a></a></th>
										<th>Image</th>
										<th>Parent Category</th>
										<th>Status</th>
										<th>Date</th>
										<th width="110" class="ac">Content Control</th>
									</tr>
								</thead>
								<tbody>
								<?php 
									foreach($categories as $categories_list): ?>
										<tr>
											<td><input type="checkbox" name="chk[]" id="chk" value="<?php echo $categories_list->c_id;?>"/></td>	
												<td><h3><?php echo $id = $categories_list->c_id;?></h3></td>
												
											<td><h3><?php $name = $categories_list->c_name;
											echo anchor("product/view_categories/$id","$name");?></h3></td>
											<td><img src="<?php echo base_url();?>../uploads/categories/<?php echo $categories_list->c_image;?>" alt="categories_image" width="50px" height="50" /></td>
											<?php $parent_id = $categories_list->parent_id;?>
											<?php $c_id = $categories_list->c_id;?>
											<td>
												<?php if($parent_id == $c_id )
													  {
													  	echo $categories_list->c_name;
														
													  }
													  else
													  {
													  	echo $categories_list->parent_id;
													  };?>
											</td>
											
											<td><?php if($categories_list->c_status == 1) 
													{
														echo "Enabled";
													}
													else
													{
														echo "Disable";
													}?> </td>
											<td><?php $date = $categories_list->created;
												echo "$date";?></td>
											<?php
											$base = base_url();
											$id = $categories_list->c_id;
											?>
											<td><?php echo anchor("{$base}index.php/categories/editcategories/$id"," ",'class="ico edit"');?><?php echo anchor("{$base}index.php/categories/deletecategories/$id"," ",'class="ico del" onclick="return window.confirm(\'Are you Sure ?\');"');?><?php echo anchor("{$base}index.php/categories/categoryview/$id"," ",'class="ico view"');?></td>
										</tr>
								<?php
									endforeach;
												?>
								<?php //echo $this->pagination->create_links();?>
							</tbody>
							</table>
							
						
						
							<div class="pagging">
								<!--<div class="left">Showing 1-12 of 44</div>-->
								<div class="right">
								<p><?php //echo $links; ?></p>
								<!--<a href="#">Previous</a>
								<a href="#">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#">4</a>
								<a href="#">245</a>
								<span>...</span>
								<a href="#">Next</a>
								<a href="#">View all</a>-->
								</div>
								</div>
						
							</div>
					
						</div>
						
			
			</div>
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php echo anchor('categories/create','<span>Add Categories</span>','class="add-button"'); ?>
							<div class="cl">&nbsp;</div>
							
	
							<?php /*?><p class="select-all"><?php echo form_checkbox('selectall','class="checkbox"');?>&nbsp;<?php echo form_label('select all');?></p>
							<p><?php echo anchor('#','Delete Selected');?></p>
	<?php */?>
	
						   <p><input type="submit" class="button" value="Delete Selected" name="delete" onclick="return window.confirm('Are You Sure?');"/>
</p>
							<p>
							<input type="submit" class="button" value="Enable Selected" name="enable"/></p>
							<p>
                			<input type="submit" value="Disable Selected" name="disable"  class="button"/></p>
	</form>
								<!-- Sort -->
							<!--<div class="sort">
							<?php //echo form_label('Sort by');?><?php ?>
								<select class="field">
									<option value="">Title</option>
								</select>
								<!--<select class="field">
									<option value="">Date</option>
								</select>
								<select class="field">
									<option value="">Author</option>
								</select>
							</div>-->
							<!-- End Sort -->
	
						</div>
					</div>
			
			</div>
			
			
					<div class="cl">&nbsp;</div>			
			</div>
		<!-- Main -->
		</div>
</div>