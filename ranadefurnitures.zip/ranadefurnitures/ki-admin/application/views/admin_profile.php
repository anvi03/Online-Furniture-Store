<div id="container">
	<div class="shell">
		
		<div class="small-nav">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('profile','Setting');?>
			<span>&gt;</span>
			Update Profile
	</div>

		<?php /*?><div id="div-close" class="msg msg-ok">
			<!--<p><strong>Your file was uploaded succesifully!</strong></p>
			<a href="#" class="close" onclick="return closediv()">close</a>-->
		</div><?php */?>
	
		<br />
		
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<?php 
				if($this->session->userdata('validation_errors'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px;">
				<strong><?php echo $this->session->userdata('validation_errors');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('validation_errors');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px;">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>
			
			
			<?php 
				if($this->session->userdata('err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px; color:#FF0000; background-color:#FDC9C1;height:35px; ">
				<strong><p><?php echo $this->session->userdata('err');?></p></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('err');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>

			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-close" class="msg msg-ok" style="margin-bottom:20px">
				<p><strong><?php echo $this->session->userdata('msg');?></strong></p>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closediv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>

			
			<div id="content">
				
				<div class="box">
					<div class="box-head">
						<h2 class="left">Upadate Profile</h2>
						<div class="right">
							<!--<label>search articles</label>
							<input type="text" class="field small-field" />
							<input type="submit" class="button" value="search" />-->
						</div>
					</div>
			
					<div class="form">
						<!--<table width="100%" border="0" cellspacing="0" cellpadding="0">-->
							<?php /*?><span style="color:#009900;">
								<?php  echo $this->session->userdata('succ');
											$this->session->unset_userdata('succ');
								?>
								</span>
								<span style="color:#990000;">
<?php */?>								
								</span>
									<?php	
									$this->load->helper('html');
									echo form_open('profile/update_admin');
									?><p>
									<?php 
									echo form_label('Username','username');
									echo form_input('username',$admin_profile->username,'class="field size1" required');
									?></p>
									<p>
									<?php
									
									echo form_label('First Name','first_name');
									echo form_input('first_name',$admin_profile->first_name,' class="field size1" required');
									?></p>
									<p>
									<?php

									
									echo form_label('Last Name','last_name');
									echo form_input('last_name',$admin_profile->last_name,'class="field size1" required');
									?></p>
									<p>
									<?php

									
									echo form_label('Email','email');
									echo form_input('email',$admin_profile->email,' class="field size1" required');
									?></p>
		
									<?php

									
									?></div>
									<div class="buttons"><?php 

									echo form_submit('submit','update_profile','class="button"');
								
									echo form_close();
								?>
		

							<!--<table>
							<tr>
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
							<tr class="odd">
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
							<tr class="odd">
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
							<tr class="odd">
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
							<tr>
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
							<tr class="odd">
								<td><input type="checkbox" class="checkbox" /></td>
								<td><h3><a href="#">Lorem ipsum dolor sit amet, consectetur.</a></h3></td>
								<td>12.05.09</td>
								<td><a href="#">Administrator</a></td>
								<td><a href="#" class="ico del">Delete</a><a href="#" class="ico edit">Edit</a></td>
							</tr>
						</table>-->
						
						<!--<div class="pagging">
							<div class="left">Showing 1-12 of 44</div>
							<div class="right">
								<a href="#">Previous</a>
								<a href="#">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#">4</a>
								<a href="#">245</a>
								<span>...</span>
								<a href="#">Next</a>
								<a href="#">View all</a>
							</div>
						</div>-->
						
					</div>
					
				</div>
				
				<?php /*?><div class="box">
					<!--<div class="box-head">
						<h2>Add New Article</h2>
					</div> -->
					<!--<form action="" method="post">-->
						
						<div class="form">
								<!--<p>
									<span class="req">max 100 symbols</span>
									<label>Article Title <span>(Required Field)</span></label>
									<input type="text" class="field size1" />
								</p>	
								<p class="inline-field">
									<label>Date</label>
									<select class="field size2">
										<option value="">23</option>
									</select>
									<select class="field size3">
										<option value="">July</option>
									</select>
									<select class="field size3">
										<option value="">2009</option>
									</select>
								</p>
								
								<p>
									<span class="req">max 100 symbols</span>
									<label>Content <span>(Required Field)</span></label>
									<textarea class="field size1" rows="10" cols="30"></textarea>
								</p>	-->
							
						</div>
						
						<div class="buttons">
							<!--<input type="button" class="button" value="preview" />
							<input type="submit" class="button" value="submit" />-->
						</div>

					<!--</form>-->
				</div><?php */?>
			</div>

			<div id="sidebar">
				
				<div class="box">
					
					<div class="box-head">
						<h2>Management</h2>
					</div>
					<div class="box-content">
					<?php echo anchor('profile/changepwd','ChangePassword','class="ico edit"');					?>
					<br />
					<br />
							<?php echo anchor('dashboard','<span>Back To Dashboard</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>

					
					<?php /*?><div class="box-content">
						<!--<a href="#" class="add-button"><span>Add new Article</span></a>-->						<div class="cl">&nbsp;</div>
						
						<!--<p class="select-all"><input type="checkbox" class="checkbox" /><label>select all</label></p>-->
						<!--<p><a href="#">Delete Selected</a></p>
						
						<!-- Sort -->
						<!--<div class="sort">
							<label>Sort by</label>
							<select class="field">
								<option value="">Title</option>
							</select>
							<select class="field">
								<option value="">Date</option>
							</select>
							<select class="field">
								<option value="">Author</option>
							</select>
						</div>-->

					</div><?php */?>
				</div>
			
			</div>
			
			<div class="cl">&nbsp;</div>			
		</div>
	</div>
</div>