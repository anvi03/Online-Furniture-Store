<!--redactor-->
<link rel="stylesheet" href="<?php echo base_url('css/redactor.css'); ?>">
<script src="<?php echo base_url('js/redactor/jquery.js'); ?>"></script>
<script src="<?php echo base_url('js/redactor/jquery-1.9.0.min.js'); ?>"></script>
<script src="<?php echo base_url('js/redactor/redactor.js'); ?>"></script>
<script src="<?php echo base_url('js/redactor/redactor.min.js'); ?>"></script>
<!--redactor-->
<script type="text/javascript">
$(document).ready(function(){
    $('.redactor').redactor({
            minHeight: 200,
            imageUpload: '<?php echo base_url(); ?>index.php/redactor/upload_image',
            fileUpload: '<?php echo base_url(); ?>index.php/redactor/upload_file',
            imageGetJson: '<?php echo base_url(); ?>index.php/redactor/get_images',
            imageUploadErrorCallback: function(json)
            {
                alert(json.error);
            },
            fileUploadErrorCallback: function(json)
            {
                alert(json.error);
            }
      });
});
</script>
<div id="container">
	<div class="shell">	
		
		<div class="small-nav" style="padding:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('cms','CMS');?>
			<span>&gt;</span>
			Add Page
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			<?php 
				if($this->session->userdata('validation_errors'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('validation_errors');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('validation_errors');
				}
			?>
			
			<?php 
				if($this->session->userdata('imgerror'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('imgerror');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('imgerror');
				}
			?>
			
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php echo anchor('cms','<span>Back To CMS List</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
					</div>
			
			</div>
			
			<div id="content">
						
				<div class="box">
					<div class="box-head">
						<h2>Add Page</h2>
					</div>
					<?php echo form_open_multipart('cms/create');?>
						
						<div class="form">
								<p>
									<span class="req">max 100 symbols</span>
									<?php echo form_label('Title <span>(Required Field)</span>');?>
									<?php echo form_input('title',set_value('title'),'placeholder="title" class="field size1" required');?>
								</p>	

								<p>
									<span class="req">max 100 symbols</span>
									<?php echo form_label('Page URL Key <span>(Required Field)</span>');?>
									<?php echo form_input('page_url_key',set_value('page_url_key'),'placeholder="page_url_key" class="field size1" required');?>
								</p>	
								
								<p>
								<?php
									
									$options = array(
												  '1'  => 'Enabled',
												  '0'    => 'Disabled',
												);
								
									//$shirts_on_sale = array('small', 'large');
									
									echo form_label('Status <span>(Required Field)</span>');
									echo form_dropdown('status', $options,'','class="field size1" ');
									?>
								
								</p>

								<p>
									<?php echo form_label('content <span>(Required Field)</span>'); ?>
									<?php echo form_textarea('content',set_value('content'),'class="field size1 redactor"');?>
								</p>
								
								
								
								<p>
									<?php echo form_label('Meta Keywords <span>(Required Field)</span>'); ?>
									<?php echo form_textarea('metakeywords',set_value('metakeywords'),'class="field size1"required');?>
								</p>
								
								<p>
									<?php echo form_label('Meta Description <span>(Required Field)</span>'); ?>
									<?php echo form_textarea('metadesc',set_value('metadesc'),'class="field size1" required');?>
								</p>
								
								
								
								
																
								<!--<p class="inline-field">
									<label>Date</label>
									<select class="field size2">
										<option value="">23</option>
									</select>
									<select class="field size3">	
										<option value="">July</option>
									</select>
									<select class="field size3">
										<option value="">2009</option>
									</select>
								</p>	-->
							
						</div>
					
						<div class="buttons">
							<?php echo form_submit('addbtn','Add Page','class="button"');?>
						</div>
					<?php echo form_close();?>
				</div>
				
				
			</div>
			<div class="cl">&nbsp;</div>			
			</div>
		</div>
</div>