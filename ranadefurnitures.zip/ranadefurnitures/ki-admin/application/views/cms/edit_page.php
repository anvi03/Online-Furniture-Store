<!--redactor-->
<link rel="stylesheet" href="<?php echo base_url('css/redactor.css'); ?>">
<script src="<?php echo base_url('js/redactor/jquery.js'); ?>"></script>
<script src="<?php echo base_url('js/redactor/jquery-1.9.0.min.js'); ?>"></script>
<script src="<?php echo base_url('js/redactor/redactor.js'); ?>"></script>
<script src="<?php echo base_url('js/redactor/redactor.min.js'); ?>"></script>
<!--redactor-->
<script type="text/javascript">
$(document).ready(function(){
    $('.redactor').redactor({
            minHeight: 200,
            imageUpload: '<?php echo base_url(); ?>index.php/redactor/upload_image',
            fileUpload: '<?php echo base_url(); ?>index.php/redactor/upload_file',
            imageGetJson: '<?php echo base_url(); ?>index.php/redactor/get_images',
            imageUploadErrorCallback: function(json)
            {
                alert(json.error);
            },
            fileUploadErrorCallback: function(json)
            {
                alert(json.error);
            }
      });
});
</script>
<div id="container">
	<div class="shell">	
		
		<div class="small-nav" style="padding:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('cms','CMS');?>
			<span>&gt;</span>
			Edit Page
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<?php 
				if($this->session->userdata('validation_errors'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('validation_errors');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('validation_errors');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php echo anchor('cms','<span>Back To Page List</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
					</div>
			
			</div>
			
			<div id="content">
						
				<div class="box">
					<div class="box-head">
						<h2>Edit Page</h2>
					</div>
					<?php echo form_open_multipart('cms/update_page');?>
						
						<div class="form">
							<?php foreach($page_data as $page_item): ?>
								<p>
									<span class="req">max 100 symbols</span>
									<?php echo form_label('Page Title');?>
									<?php echo form_input('title',$page_item->page_title,'placeholder="Title" class="field size1" required');?>
									<?php echo form_hidden('id',$page_item->p_id); ?>
								</p>	
								
								<p>
									<?php echo form_label('Page Url Key'); ?>
									<?php echo form_input('page_url_key',$page_item->page_url_key,'placeholder="Page Url Key" class="field size1" required');?>
								</p>
								
								<p>
									<?php 
									$options = array(
												  '1'  => 'Enabled',
												  '0'    => 'Disabled',
												);
								
									//$shirts_on_sale = array('small', 'large');
									
									echo form_label('Status <span>(Required Field)</span>');
									echo form_dropdown('status', $options,'','class="field size1" ');
								?>
								</p>								
																
								<p>
									<?php echo form_label('Content'); ?>
									<?php echo form_textarea('content',$page_item->content,'placeholder="Content" class="field size1 redactor" required');?>

								</p>
								<p>
								
									<?php echo form_label('Meta Keywords'); ?>
									<?php echo form_textarea('metakeywords',$page_item->metakeywords,'placeholder="MetaKeywords" class="field size1" required');?>
								</p>
								
								<p>
								
									<?php echo form_label('Meta Description'); ?>
									<?php echo form_textarea('metadesc',$page_item->meta_desc,'placeholder="MetaDesc" class="field size1" required');?>
								</p>

							<?php endforeach ?>
							
						</div>
					
						<div class="buttons">
							<?php echo form_submit('updatebtn','Update','class="button"');?>
						</div>
					<?php echo form_close();?>
				</div>
				
				
			</div>

			<div class="cl">&nbsp;</div>			
			</div>
		</div>
</div>