<div id="container">
	<div class="shell">	
		
		<div class="small-nav" style="padding:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('news','News');?>
			<span>&gt;</span>
			Add News
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			<?php 
				if($this->session->userdata('validation_errors'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('validation_errors');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('validation_errors');
				}
			?>
			
			<?php 
				if($this->session->userdata('imgerror'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('imgerror');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('imgerror');
				}
			?>
			
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php echo anchor('news','<span>Back To News</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
					</div>
			
			</div>
			
			<div id="content">
						
				<div class="box">
					<div class="box-head">
						<h2>Add News</h2>
					</div>
					<?php echo form_open_multipart('news/create');?>
						
						<div class="form">
								<p>
									<span class="req">max 100 symbols</span>
									<?php echo form_label('News Title <span>(Required Field)</span>');?>
									<?php echo form_input('title',set_value('title'),'placeholder="Title" class="field size1"');?>
								</p>	
								
								<p>
									<?php echo form_label('Description <span>(Required Field)</span>'); ?>
									<?php echo form_textarea('desc',set_value('desc'),'placeholder="Description" class="field size1"');?>
								</p>
								
								<p>
									<?php echo form_label('Image'); ?>
									<?php echo form_upload('image',set_value('image'),'class="field size1"');?>
								</p>
								
								<p>
									<?php echo form_label('Status <span>(Required Field)</span>');?>
									<?php echo form_radio('status','1',TRUE);?>&nbsp;Enabled
									&nbsp;
									<?php echo form_radio('status','0',false);?>&nbsp;Disabled
								</p>	
								
								<!--<p class="inline-field">
									<label>Date</label>
									<select class="field size2">
										<option value="">23</option>
									</select>
									<select class="field size3">	
										<option value="">July</option>
									</select>
									<select class="field size3">
										<option value="">2009</option>
									</select>
								</p>	-->
							
						</div>
					
						<div class="buttons">
							<?php echo form_submit('addbtn','Add News','class="button"');?>
						</div>
					<?php echo form_close();?>
				</div>
				
				
			</div>
			<div class="cl">&nbsp;</div>			
			</div>
		</div>
</div>