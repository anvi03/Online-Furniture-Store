<div id="container">
	<div class="shell">	
		
		<div class="small-nav" style="padding:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('news','News');?>
			<span>&gt;</span>
			Edit News
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<?php 
				if($this->session->userdata('validation_errors'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('validation_errors');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('validation_errors');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php echo anchor('news','<span>Back To News</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
					</div>
			
			</div>
			
			<div id="content">
						
				<div class="box">
					<div class="box-head">
						<h2>Edit News</h2>
					</div>
					<?php echo form_open_multipart('news/editnews');?>
						
						<div class="form">
							<?php foreach($news as $news_data): ?>
								<p>
									<span class="req">max 100 symbols</span>
									<?php echo form_label('News Title');?>
									<?php echo form_input('title',$news_data->title,'placeholder="Title" class="field size1"');?>
									<?php echo form_hidden('id',$news_data->id); ?>
								</p>	
								
								<p>
									<?php echo form_label('Description'); ?>
									<?php echo form_textarea('desc',$news_data->description,'placeholder="Description" class="field size1"');?>
								</p>
								
								<p>
									<img src="<?php echo base_url();?>../uploads/news/<?php echo $news_data->image;?>" alt="news_image" style="width:100px;height:100px;"/>
									<?php echo form_label('Image'); ?>
									<?php echo form_upload('image',$news_data->image,'class="field size1" style="width:600px"');?>
								</p>
								
								<p>
									<?php echo form_label('Status');?>
									<input type="radio" name="status" value="1" <?php if($news_data->status == "1") echo "checked"; ?> />&nbsp;Enabled
									<input type="radio" name="status" value="0" <?php if($news_data->status == "0") echo "checked"; ?> />&nbsp;Disabled
							</p>
								<p>
								<?php /*?><?php $options = array(
								  '0'   => 'Disable',
								  '1' => 'Enable',
								   );
				
								//$shirts_on_sale = array('small', 'large');
								
								echo form_dropdown('status', $options, 'large');?>
<?php */?>
								</p>	
							<?php endforeach ?>
							
						</div>
					
						<div class="buttons">
							<?php echo form_submit('updatebtn','Update','class="button"');?>
						</div>
					<?php echo form_close();?>
				</div>
				
				
			</div>

			<div class="cl">&nbsp;</div>			
			</div>
		</div>
</div>