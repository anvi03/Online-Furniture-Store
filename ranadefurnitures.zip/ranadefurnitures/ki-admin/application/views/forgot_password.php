<!DOCTYPE html>
<html>
<head>
	<title>KI-Admin Panel</title>
		<meta charset="utf-8">
		<link href="<?php echo base_url();?>css/login.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.ico" type="image/x-icon">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,300,600,700' rel='stylesheet' type='text/css'>
</head>
<body>

			
<div class="main">
			<?php 
				if($this->session->userdata('err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px;color:#FF0000; background-color:#FDC9C1;">
				<strong><?php echo $this->session->userdata('err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('err');
				}
			?>
			
			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px;color:#FF0000; background-color:#FDC9C1;">
				<strong><?php echo $this->session->userdata('msg');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>
		<div class="login-form">
			<h1 style="margin-bottom:10px">KI - Admin Login</h1>
					<div class="head">
						<img src="<?php echo base_url(); ?>images/logo.png" alt=""/>
					</div>
					
					
				<?php 
					if($this->session->userdata('err')) 
					{ 
				?>
						<span class="err">
				<?php 
						echo $this->session->userdata('err'); 
						$this->session->unset_userdata('err'); 
				?>
						</span>
				<?php
				} 
				
				?>
				
				
				<?php 
					if($this->session->userdata('msg')) 
					{ 
				?>
						<span class="msg">
				<?php
						echo $this->session->userdata('msg'); 
						$this->session->unset_userdata('msg'); 
				?>
						</span>
				<?php	
					}
				?>
				
				
				
				<?php echo form_open('forgot/retrive_pwd');?>
				
				<input type="text" name="username"placeholder="username" required>
				
				<input type="text" name="email" placeholder="email" style="border-radius: 0 0 7px 7px;" required>
				
				<div class="submit">
					<?php echo form_submit('submit','Sent Mail',''); ?>
				</div>	
					
				<?php echo form_close(); ?>		
		</div>
<div class="copy-right">
	<p>Copyright &copy; 2015 <?php echo anchor('http://kalikundinfotech.com','Kalikund Infotech');?></p> 
</div>

</div>
			 		
</body>
</html>