<div id="container">
	<div class="shell">	
		<div class="small-nav" style="padding-bottom:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('product','Product');?>
			<span>&gt;</span>
			<?php echo "view";?>
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			
			<?php 
				if($this->session->userdata('err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px; color:#FF0000; background-color:#FDC9C1;height:35px; ">
				<strong><?php echo $this->session->userdata('err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('err');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>

			<?php 
				if($this->session->userdata('errmsg'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px; color:#FF0000; background-color:#FDC9C1;height:35px; ">
				<strong><p><?php echo $this->session->userdata('errmsg');?></p></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('errmsg');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>

			
			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-close" class="msg msg-ok" style="margin-bottom:20px">
				<p><strong><?php echo $this->session->userdata('msg');?></strong></p>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closediv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>

			<div id="content">
				
					<div class="box">
						<div class="box-head">
							<h2 class="left">Current Product</h2>
							<div class="right">
								<?php /*?><?php echo form_open('news/searchnews'); ?>
								<?php echo form_label('search news');?>
								<?php echo form_input('srchterm','','class="field small-field"');?>
								<?php echo form_submit('srchbtn','Search','class="button"');?>
<?php */?>							</div>
						</div>
	
						<div class="table">
						
							<table width="100%" border="0" id="myTable" cellspacing="0" cellpadding="0">
								<thead>
								<?php /*?><tr>
									<th width="13"><?php echo form_checkbox('ch1','class="checkbox"');?></th>
									<th>Id</th>
									<th>Title</th>
									<th>Description</th>
									<th>Image</th>
									<th>Status</th>
									<th>Date</th>
									<th width="110" class="ac">Content Control</th>
								</tr><?php */?>
								</thead>
								<tbody>
						
								<?php 
								
									foreach($product as $product_item): ?>
										<tr>
											<p>
											<th>Id</th>
											<td><?php echo $product_item->p_id;?></td>
											</p>
										<tr>
										<tr>
											<p>
											<th>Name</th>
											<td><?php echo $product_item->p_name;?></td>
											</p>

										</tr>
										<tr>
											<p>
											<th>Description Long</th>
											<td><?php echo $product_item->p_desc_long;?></td>
											</p>

										</tr>
										<tr>
											<p>
											<th>Description Short</th>
											<td><?php echo $product_item->p_desc_short;?></td>
											</p>

										</tr>

										<tr>
											<p>
											<th>Price</th>
											<td><?php echo $product_item->p_price;?></td>
											</p>

										</tr>
										
										<tr>
											<p>
											<th>Quantity</th>
											<td><?php echo $product_item->p_qty;?></td>
											</p>

										</tr>

										<tr>
											<p>
											<th>Image</th>
											<td><img src="<?php echo base_url();?>../uploads/product/<?php echo $product_item->p_image;?>" alt="Product_image"  height="150px" />
											</p>
											<tr>
											<th></th>
											<td>
											<p>
											
												<?php foreach($product_data as $product_images): ?>											
												<img src="<?php echo base_url();?>../uploads/product/<?php echo $product_images->p_id;?>/thumbs/<?php echo $product_images->image;?>" alt="Product_image"  height="100px" />
												<?php $base = base_url();?>
												
												<?php ?>
												<?php echo anchor("{$base}index.php/product/deleteimage/".$product_images->image_id," ",'class="ico del" onclick="return window.confirm(\'Are you Sure ?\');"');?>&nbsp;&nbsp;
												<?php endforeach;?>
										
											</p>
											</td>
											</tr>
											
											</td>
										</tr>

									
										
										<tr>
											<p>
											<th>Status</th>
											<td><?php if($product_item->p_status == 1)
														{
															echo "Enable";
														}
														else
														{
															echo "Desable";
														}
												?></td>
											</p>

										</tr>
										
										<tr>
											<p>
											<th>Created</th>
											<td><?php echo $product_item->p_created; ?></td>
											</p>

										</tr>
										

										<tr>
											<p>
											<th>Updated</th>
											<td><?php echo $product_item->p_updated;?></td>
											</p>

										</tr>
										
										<tr>
											<p>
											<th>Category Id</th>
											<td><?php echo $product_item->c_id;?></td>
											</p>

										</tr>
										
								<?php
									endforeach;
								
								?>
								<?php //echo $this->pagination->create_links();?>
								<tbody>
							</table>
							
							<br />
							<br />
							<h2>add to releted image</h2>
							<?php 
								echo form_open_multipart('product/addimages');
								echo form_hidden('p_id',$this->uri->segment(3));
								echo form_label('Image','fileimg required');
								echo form_upload('image[]','','class="field size1" multiple');
								echo form_submit('submit','Add Image','class="button"');
								echo form_close();
							?>	 
						
						
							
						
							<div class="pagging">
								<!--<div class="left">Showing 1-12 of 44</div>-->
								<div class="right">
								<p><?php //echo $links; ?></p>
								<!--<a href="#">Previous</a>
								<a href="#">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#">4</a>
								<a href="#">245</a>
								<span>...</span>
								<a href="#">Next</a>
								<a href="#">View all</a>-->
								</div>
								</div>
						
							</div>
					
						</div>
			
			</div>
	
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
							<div class="box-content">
							<?php echo anchor('product','<span>Back To Product</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
							<!-- Sort -->
							<!--<div class="sort">
							<?php //echo form_label('Sort by');?><?php ?>
								<select class="field">
									<option value="">Title</option>
								</select>
								<!--<select class="field">
									<option value="">Date</option>
								</select>
								<select class="field">
									<option value="">Author</option>
								</select>
							</div>-->
							<!-- End Sort -->
	
						</div>
					</div>
			
			</div>
		
			<div class="cl">&nbsp;</div>			
		</div>
	</div>
</div>