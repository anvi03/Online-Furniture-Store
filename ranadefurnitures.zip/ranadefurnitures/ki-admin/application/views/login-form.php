<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
		<meta charset="utf-8">
		<link href="<?php echo base_url();?>css/login.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="<?php echo base_url();?>images/favicon.ico" type="image/x-icon">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,300,600,700' rel='stylesheet' type='text/css'>
</head>
<body>

			
<div class="main">
		<?php 
				if($this->session->userdata('access'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px;color:#FF0000; background-color:#FDC9C1;">
				<strong><?php echo $this->session->userdata('access');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('access');
				}
			?>
		<div class="login-form">
			<h1 style="margin-bottom:10px">Admin Login</h1>
					<div class="head">
						<img src="<?php echo base_url(); ?>images/logo.png" alt=""/>
					</div>
					
					
				<?php 
					if($this->session->userdata('err')) 
					{ 
				?>
						<span class="err">
				<?php 
						echo $this->session->userdata('err'); 
						$this->session->unset_userdata('err'); 
				?>
						</span>
				<?php
				} 
				
				?>
				
				
				<?php 
					if($this->session->userdata('msg')) 
					{ 
				?>
						<span class="msg">
				<?php
						echo $this->session->userdata('msg'); 
						$this->session->unset_userdata('msg'); 
				?>
						</span>
				<?php	
					}
				?>
				
				
				
				<?php echo form_open('login/validate_login'); ?>
				
				<?php echo form_input('user','','class="text" placeholder="Username" required'); ?>
				
				<?php echo form_password('pass','','placeholder="Password" required'); ?>
				
				<div class="submit">
					<?php echo form_submit('submit','LOGIN','onClick="myFunction()"'); ?>
				</div>	
					<p><?php echo anchor('forgot/forget_view','Forgot Password ?'); ?></p>
				<?php echo form_close(); ?>		
		</div>
<div class="copy-right">
	<p>Copyright &copy; 2015 <?php echo anchor('http://kalikundinfotech.com','Kalikund Infotech');?></p> 
</div>

</div>
			 		
</body>
</html>