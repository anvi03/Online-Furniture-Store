<style type="text/css">
#primary_nav_wrap
{
	margin:5px 5px 5px 5px;
	width:1100px;	
}

#primary_nav_wrap ul
{
	list-style:none;
	position:relative;
	float:left;
	margin:0;
	padding:0
}

#primary_nav_wrap ul a
{
	display:block;
	color:#fff;
	text-decoration:none;
	font-weight:700;
	font-size:13px;
	line-height:32px;
	padding:0 15px;
	font-family:"HelveticaNeue","Helvetica Neue",Helvetica,Arial,sans-serif
}

#primary_nav_wrap ul li
{
	position:relative;
	float:left;
	margin:0;
	padding:0
}

#primary_nav_wrap ul li.current-menu-item
{
	background:#ddd;
	margin-right:5px;
}

#primary_nav_wrap ul li:hover,#primary_nav_wrap ul li .active
{
	border-top-left-radius:5px; border-top-right-radius:5px; 
	background:#4aaaa5;
	color:#fff;
}

#primary_nav_wrap ul ul
{
	display:none;
	position:absolute;
	top:100%;
	left:0;
	background:#fff;
	padding:0
}

#primary_nav_wrap ul ul li
{
	float:none;
	width:200px
}

#primary_nav_wrap ul ul a
{
	line-height:120%;
	padding:10px 15px
}

#primary_nav_wrap ul ul ul
{
	top:0;
	left:100%
}

#primary_nav_wrap ul li:hover > ul
{
	display:block
}
</style>


<div id="primary_nav_wrap">
			<ul>
				<?php $dash = activate_menu('dashboard');?>
				<?php $news = activate_menu('news');?>
				<?php $categories = activate_menu('categories');?>
				<?php $product = activate_menu('product');?>
				<?php $contacts = activate_menu('contacts');?>
				<?php $cms = activate_menu('cms');?>
				<?php $banner = activate_menu('banner');?>
				<?php $user = activate_menu('register_user');?>
				<?php $order = activate_menu('orders');?>
				<?php $sales = activate_menu('sales');?>
				<?php $product_report = activate_menu('product_report');?>
				<?php $customer_report = activate_menu('customer_report');?>


				
			    <li><?php echo anchor('dashboard','<span>Dashboard</span>',$dash);?></li>
			    <li><?php echo anchor('news','<span>News</span>',$news); ?></li>
				<li><?php echo anchor('categories','<span>Categories</span>',$categories);?>
					
			    </li>
				<li><?php echo anchor('product','<span>Products</span>',$product);?></li>
				
				<li><?php echo anchor('contacts','<span>Contacts</span>',$contacts);?></li>
				
				<li><?php echo anchor('cms','<span>CMS</span>',$cms);?></li>
				
				<li><?php echo anchor('banner','<span>Banner</span>',$banner);?></li>
				
				<li><?php echo anchor('register_user','<span>Users</span>',$user);?></li>
				
				<li><?php echo anchor('orders','<span>Orders</span>',$order);?></li>
				
				<li><?php echo anchor('sales','<span>Sales</span>',$sales);?></li>
				
				<li><?php echo anchor('product_report','<span>Product Report</span>',$product_report);?>
				</li>
				
				<li><?php echo anchor('customer_report','<span>Customer</span>',$customer_report);?></li>
			</ul>

</div>