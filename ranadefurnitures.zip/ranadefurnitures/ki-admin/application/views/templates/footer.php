<div class="line">
	</div>
<div id="footer">
	<div class="shell">
		<span class="left">Copyright &copy; <?php echo date('Y'); ?> <!--- Kalikund Infotech. All Rights Reserved.--></span>
		<span class="right">
			Developed by Khushbu Mulatani & Patil Shital 
		</span>
	</div>
</div>
</body>
</html>