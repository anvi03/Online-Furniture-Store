<div id="container">
	<div class="shell">	
		<div class="small-nav" style="padding-bottom:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('contacts','Contacts');?>
			
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-close" class="msg msg-ok" style="margin-bottom:20px">
				<p><strong><?php echo $this->session->userdata('msg');?></strong></p>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closediv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>
			<?php 
				if($this->session->userdata('err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px; color:#FF0000; background-color:#FDC9C1;height:35px; ">
				<strong><p><?php echo $this->session->userdata('err');?></p></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('err');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>

			<div id="content">
				
					<div class="box">
						<div class="box-head">
							<h2 class="left">Current Contacts</h2>
							<div class="right">
								<?php /*?><?php echo form_open('news/searchnews'); ?>
								<?php echo form_label('search news');?>
								<?php echo form_input('srchterm','','class="field small-field"');?>
								<?php echo form_submit('srchbtn','Search','class="button"');?>
<?php */?>							</div>
						</div>
	
						<div class="table">
						
							<?php
								echo form_open('contacts/checkbox');?>					
							<table width="100%" border="0" id="myTable" cellspacing="0" cellpadding="0">
								<thead>
								<tr>
									<th width="13"><input type="checkbox" name="chk" onclick='ToggleAll(this);'/></th>
									<th>Id</th>
									<th>Name</th>
									<th>Email</th>
									<th>Company Name</th>
									<th>Subject</th>
									<th>Date</th>
									<th width="110" class="ac">Content Control</th>
								</tr>
								</thead>
								<tbody>
								<?php 
								foreach($contact as $contact_item): ?>
										<tr>
											<td><input type="checkbox" name="chk[]" id="chk" value="<?php echo $contact_item->contact_id;?>"/></td>					
											<td><h3><?php echo $id = $contact_item->contact_id;?></h3></td>

											<td><h3><?php $name = $contact_item->contact_name;
											echo substr($name,0,5).'.....'; ?></h3></td>
											<td><?php echo $email = $contact_item->contact_email;
												?></td>
											<td><h3><?php echo $company_name = $contact_item->company_name;?></h3></td>	
											<td><h3><?php echo $subject = $contact_item->subject;?></h3></td>
											
											<td><?php $date = $contact_item->contact_date;
												echo "$date";?></td>
											<?php
											$base = base_url();
											$id = $contact_item->contact_id;
											?>
											<td><?php echo anchor("{$base}index.php/contacts/deletecontact/$id"," ",'class="ico del" onclick="return window.confirm(\'Are you Sure ?\');"');?><?php echo anchor("{$base}index.php/contacts/contactview/$id"," ",'class="ico view"');?></td>
										</tr>
										
								<?php
									endforeach;
								
								?>	 
								</tbody>
							</table>
							
						
							<div class="pagging">
								<!--<div class="left">Showing 1-12 of 44</div>-->
								<div class="right">
								<p><?php //echo $links; ?></p>
								<!--<a href="#">Previous</a>
								<a href="#">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#">4</a>
								<a href="#">245</a>
								<span>...</span>
								<a href="#">Next</a>
								<a href="#">View all</a>-->
								</div>
								</div>
						
							</div>
					
						</div>
			
			</div>
	
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php /*?><?php echo anchor('news/create','<span>Add News</span>','class="add-button"'); ?><?php */?>
							<div class="cl">&nbsp;</div>
							
							<p><input type="submit" class="button" value="Delete Selected" name="delete" onclick="return window.confirm('Are You Sure?');"/>
</p>
							
</form>
	
								
								<!-- Sort -->
							<!--<div class="sort">
							<?php //echo form_label('Sort by');?><?php ?>
								<select class="field">
									<option value="">Title</option>
								</select>
								<!--<select class="field">
									<option value="">Date</option>
								</select>
								<select class="field">
									<option value="">Author</option>
								</select>
							</div>-->
							<!-- End Sort -->
	
						</div>
					</div>
			
			</div>
		
			<div class="cl">&nbsp;</div>			
		</div>
	</div>
</div>