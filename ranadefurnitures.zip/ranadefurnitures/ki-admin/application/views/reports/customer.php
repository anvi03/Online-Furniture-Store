<!-- Starting of Container-->
	<div id="container">
    	<!-- Starting of Shell-->
    	<div class="shell">
    		<!-- Starting of Small Navigation-->
        	<div class="small-nav">
				<?php 
					echo br();
					echo anchor('dashboard','Dashboard');
					echo  " > ";
					echo anchor('customer_report','customer_report');
					echo " > ";
                ?>
                List of Customer Report
			</div>
             <div id="div-close" class="msg msg-ok"  onclick="return closediv();">
				<?php
                if ($this->session->userdata('msg'))
                {
                ?>
            
                    <p><strong><?php echo $this->session->userdata('msg'); ?></strong></p>
                	<a href="" class="close" onclick="return closediv()">close</a>
                <?php $this->session->unset_userdata('msg');}?>
			</div>
			<div class="msg msg-error" id="error" onclick="return error();">
            <?php
                if ($this->session->userdata('err'))
                {
                ?>
					<p><strong><?php echo $this->session->userdata('err'); ?></strong></p>
                    <a href="" class="close" onclick="return closediv()">close</a>
			 <?php $this->session->unset_userdata('err');}?>
			</div>
            
			<div id="div-error-close" class="msg msg-error">

                <p><strong>
                <?php
					if($this->session->userdata('err')!="")
					{
						echo $this->session->userdata('err');
						$this->session->unset_userdata('err');
					}
					else
					{
				?>
                		<script>
                        	document.getElementById('div-error-close').style.display='none';
                        </script>
                <?php
					}
				?></strong></p>
			</div>
            
            <!-- End of Small Navigation-->
        
        <!-- Starting of Main-->
        <div id="main">
			<div class="cl">&nbsp;</div>
            <div id="container"  >
                <!-- Starting of Content-->
                <div id="content" >
                
                    <!-- Starting of box-->
                    <div class="box">
                        <!-- Starting of Box Head-->
                        <div class="box-head">
                            <h2 class="left">Customers Reports</h2>
                           
                        </div>
                        <!-- End of Box Head-->
                        
                        <!-- Starting of Table-->
                        <div class="table">
                      
                        	<center>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" id="example">
                            <thead>
                                <tr>
                               		<th>Id </th>
                                    <th>Name</th>
                                    
                                    <th>Email</th>
                                    <th>Mobile No</th>
                                    <th>Total sale</th>
                                    
                                </tr>
                               </thead>
                               <tbody>
                               <?php 
							   /*echo "<pre>";
							   print_r($total);
							   die;*/
							   $ch=0;
                                 foreach($arrobj as $arrobj)
                                        {
											?>
                               <tr >
                             	
                               	<td><?php echo $arrobj['id'];?></td>
                               	<td><?php echo $arrobj['firstname'];?></td>
                                
                                <td><?php echo $arrobj['email'];?></td>
                                <td><?php echo $arrobj['mobile_no'];?></td>
                                <td><?php echo $total[$ch]?></td>
                                
                                <td>&nbsp;</td>
                               </tr>
                               <?php 
							   $ch++;
							   } ?>
                             
                                </tbody>
                            </table>
                            </center>
                        </div>
                        <!-- End of Box Table-->
                        
                        <!-- Pagging -->
                      
                            <div class="pagging">
                                
                                </div>
                       
                        <!-- End Pagging -->
                            
                        </div>
                    <!-- End of Box-->
                </div>
                <!-- End of Content-->
                
                <!-- Starting of SideBar-->
                <div id="sidebar">
            	
                <!-- Starting of Box-->
                <div class="box">
                
                	<!-- Starting of Box Head-->
                	<div class="box-head">
                    	<h2>Customer PDF</h2>
                    </div>
                    <!-- End of Box Head-->
                    
                    <!-- Starting of Box Head-->
                    <div class="box-content">
                    	<a href="customer_report/getpdf"  target="_blank" class="add-button"><span>Create PDF</span></a><br /><br /><br />                 
					</div>
                    <!-- End of Box Head-->
				
                </div>
                <!-- End of Box-->
			
            </div>
                    
                    <!-- Starting of Box-->
                    <?php /*?><div class="box">
                    
                        <!-- Starting of Box Head-->
                        <div class="box-head">
                            <h2>Management</h2>
                        </div>
                        <!-- End of Box Head-->
                        
                        <!-- Starting of Box Head-->
                        <div class="box-content">
                            
                                <div class="cl">&nbsp;</div>
                                    
                                    <?php
						   echo br(2);
				echo form_submit('del','Delete Selected','class="button" onClick="return confirm('."'Are You Sure You Want To Delete?'".');"');
				?>
				<?php
				echo form_close();
                ?>                    
                                    
                                
                        </div>
                        <!-- End of Box Head-->
                    
                    </div><?php */?>
                    <!-- End of Box-->
                
                </div>
                <!-- End of Sidebar-->
			</div>
            <!-- End of container-->
			<div class="cl">&nbsp;</div>
        </div>
        <!-- End of Main-->
	
    </div>
    <!-- End of Box Shell-->

</div>
<!-- End of Box Container-->
               