<div id="container">
	<div class="shell">	
		
		<!-- Small Nav -->
		<div class="small-nav">
		<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('product','product_report');?>
			
		</div>
		
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-close" class="msg msg-ok" style="margin-bottom:20px">
				<p><strong><?php echo $this->session->userdata('msg');?></strong></p>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closediv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>
			
			
			<?php 
				if($this->session->userdata('err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px; color:#FF0000; background-color:#FDC9C1;height:35px; ">
				<strong><p><?php echo $this->session->userdata('err');?></p></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('err');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>

			
			<!-- Content -->
			
			<div id="content">
				
					<div class="box">
						<div class="box-head">
							<h2 class="left">Current Categories</h2>
							<?php /*?><div class="right">
								<?php echo form_open('categories/searchcategories'); ?>
								<?php echo form_label('search news');?>
								<?php echo form_input('srchterm',set_value('srchterm'),'class="field small-field"');?>
								<?php echo form_submit('srchbtn','Search','class="button"');?>
						</div><?php */?>
						</div>
	
						<?php /*?><div class="table">
						<?php echo form_open('categories/checkbox');?>
							<table width="100%" border="0" id="myTable" cellspacing="0" cellpadding="0">
								<thead>
									<tr>
										<th width="13"><input type="checkbox" name="chk" onclick='ToggleAll(this);'/></th>
										<th>Id</th>
										<th>Name<a></a></th>
										<th>price</th>
										<th>sold</th>
                                		<th>Quanity</th>
										<th width="110" class="ac">Content Control</th>
									</tr>
								</thead>
								<tbody>
								<?php 
								if(!is_array($arrobj))
                                {
                                    echo "<tr><td colspan='7'>".$arrobj."</td></tr>";
                                }
                                else
                                {
									$i=0;
                                    foreach($arrobj as $obj)
                                    {
                                ?>
                                        <tr <?php if($obj['p_id']%2!=0) echo 'class="odd"';?>>
                                        	
                                        	<td><input type="checkbox" name="chk[]" id="chk" value="<?php echo $obj['p_id'];?>"/></td>
											<td><h3><?php echo $obj['p_id'];?></h3></td>
                                            <td><h3><?php echo $obj['p_name'];?></h3></td>
                                            <td><h3><?php echo $obj['p_price'];?></h3></td>
                                             <td><h3><?php echo $total[$i];?></h3></td>
                                             <td><h3><?php echo $obj['p_qty'];?></h3></td>
                                             
                                        </tr>
                                <?php
								$i++;
                                    }
                                }
                            ?>
							</tbody>
							</table>
							
						
						
							<div class="pagging">
								<!--<div class="left">Showing 1-12 of 44</div>-->
								<div class="right">
								<p><?php //echo $links; ?></p>
								<!--<a href="#">Previous</a>
								<a href="#">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#">4</a>
								<a href="#">245</a>
								<span>...</span>
								<a href="#">Next</a>
								<a href="#">View all</a>-->
								</div>
								</div>
						
							</div><?php */?>
							<div class="table">
                  <table>
                    <thead >
                      <tr >
                   <!-- <th style="background:#fff"><input type="checkbox" name="chk" onclick='ToggleAll(this);'/></th>-->
                        <th>Customer Name</th>
                        <th>Product Name</th>
                        <th>quantity</th>
                        <th>Email</th>
                        <th>Price</th>
                        <th>Total Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
					
					   foreach ($sales as $sales_item){ ?>
							<tr>

								<td><?php echo $sales_item->username?></td>
								<td><?php echo $sales_item->p_name ?></td>
                                <td><?php echo $sales_item->quantity ?></td>
                             	<td>
								<?php 
								echo $sales_item->email; 
								?>
                                </td>
                             	<td>
								<?php 
								echo $sales_item->p_price; 
								?>
                                </td>
								<td><?php echo $sales_item->quantity*$sales_item->p_price?></td>
												</tr>
							<?php } ?>
                      
                    </tbody>
                
                  </table>
                 
                </div>
					
						</div>
						
			
			</div>
			<div id="sidebar">
            	
                <!-- Starting of Box-->
                <div class="box">
                
                	<!-- Starting of Box Head-->
                	<div class="box-head">
                    	<h2>Sales PDF</h2>
                    </div>
                    <!-- End of Box Head-->
                    
                    <!-- Starting of Box Head-->
                    <div class="box-content">
                    	<a href="sales/getpdf"  target="_blank" class="add-button"><span>Create PDF</span></a><br /><br /><br />                 
					</div>
                    <!-- End of Box Head-->
				
                </div>
                <!-- End of Box-->
			
            </div>
			
			
			
			
					<div class="cl">&nbsp;</div>			
			</div>
		<!-- Main -->
		</div>
</div>