<?php //echo "<pre>";print_r($order);?>
<div style="font-size:20px;">
	<strong><?php echo "Online Furniture Mall";?>
	</strong>
</div>

<div style="font-size:20px; border:1px solid #333333;">
<div style="float:left; margin-right:200px;">
	<strong>
	*<?php echo $order[0]->order_no;?>*</strong>
</div>	
	<table>
			<tr>
				<th>	
					Bill To Address
				</th>
				<th style="padding-left:300px;">
					Ship To Address
				</th>
			</tr>
			<tr>
				<td>
					<?php echo $order[0]->bill_firstname;?>
					<?php echo $order[0]->bill_lastname;?> <br >
					<?php echo $order[0]->bill_address1;?> <br >
					<?php echo $order[0]->bill_email;?><br >
					<?php echo $order[0]->bill_phone;?>
				</td>
				<td style="padding-left:300px;">
					<?php echo $order[0]->ship_firstname;?>
					<?php echo $order[0]->ship_lastname;?> <br >
					<?php echo $order[0]->ship_address1;?> <br >
					<?php echo $order[0]->ship_email;?><br >
					<?php echo $order[0]->ship_phone;?>
				</td>
			</tr>
	</table>
</div>
<div style="font-size:20px; margin-top:20px; width:1200px;  margin-left:20px; border:1px solid #333333;">
	<table border="1">
		<tr>
			<th style="border:1px solid #000000; width:400px;">
				Quantity
			</th>
			<th style="border:1px solid #000000; width:400px;">
				Name
			</th>
			<th style="border:1px  solid #000000; width:400px;">
				Description
			</th>
		</tr><?php foreach($order as $order_item)
							  {
							  		?>
						
		<tr>
			<td style="border:1px solid #000000;"><?php echo $order_item->quantity;?></td>
			<td style="border:1px solid #000000;"><?php echo $order_item->p_name;?></td>
			<td style="border:1px solid #000000;"><?php echo $order_item->p_desc_short;?></td>
		</tr>
		<?php }?>
	</table>
</div>