<?php //echo "<pre>";print_r($order);die;?>
<div id="container">
	<div class="shell">	
		<div class="small-nav" style="padding-bottom:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('orders','Orders');?>
			<span>&gt;</span>
			<?php echo "View"; ?>

		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-close" class="msg msg-ok" style="margin-bottom:20px">
				<p><strong><?php echo $this->session->userdata('msg');?></strong></p>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closediv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>

			<div id="content">
				
					<div class="box">
						<div class="box-head">
							<h2 class="left">View Order</h2>
							<div class="right">
								<?php /*?><?php echo form_open('news/searchnews'); ?>
								<?php echo form_label('search news');?>
								<?php echo form_input('srchterm','','class="field small-field"');?>
								<?php echo form_submit('srchbtn','Search','class="button"');?>
<?php */?>					</div>
						</div>
						<div class="table">
						<table>
									<tr>
										<th style="width:225px; text-align:center;">Account Info</th>
										<th style="width:225px; text-align:center;">Billing Info</th>
										<th style="width:225px; text-align:center;">Shipping Info</th>
									</tr>
									<tr>
										<td><?php echo $order[0]->username;?>
										<?php echo $order[0]->email;?>
										<?php echo $order[0]->mobile_no;?></td>
										<td>
											<?php echo $order[0]->bill_firstname;?> 
											<?php echo $order[0]->bill_lastname;?><br  />
											<?php echo $order[0]->bill_address1;?><br  />
											<?php echo $order[0]->bill_email;?><br  />
											<?php echo $order[0]->bill_phone;?>
										</td>
										<td>
											<?php echo $order[0]->ship_firstname;?> 
											<?php echo $order[0]->ship_lastname;?><br  />
											<?php echo $order[0]->bill_address1;?><br  />
											<?php echo $order[0]->ship_email;?><br  />
											<?php echo $order[0]->ship_phone;?>
										</td>										
									</tr>
									</table>
									<table>
									<tr>
										<th style="width:180px; text-align:center;">Name</th>
										<th style="width:180px; text-align:center;">Image</th>
										<th style="width:180px; text-align:center;">Price</th>
										<th style="width:180px; text-align:center;">Quantity</th>
										<th style="width:180px; text-align:center;">Total</th>
									</tr>
									</tr>
									
									
									<td><?php $ord_no = $order[0]->order_no;?></td>
									<?php echo form_open('orders/update_status/'.$ord_no);?>
									<?php echo form_label('Status:');?>
							  <select name="status"  class="field size1" style="width:80%;">
                <option value="orderplaced" <?php if($order[0]->status=="orderplaced"){ echo "selected"; } else { echo ""; } ?> >Order Placed</option>
                <option value="pending" <?php if($order[0]->status=="pending"){ echo "selected"; } else { echo ""; } ?>>Pending</option>
                <option value="processing" <?php if($order[0]->status=="processing"){ echo "selected"; } else { echo ""; } ?>>Processing</option>
                <option value="shipped" <?php if($order[0]->status=="shipped"){ echo "selected"; } else { echo ""; } ?>>Shipped</option>
              
                <option value="cancelled" <?php if($order[0]->status=="cancelled"){ echo "selected"; } else { echo ""; } ?>>Cancelled</option>
                <option value="delivered" <?php if($order[0]->status=="delivered"){ echo "selected"; } else { echo ""; } ?>>Delivered</option>
                </select><button class="button" style="width:80px;height:25px;  margin-left:20px;">Save</button>
				<?php echo form_close();?>
</td></tr>

						<?php $i = 0;?>
						<?php foreach($order as $order_item)
							  {
							  		?>
									
										<tr>
										<td>
											<?php echo $order_item->p_name;?>
										</td>
										<td>
											<img src="<?php echo base_url();?>../uploads/product/<?php echo $order_item->p_image;?> " width="200px" height="150px"/>
										</td>
										<td>
											&#8377;<?php $price =$order_item->p_price;
														echo $price;
											?>
										</td>
										<td>
											<?php $qty = $order_item->quantity;
													echo $qty;
											?>
										</td>
										<td>
											&#8377;<?php $tot = $price*$qty;
															echo $tot;
															$i += $tot;
															$i++;
											?>
										</td>
									
									<?php 
							  }?>
							  <tr>
							  		<th colspan="4">Grand Total</th>
									<td><?php 
												?>&#8377;<?php echo $i;
									?></td>
							  </tr>
							  </table>
							  <tr><td>
							  
						</table>
						</div>	  
	
						<?php /*?><div class="table">
						
							<table width="100%" border="0" id="myTable" cellspacing="0" cellpadding="0">
								<thead>
								<tr>
									<th width="13"><?php echo form_checkbox('ch1','class="checkbox"');?></th>
									<th>Id</th>
									<th>Title</th>
									<th>Description</th>
									<th>Image</th>
									<th>Status</th>
									<th>Date</th>
									<th width="110" class="ac">Content Control</th>
								</tr>
								</thead>
								<tbody>
								<?php 
								
									foreach($order as $order_item): ?>
										<tr>
											<p>
											<th>Id</th>
											<td><?php echo $order_item->id;?></td>
											</p>
										<tr>
										<tr>
											<p>
											<th>UserName</th>
											<td><?php echo $order_item->username;?></td>
											</p>

										</tr>
										<tr>
											<p>
											<th>Product Name</th>
											<td><?php echo $order_item->name;?></td>
											</p>

										</tr>
										<tr>
											<p>
											<th>Image</th>
											<td><img src="<?php echo base_url();?>../uploads/product/<?php echo $order_item->img;?>" alt="product_image" width="100px" height="50" /></td>
											</p>

										</tr>
										<tr>
											<p>
											<th>Qauntity</th>
											<td><?php echo $order_item->qty;?></td>
											</p>

										</tr>
										
										
										
										<tr>
											<p>
											<th>price</th>
											<td><?php echo $order_item->price;?></td>
											</p>

										</tr>
										
										<tr>
											<p>
											<th>Status</th>
											<td><?php echo $order_item->status;?></td>
											</p>

										</tr>

										<tr>
											<p>
											<th>SubTotal</th>
											<td><?php echo $order_item->subtotal;?></td>
											</p>

										</tr>
																				
										
										
								<?php
									endforeach;
								
								?>
								<?php //echo $this->pagination->create_links();?>
								<tbody>
							</table>
						
						
							<div class="pagging">
								<!--<div class="left">Showing 1-12 of 44</div>-->
								<div class="right">
								<p><?php //echo $links; ?></p>
								<!--<a href="#">Previous</a>
								<a href="#">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#">4</a>
								<a href="#">245</a>
								<span>...</span>
								<a href="#">Next</a>
								<a href="#">View all</a>-->
								</div>
								</div>
						
							</div><?php */?>
					
						</div>
			
			</div>
	
			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
							<div class="box-content">
							<?php echo anchor('orders','<span>Back To Orders</span>','class="back-button"'); ?>
							<br  /><br  /><br  />
							<?php echo anchor('orders/packing_slip/'.$ord_no,'<span>Packing Slip</span>','class="button" style="text-decoration:none;"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
							<!-- Sort -->
							<!--<div class="sort">
							<?php //echo form_label('Sort by');?><?php ?>
								<select class="field">
									<option value="">Title</option>
								</select>
								<!--<select class="field">
									<option value="">Date</option>
								</select>
								<select class="field">
									<option value="">Author</option>
								</select>
							</div>-->
							<!-- End Sort -->
	
						</div>
					</div>
			
			</div>
		
			<div class="cl">&nbsp;</div>			
		</div>
	</div>
</div>