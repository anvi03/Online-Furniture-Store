<div id="container">
	<div class="shell">	
		
		<div class="small-nav" style="padding:5px">
			<?php echo anchor('dashboard','Dashboard');?>
			<span>&gt;</span>
			<?php echo anchor('profile','Setting');?>
			<span>&gt;</span>
			Change Password
		</div>
		<br />
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<?php 
				if($this->session->userdata('validation_errors'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px;color:#FF0000; background-color:#FDC9C1;">
				<strong><?php echo $this->session->userdata('validation_errors');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('validation_errors');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px;">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>
			
			
			<?php 
				if($this->session->userdata('msg'))
				{
			?>
			<div id="div-close" class="msg msg-ok" style="margin-bottom:20px">
				<p><strong><?php echo $this->session->userdata('msg');?></strong></p>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closediv();" />
			</div>
			<?php
					$this->session->unset_userdata('msg');
				}
			?>

			
			<?php 
				if($this->session->userdata('err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px; color:#FF0000; background-color:#FDC9C1;height:35px; ">
				<strong><p><?php echo $this->session->userdata('err');?></p></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('err');
				}
			?>
			
			<?php 
				if($this->session->userdata('img_err'))
				{
			?>
			<div id="div-error-close" class="msg msg-error" style="margin-bottom:20px">
				<strong><?php echo $this->session->userdata('img_err');?></strong>
				<img src="<?php echo base_url();?>images/close.gif" style="width:35px;height:35px;cursor:pointer;position:absolute;right:0px;top:0px" onClick="return closeerrordiv();" />
			</div>
			<?php
					$this->session->unset_userdata('img_err');
				}
			?>

			<div id="sidebar">
			
					<div class="box">
					
						<div class="box-head">
							<h2>Management</h2>
						</div>
	
						<div class="box-content">
							<?php echo anchor('profile','<span>Back To Profile</span>','class="back-button"'); ?>
							<div class="cl">&nbsp;</div>
	
						</div>
					</div>
			
			</div>
			
			<div id="content">
						
				<div class="box">
					<div class="box-head">
						<h2>Change Password</h2>
					</div>
					<div class="form">
					<?php echo form_open('profile/update_pwd');
									?><p>
									<?php
									echo form_label('Password ','password');
									echo form_password('password','','class="field size1" required');
									?><p>
									<?php

									echo form_label('New Password ','newpassword');
									echo form_password('newpwd','','class="field size1" required');
									?><p>
									<?php

									echo form_label('Confirm Password ','confirmpwd');
									echo form_password('confirmpwd','','class="field size1" required');
									?><p>
									
	
						</div>
					
						<div class="buttons">
							<?php echo form_submit('submit','Update Password','class="button"');?>
						</div>
					<?php echo form_close();?>
				</div>
				
				
			</div>

			<div class="cl">&nbsp;</div>			
			</div>
		</div>
</div>