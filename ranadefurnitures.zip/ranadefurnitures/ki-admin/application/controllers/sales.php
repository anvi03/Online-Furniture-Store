<?php
if( ! defined('BASEPATH')) exit('No direct script access allowed');
class Sales extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('is_logged_in') || $this->session->userdata('is_logged_in')==TRUE)
		{
				$this->load->model('sales_model');
				//$this->load->model('order_model');
				//$this->load->model('invoice_model');
		}
		else
		{
			redirect('login');
		}			
	}
	public function index() 
   {
    $data['title']="Sales Reports";
	$data['sales']=$this->sales_model->get_sales();
	//echo "<pre>";print_r($data['sales']);
	$data['page']='reports/sales_reports';
    $this->load->view('templates/content',$data);
   }
	public function getPdf()
	{
		$i=0;
		$data['sales']=$this->sales_model->get_sales();	
		foreach($data['sales'] as $row)
		{
			$v=$row->p_price*$row->quantity;
			$i+=$v;
		}
		
		$this->load->model('fpdf');
		$this->fpdf->AddPage();
		$this->fpdf->SetFont('Arial','B',30);
		$this->fpdf->cell(88,20,"Sales Report",'','','L');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(56,20,"Date : ".date('Y/m/d'),'','','L');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(40,20,"Total Sales Amount : ".$i,'',1,'C');		
						
		$this->fpdf->SetLineWidth(.3);
		$data['totalsales']=$i;		
		$this->fpdf->SetFont('Arial','B',10);
        $this->fpdf->Cell(50,8,"Customer Name",1,'','C');
		$this->fpdf->Cell(50,8,"Product Name",1,'','C');
		$this->fpdf->Cell(20,8,"Qty",1,'','C');
		$this->fpdf->Cell(30,8,"Price",1,'','C');
		$this->fpdf->Cell(40,8,"Total Amount",1,'','C');
    	//$this->fpdf->Ln();	
		$this->fpdf->SetFillColor(500,500,500);
	    $this->fpdf->SetTextColor(0);
    	$this->fpdf->SetFont('');
		$fill = false;
		foreach($data['sales'] as $row)
		{
			$this->fpdf->Cell(50,8,ucfirst($row->username),'LR',0,'C',$fill);
			$this->fpdf->Cell(50,8,ucfirst($row->p_name),'LR',0,'C',$fill);
			$this->fpdf->Cell(20,8,number_format($row->quantity),'LR',0,'C',$fill);
			$this->fpdf->Cell(30,8,number_format($row->p_price),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,number_format($row->quantity*$row->p_price),'LR',0,'C',$fill);
			$this->fpdf->Ln();
			$fill = !$fill;
		}		
		$this->fpdf->Cell(190,0,"",1,'','C');
		$this->fpdf->Output();																
	}
	/*public function checkBox()
	{
		if(is_array($this->input->post('chk')))
		{
			foreach($this->input->post('chk') as $value)
			{
				if($this->input->post('enable'))
				{
					$this->sales_model->enable_sales($value);			
					$v="Selected Record Enabled Successfully...!!!";
				}
				else if($this->input->post('disable'))
				{
					$this->sales_model->disblesales($value);		
					$v="Selected Record Disabled Successfully...!!!";							
				}
				else if($this->input->post('delete'))
				{
					$this->sales_model->delete_sales($value);
					$v="Selected Record Deleted Successfully...!!!";	
				}
			}
			$this->session->set_userdata('msg',$v);		
		}
		redirect('sales');
	}
	public function page($page,$data="")
	{
		$data['page'] = $page;
		$this->load->view('templates/content',$data);
	}
	public function index()
	{			
		$data['status']=0;
		$data['title'] = "Ki-Admin : : sales Listing";
		$data['sales']=$this->sales_model->get_sales();			
		$i=0;
		foreach($data['sales'] as $row)
		{
			$v=$row->price*$row->qty;
			$i+=$v;
		}
		$data['totalsales']=$i;		
		$this->page('sales/sales_list',$data);				
	}	
	public function addsales()
	{		
		$this->form_validation->set_rules('p_date','p_date','trim|required');		
		if ($this->form_validation->run() === FALSE)
		{			
			$data['ono']=$this->invoice_model->get_invoice();			
			$data['title'] = "Ki-Admin : : Add sales";
			$this->page('sales/sales_add',$data);
		}
		else
		{	
			echo "<pre>";
			print_r($_POST);	
			die();			
			if($this->sales_model->addsales())
			{
				$this->session->set_userdata('msg',"Record Added Successfully...!!!");
				redirect('sales');
			}
			else
			{			
				$data['title'] = "Ki-Admin : : Add New sales";
				$this->page('sales/sales_add',$data);
			}
		}
	}
	public function viewsales($id)
	{
		if($this->sales_model->id_check($id)==0 || !is_numeric($id))
		{
			$this->session->set_userdata('err',"Record Is Not Available...!!!");
			redirect('sales');
		}
		$data['title'] = "Ki-Admin : : View sales";
		$data['sales'] = $this->sales_model->view_sales($id);		
		$data['item'] = $this->sales_model->view_sales_item($id);
		$this->page('sales/sales_view',$data);
	}
	public function status()
	{
		$data['title'] = "Ki-Admin : : Cateory Listing";
		$data['status']=$this->input->post('status');
		$data['sales']=$this->sales_model->status_wise();
		$this->page('sales/sales_list',$data);				
	}
	public function del_Order_item($id="",$oid="")
	{
		$this->order_model->deleteOrderDetail($id);
		$this->session->set_userdata('msg',"Item Deleted Successfully...!!!");
		redirect("sales/addsales");
	}*/
}
?>