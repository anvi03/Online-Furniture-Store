<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Banner extends CI_Controller {
		
		public function __construct()
		{
			parent::__construct();
            $this->load->model('banner_model');
			$this->checkSession();
			
		}
		
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
	
		public function index()
		{
			
        	 $data['banner_list'] = $this->banner_model->get_banner();
			 $data['title'] = "Banner";
			 $data['page'] = 'banner/banner_list';
			 $this->load->view('templates/content',$data);

		}
		
		public function create()
		{
			$this->form_validation->set_rules('title','Title','trim|required|min_length[3]');
			
			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				$data['title'] = "Banner";
				$data['page'] = 'banner/add_banner';
				$this->load->view('templates/content',$data);
			}
			else
			{
				$title = $this->input->post('title');
				//$desc = $this->input->post('desc');
				$status = $this->input->post('status');
				//$date = $this->input->post('created');
				
				$config['upload_path'] = '../uploads/banner/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('image');
				if($res)
				{
					$image=$this->upload->data();
					$this->banner_model->set_banner($title,$status,$image['file_name']);
					$this->session->set_userdata('msg','Banner Added Successfully!!!');
					redirect('banner');
				}
				else
				{
					$err=$this->upload->display_errors('<p>','</p>');
					$data['title'] = "Banner";
					$data['page'] = 'banner/add_banner';
					$this->session->set_userdata('imgerror',$err);
					$this->load->view('templates/content',$data);
				}
			}
		}
		
		public function edit_banner($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('banner');
			}
			else
			{
				$this->session->set_flashdata('id',$id);
			
				$data['banner'] = $this->banner_model->get_data($id);
				if($data['banner']==FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('banner');
				}
				else
				{
					$data['title'] = "Banner";
					$data['page'] = 'banner/edit_banner';
					$this->load->view('templates/content',$data);
				}
				
			}
		}
		
		public function updatebanner()
		{
			$id = $this->input->post('id');
			$this->form_validation->set_rules('title','Title','required');
			//$this->form_validation->set_rules('desc','Description','required');
			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				redirect("banner/updatebanner/".$this->session->flashdata('id'));
			}
			else
			{
				$title = $this->input->post('title');
				//$desc = $this->input->post('desc');
				$status = $this->input->post('status');
				//$date = $this->input->post('created');
				
				$config['upload_path'] = '../uploads/banner/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('image');
				if($res == "")
				{
					$this->banner_model->update_banner($id,$title,$status);
					$this->session->set_userdata('msg','Banner Updated Successfully!!!');
					redirect('banner');	
				}
				else
				{
					$res= $this->banner_model->get_img($id);
					$img = $res[0]->image;
					unlink("../uploads/banner/$img");
					$image=$this->upload->data();
					$this->banner_model->update_img_banner($id,$title,$status,$image['file_name']);
					$this->session->set_userdata('msg','Banner Updated Successfully!!!');
					redirect('banner');	
				}
			}
		}
		
		public function deletebanner($id=NULL)
		{
			if($id=="")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('banner');
			}
			else
			{
				$res= $this->banner_model->get_img($id);
				if($res == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');	
				}
				else
				{
					$img = $res[0]->image;
					unlink("../uploads/banner/$img");
					$this->banner_model->delete_banner($id);
					$this->session->set_userdata('msg','Banner Deleted Successfully!!!');
				}
				redirect('banner');
			}
		}
		public function bannerview($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('banner');

			}
			else
			{
				$data['banner'] = $this->banner_model->per_banner($id);
				if($data['banner'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('banner');

				}
				else
				{	
					$data['title'] = "Banner";
					$data['page'] = 'banner/view_banner';
					$this->load->view('templates/content',$data);
				}
			}

		}
		
		
		public function checkBox()
		{				
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["enable"]) && $_POST["enable"]=="Enable Selected")
					{
						$this->banner_model->enable_banner($value);					
						$v="Selected Record Enabled Successfully...!!!";
					}
					else if( isset($_POST["disable"]) && $_POST["disable"]=="Disable Selected")
					{
						$this->banner_model->disble_banner($value);		
						$v="Selected Record Disabled Successfully...!!!";							
					}
					else if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->banner_model->delete_banner_all($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('banner');	
			}
			redirect('banner');	
		}
		
	}
?>