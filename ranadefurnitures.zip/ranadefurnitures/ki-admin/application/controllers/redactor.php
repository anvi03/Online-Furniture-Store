<?php
if( ! defined('BASEPATH')) exit('No direct script access allowed');
class Redactor extends CI_Controller
{
	function upload_image()
    {
        $config['upload_path'] = '../uploads/redactor';
        $config['allowed_types'] = 'gif|jpg|png';

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('file'))
        {
            $error = array('error' => $this->upload->display_errors());
            echo stripslashes(json_encode($error));
        }
        else
        {
            $data = $this->upload->data();

            //upload successful generate a thumbnail
            $config['image_library'] = 'gd2';
            $config['source_image'] = 'uploads/redactor/full/'.$data['file_name'];
            $config['new_image'] = 'uploads/redactor/thumbnails/'.$data['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = TRUE;
            $config['width']     = 75;
            $config['height']   = 50;

            $this->load->library('image_lib', $config); 

            $this->image_lib->resize();

            
            $data = array('filelink' => base_url('../uploads/redactor/'.$data['file_name']), 'filename'=>$data['file_name']);
            echo stripslashes(json_encode($data));
        }
    }

    function upload_file()
    {
        $config['upload_path'] = 'uploads/redactor';
        $config['allowed_types'] = '*';

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('file'))
        {
            $error = array('error' => $this->upload->display_errors());
            echo stripslashes(json_encode($error));
        }
        else
        {
            $data = $this->upload->data();
            $data = array('filelink' => base_url('uploads/redactor/'.$data['file_name']), 'filename'=>$data['file_name']);
            echo stripslashes(json_encode($data));
        }
    }

    function get_images()
    {
        $files = get_filenames('uploads/redactor/thumbnails');

        $return = array();
        foreach($files as $file)
        {
            $return[] = array('thumb'=>base_url('uploads/redactor/thumbnails/'.$file), 'image'=>base_url('uploads/redactor/images/'.$file));
        }
        echo stripslashes(json_encode($return));
    }
	function image_unlink($str)
	{
		$dir = './uploads/redactor/';
		if(isset($str))
		{
			$img=$str;
			if(file_exists($dir.$img))
			{
				unlink($dir.$img);
			}
		}
	}
}
?>