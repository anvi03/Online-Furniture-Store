<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
	class Cms extends CI_Controller
	{
		public function __construct()
		{
			parent :: __construct();
			$this->checkSession();
			$this->load->model('cms_model');
		}
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
		public function index()
		{
			
			$data['cms'] = $this->cms_model->cms_list();
			$data['title'] = "CMS";
			$data['page'] = 'cms/cms_list';
			$this->load->view('templates/content',$data);
		}
		public function create()
		{
			$this->form_validation->set_rules('title','Title','required|min_length[3]|max_length[25]');
			$this->form_validation->set_rules('page_url_key','Page Url Key','required|min_length[3]||is_unique[cms.page_url_key]');
			$this->form_validation->set_rules('status','Status','required');
			$this->form_validation->set_rules('metakeywords','Metakeywords','required|min_length[3]|max_length[225]');
			$this->form_validation->set_rules('metadesc','Metadesc','required|min_length[3]');
			
			
			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				$data['title']="CMS";
				$data['page'] = 'cms/add_page';
				$this->load->view('templates/content',$data);
			}
			else
			{
				$title = $this->input->post('title');
				$page_url_key = $this->input->post('page_url_key');
				$status = $this->input->post('status');
				$content = $this->input->post('content');
				$metakeywords = $this->input->post('metakeywords');
				$metadesc = $this->input->post('metadesc');
				
				
				$this->cms_model->set_cms($title,$page_url_key,$status,$content,$metakeywords,$metadesc);
				$this->session->set_userdata('msg','Page Added Successfully!!!');
				redirect('cms');


			}

		}
		
				
		public function edit_page($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');				
				redirect('cms');
	
			}
			else
			{
				$this->session->set_flashdata('id',$id);
				$data['page_data'] = $this->cms_model->get_data($id);
				if($data['page_data'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');				
					redirect('cms');

				}
				else
				{
					$data['title'] = "CMS";
					$data['page'] = 'cms/edit_page';
					$this->load->view('templates/content',$data);
				}
				
			}
			
		}

		
		public function update_page()
		{
			$id = $this->input->post('id');
			$this->form_validation->set_rules('title','Title','required|min_length[3]|max_length[25]');
			$this->form_validation->set_rules('page_url_key','Page Url Key','required|min_length[3]');
			$this->form_validation->set_rules('content','Content','required|min_length[3]');
			$this->form_validation->set_rules('metakeywords','Meta Keywords','required|min_length[3]|max_length[225]');
			$this->form_validation->set_rules('metadesc','Meta Desc','required|min_length[3]');


			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				redirect("cms/edit_page/".$id);
			}
			else
			{
				$title = $this->input->post('title');
				$page_url_key = $this->input->post('page_url_key');
				$status = $this->input->post('status');
				$content = $this->input->post('content');
				$metakeywords = $this->input->post('metakeywords');
				$metadesc = $this->input->post('metadesc');
				
					$this->cms_model->update_page($id,$title,$page_url_key,$status,$content,$metakeywords,$metadesc);
					$this->session->set_userdata('msg','Page Updated Successfully!!!');
					redirect('cms');	
			}
		}
		
		
		public function deletepage($id=NULL)
		{
			if($id=="")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('cms');
			}
			else
			{
				$res= $this->cms_model->get_page($id);
				if($res == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('cms');	
				}
				else
				{
					$this->cms_model->delete_page($id);
					$this->session->set_userdata('msg','Page Deleted Successfully!!!');
				}
				redirect('cms');
			}
			
		}
		
		
		
		
		public function pageview($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('cms');

			}
			else
			{
				$data['cms'] = $this->cms_model->per_page($id);
				if($data['cms'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('cms');

				}
				else
				{	
					$data['title'] = "CMS";
					$data['page'] = 'cms/view_page';
					$this->load->view('templates/content',$data);
				}
			}

		}
		
		
		
		public function checkBox()
		{				
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["enable"]) && $_POST["enable"]=="Enable Selected")
					{
						$this->cms_model->enable_cms($value);					
						$v="Selected Record Enabled Successfully...!!!";
					}
					else if( isset($_POST["disable"]) && $_POST["disable"]=="Disable Selected")
					{
						$this->cms_model->disble_cms($value);		
						$v="Selected Record Disabled Successfully...!!!";							
					}
					else if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->cms_model->delete_cms($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('cms');	
			}
			redirect('cms');	
		}
		public function unlink_image($str)
		{
			$dir = '../uploads/redactor/';
			$img=$str;
			if(file_exists($dir.$img))
			{
				unlink($dir.$img);
			}
		}
	}
?>