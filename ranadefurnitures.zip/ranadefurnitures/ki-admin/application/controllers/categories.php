<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Categories extends CI_Controller
	{
		public function __construct()
		{
			parent :: __construct();
			$this->checkSession();
			$this->load->model('categories_model');
		}
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
		public function index()
		{
		
			$data['categories'] = $this->categories_model->get_categories();
			$data['categories_data'] = $this->categories_model->get_parent();
			
			$data['title']="Categories";
			$data['page'] = 'categories/categories_view';
			$this->load->view('templates/content',$data);
			
		}
		public function create()
		{	
			$this->form_validation->set_rules('c_name','Categories Name','required|alpha_numeric|min_length[3]|max_length[20]');
			//$this->form_validation->set_rules('desc','Description','required');
			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				$data['categories'] = $this->categories_model->get_categories();
				$data['title']="Categories";
				$data['page'] = 'categories/add_categories';
				$this->load->view('templates/content',$data);
			}
			else
			{
				$c_name = $this->input->post('c_name');
				//$desc = $this->input->post('desc');
				$status = $this->input->post('status');
				$parent_id = $this->input->post('parent_id');
				
				$config['upload_path'] = '../uploads/categories/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('c_image');
				if($res)
				{
					$image=$this->upload->data();
					$this->categories_model->set_categories($c_name,$parent_id,$status,$image['file_name']);
					$this->session->set_userdata('msg','Category Added Successfully!!!');
					redirect('categories');
				}
				else
				{
					$err=$this->upload->display_errors('<p>','</p>');
					
					$data['title']="Categories";
					$data['page'] = 'categories/add_categories';
					$this->session->set_userdata('imgerror',$err);
					$this->load->view('templates/content',$data);
				}
			}
		}
		public function editcategories($id=NULL)
		{
			$this->session->set_flashdata('id',$id);
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('categories');
			}
			else
			{
				$data['categories'] = $this->categories_model->categories_data($id);
				if($data['categories'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('categories');
				}
				else
				{
					$data['title']="Categories";
					$data['page'] = 'categories/edit_categories';
					$this->load->view('templates/content',$data);
				}
			}

		}
		public function updatecategories()
		{
			$id = $this->input->post('c_id');
			$this->form_validation->set_rules('c_name','Categories Name','required|alpha_numeric|min_length[3]|max_length[20]');
			$this->form_validation->set_rules('status','Status','required');
			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				redirect("categories/editcategories/".$this->session->flashdata('id'));
			}
			else
			{
				$name = $this->input->post('c_name');
				//$desc = $this->input->post('desc');
				$status = $this->input->post('status');
				//$date = $this->input->post('created');
				
				$config['upload_path'] = '../uploads/categories/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('image');
				if($res == "")
				{
					$this->categories_model->update_categories($id,$name,$status);
					$this->session->set_userdata('msg','Category Updated Successfully!!!');
					redirect('categories');	
				}
				else
				{
					$res= $this->categories_model->get_img($id);
					$img = $res[0]->c_image;
					unlink("../uploads/categories/$img");
					$image=$this->upload->data();
					$this->categories_model->update_img_categories($id,$name,$status,$image['file_name']);
					$this->session->set_userdata('msg','categories Updated Successfully!!!');
					redirect('categories');	
				}
			}
		}

		public function deletecategories($id =NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');				
				redirect('categories');
			}
			else
			{
				$res= $this->categories_model->get_img($id);
				if($res == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
				}
				else
				{
					$img = $res[0]->c_image;
					unlink("../uploads/categories/$img");
					$this->categories_model->delete_categories($id);

					$this->session->set_userdata('msg','Category Delete Successfully!!!');
					
				}
				redirect('categories');
			}

		}
		
		public function categoryview($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');				
				redirect('categories');

			}
			else
			{
				$data['categories'] = $this->categories_model->per_category($id);
				if($data['categories'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');				
					redirect('categories');

				}
				else
				{	
					$data['title']="Categories";
					$data['page'] = 'categories/view_category';
					$this->load->view('templates/content',$data);
				}
			}
	
		}
		
		public function checkBox()
		{				
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["enable"]) && $_POST["enable"]=="Enable Selected")
					{
						$this->categories_model->enable_categories($value);					
						$v="Selected Record Enabled Successfully...!!!";
					}
					else if( isset($_POST["disable"]) && $_POST["disable"]=="Disable Selected")
					{
						$this->categories_model->disble_categories($value);		
						$v="Selected Record Disabled Successfully...!!!";							
					}
					else if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->categories_model->delete_category($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('categories');	
			}
			redirect('categories');	
		}
		
	}
?>