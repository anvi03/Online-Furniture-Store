<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Forgot extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('email');	
	}
	public function forget_view()
	{
 	
		$this->load->view('forgot_password');
	}
	public function retrive_pwd()
	{
			
			$data['title']='Forgot';
			$uname=$this->input->post('username');
			$email=$this->input->post('email');
			/*echo $uname;
			echo $email;
			die;*/
			$this->load->model('forgot_model');
			$result=$this->forgot_model->retrive($uname,$email);
			//echo "<pre>";print_r($result);die;
			if($result == TRUE)
			{
				
				$npwd=random_string('alnum','6');
				$qry=$this->forgot_model->generated($npwd,$uname,$email);
				if($qry==TRUE)
				{
				echo $email;
				die();
					try
					{
					$my_mail='khushboomulatani@gmail.com';
							$config = Array(
						  'protocol' => 'smtp',
						  'smtp_host' => 'ssl://smtp.googlemail.com',
						  'smtp_port' => 465,
						  'smtp_user' => $my_mail, // change it to yours email id
						  'smtp_pass' => '9825628786', // change it to yours password
						  'mailtype' => 'html',
						  'charset' => 'iso-8859-1',
						  'wordwrap' => TRUE
							);
						
						
								$message = $npwd.' now this is your new password please login in and change it again....now it self';
						
							  $this->load->library('email', $config);
							  $this->email->set_newline("\r\n");
						
							  $this->email->from($my_mail); // change it to yours smtp user and  from should be same
						
							  $this->email->to($email);// change it to yours
						
							  $this->email->subject('mail to change password');
						
							  $this->email->message($message);
							
							  if($this->email->send())
								 {
									 
								$this->session->set_userdata('msg',"Password send on email");
								redirect('login');
								 }
							 else
								{
									$this->session->set_userdata('err',"something went wrong!!");
									$this->forget_view();
								}
					}
					catch(Exception $e)
					{
						$this->session->set_userdata('err',"something went wrong!!");
						$this->forget_view();
					}
				}
						
				else
				{
					$this->session->set_userdata('err',"wrong username or email");
					$this->forget_view();
				}
				
			}
			else
			{
				$this->session->set_userdata('err',"wrong data");
				$this->forget_view();
			}
			//$this->load->view('news_view',$result);
			//$data['page'] = 'pages/forgot_pwd';
			//$this->load->view('templates/content',$data);;
		
	}

}

?>