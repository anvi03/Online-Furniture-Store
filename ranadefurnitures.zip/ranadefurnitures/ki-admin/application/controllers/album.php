<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Album extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('album_model');
	}
	
	public function index()
	{
		$data['title']="Album List";
		$data['album']=$this->album_model->getAlbums();
		$this->load->view('gallery/album_list',$data);
	}
	public function view($album_id)
	{
		$data['title']="Photos List";
		$data['photo']=$this->album_model->getPhotos($album_id);
		$this->load->view('gallery/photo_list',$data);
	}
	public function add()
	{
		$this->load->view('gallery/album_add');
	}
	public function create()
	{
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_width']  = '1024';
		$config['max_height']  = '768';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('image'))
		{
			$data = array('error' => $this->upload->display_errors());
			$this->load->view('gallery/album_add', $data);
		}
		else
		{
			$arr = $this->upload->data();
			$imageName = $arr['file_name'];
			$foo = $this->album_model->insert_album($imageName);
			if($foo)
			{
				redirect('album');
			}
		}
	}
	public function addimages($album_id)
	{
		
		if(!is_dir('./uploads/album/'.$album_id))
		{
			mkdir('./uploads/album/'.$album_id,0755,true);
			mkdir('./uploads/album/'.$album_id.'/full',0755,true);
			mkdir('./uploads/album/'.$album_id.'/thumbs',0755,true);
			
		}
		$config['upload_path'] = './uploads/album/'.$album_id.'/full';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_width']  = '5000';
		$config['max_height']  = '5000';
		$config['max_size'] = 2048;
		$config['encrypt_name'] =  TRUE;

		$this->load->library('upload', $config);
		 
		$i = 0;
		foreach($_FILES as $key=>$val)
		{
			$cnt = count($_FILES['image']['name']);
			for($j=0;$j<$cnt;$j++)
			{
				$img['name'] = $val['name'][$i];
				$img['type'] = $val['type'][$i];
				$img['tmp_name'] = $val['tmp_name'][$i];
				$img['error'] = $val['error'][$i];
				$img['size'] = $val['size'][$i];
				
				//echo "<pre>"; print_r($img); 
				//$this->upload->do_upload_ki($img);
				$i++;
				if ( ! $this->upload->do_upload_ki($img))
				{
					$this->session->set_userdata('err',$this->upload->display_errors());
					
					redirect('album/view/'.$album_id);
				}
				else
				{
					$arr = $this->upload->data();
					$imageName = $arr['file_name'];
					$this->upload->resize($imageName,$config['upload_path'],'./uploads/album/'.$album_id.'/thumbs/');
					
					
					$res = $this->album_model->add_image($imageName,$album_id);
					
				}
				
			}
		}
		redirect('album/view/'.$album_id);
	
	}
}
