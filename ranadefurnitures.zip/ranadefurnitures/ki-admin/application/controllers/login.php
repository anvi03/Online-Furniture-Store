<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Login extends CI_Controller{
	
		public function index()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(isset($isloggedin) && $isloggedin == TRUE)
			{
				
				redirect('dashboard');
			}
			else
			{
				$this->load->view('login-form');
			}
		}
		
		public function validate_login()
		{
			$this->load->model('login_model');
			
		
			$query = $this->login_model->validate();
			if ($query)
			{	
				$this->session->set_userdata('username',$this->input->post('user'));
				$this->session->set_userdata('is_logged_in',TRUE);
				redirect('dashboard');
			}
			else
			{
				$this->session->set_userdata('err','Invalid Username or Password');
				redirect();
			}
		}
	}
?>