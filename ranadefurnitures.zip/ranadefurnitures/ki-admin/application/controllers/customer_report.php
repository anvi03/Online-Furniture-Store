<?php
if(!defined('BASEPATH')) exit('No direct script access allowed.');
	class Customer_report extends CI_Controller
	{
		public function __construct()
		{	
			parent::__construct();
			$this->session->userdata('is_logged_in');
			$this->load->model('cust_report_model');
		}
		public function index()
		{
			$data['arrobj'] = $this->cust_report_model->getcustomer();
			foreach($data['arrobj'] as $a)
			{
				$arr[]= $this->cust_report_model->get_total($a['id']);
			}
			foreach($arr as $a)
			{
				$tot[]= $a[0]['total'];
			}
		
			$data['total']=$tot;
			/*$result['page']='report/customer';
			$this->load->view('templates/content',$result);*/
			/*echo "<pre>";
			print_r($data['total']);
			die;*/
			$data['page'] = "reports/customer";
			$this->load->view('templates/content',$data);
		}
		public function getPdf()
		{
			$t =0;
			$data['arrobj'] = $this->cust_report_model->getcustomer();
			foreach($data['arrobj'] as $a)
			{
				$arr[]= $this->cust_report_model->get_total($a['id']);
			}
			foreach($arr as $a)
			{
				$tot[]= $a[0]['total'];
				
				
			}
			$total = array_sum($tot);
			//$data['total'] = $tot;
			//echo "<pre>";print_r($data['total']);
		$this->load->model('fpdf');
		$this->fpdf->AddPage();
		$this->fpdf->SetFont('Arial','B',26);
		$this->fpdf->cell(88,20,"Customer Report",'','','L');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(56,20,"Date : ".date('Y/m/d'),'','','L');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(40,20,"Total Sales Amount : ".$total,'',1,'C');		
						
		$this->fpdf->SetLineWidth(.3);
		//$data['total']=$tot;
		$data['arrobj'];		
		$this->fpdf->SetFont('Arial','B',10);
        $this->fpdf->Cell(10,8,"id",1,'','C');
		$this->fpdf->Cell(30,8,"customer Name",1,'','C');
		//$this->fpdf->Cell(20,8,"Address",1,'','C');
		$this->fpdf->Cell(50,8,"email",1,'','C');
		$this->fpdf->Cell(40,8,"Mobile No",1,'','C');
		//$this->fpdf->Cell(40,8,"created",1,1,'C');
		$this->fpdf->Cell(40,8,"Total Amount",1,1,'C');
    	//$this->fpdf->Ln();	
		$this->fpdf->SetFillColor(500,500,500);
	    $this->fpdf->SetTextColor(0);
    	$this->fpdf->SetFont('');
		$fill = false;
		$i=0;
		foreach($data['arrobj'] as $row)
		{
			$this->fpdf->Cell(10,8,number_format($row['id']),'LR',0,'C',$fill);
			$this->fpdf->Cell(30,8,ucfirst($row['firstname']),'LR',0,'C',$fill);
			//$this->fpdf->Cell(20,8,ucfirst($row['address']),'LR',0,'C',$fill);
			$this->fpdf->Cell(50,8,ucfirst($row['email']),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,ucfirst($row['mobile_no']),'LR',0,'C',$fill);
			//$this->fpdf->Cell(40,8,ucfirst($row['created']),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,number_format($tot[$i]),'LR',0,'C',$fill);
			$this->fpdf->Ln();
			$fill = !$fill;
			$i++;
		}		
		$this->fpdf->Cell(190,0,"",1,'','C');
		$this->fpdf->Output();																
		}
		
		public function checkBox()
		{
			$this->load->model('cust_report_model');	
		//$this->load->model("news_model");		
		if(isset($_POST['chk']))
		{
			foreach($this->input->post('chk') as $value)
			{
				/*if(isset($_POST["enable"]) && $_POST["enable"]=="Enable Selected")
				{
					$this->contact_model->enable_news($value);					
					$v="Selected Record Enabled Successfully...!!!";
				}
				else if(isset($_POST["disable"]) && $_POST['disable']=="Disable Selected")
				{
					$this->contact_model->disble_news($value);		
					$v="Selected Record Disabled Successfully...!!!";							
				}
				else*/if(isset($_POST["delete"]) && $_POST['delete']=="Delete Selected")
				{
					$this->cust_report_model->delete_news($value);

					$v="Selected Record Deleted Successfully...!!!";	
				}
			}						
			$this->session->set_userdata('msg',$v);
			redirect('customer_report');	
		}
		redirect('contact');
		//$this->index();		
		}	
		public function delete($id=NULL)
		{	
			$this->load->model('cust_report_model');
			$result=$this->cust_report_model->delete($id);
			if($result==false)
			{
				redirect('customer_report');	
			}
			else
			{
				$this->session->set_userdata('succ','record deleted successfully...');	
				redirect('customer_report');
			}
			
		}
	}

?>