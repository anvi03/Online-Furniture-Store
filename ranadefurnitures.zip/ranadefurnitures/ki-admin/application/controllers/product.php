<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Product extends CI_Controller
	{
		public function __construct()
		{
			parent :: __construct();
			$this->checkSession();
			$this->load->model('product_model');
			$this->load->model('image_model');
		}
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
		public function index()
		{	
			$data['product'] = $this->product_model->product_view();
			$data['title'] = "Product";
			$data['page'] = 'product/product_view';
			$this->load->view('templates/content',$data);
		}
		public function view_categories($id)
		{	
			$this->session->set_flashdata('id',$id);
			$data['product'] = $this->product_model->get_product($id);
			$data['title'] = "Product";
			$data['page'] = 'product/product_view';
			$this->load->view('templates/content',$data);

		}
		public function editproduct($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');				
				redirect('product');
	
			}
			else
			{
				$this->session->set_flashdata('id',$id);
				$data['product'] = $this->product_model->category_id();
				$data['product'] = $this->product_model->product_data($id);
				if($data['product'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');				
					redirect('product');

				}
				else
				{
					$data['title'] = "Product";
					$data['page'] = 'product/edit_product';
					$this->load->view('templates/content',$data);
				}
			}
		}
		public function updateproduct()
		{
			$id = $this->input->post('p_id');
			$this->form_validation->set_rules('p_name','Name','required|alpha_numeric|min_length[3]|max_length[20]');
			$this->form_validation->set_rules('p_desc_long','Description Long','required');
			$this->form_validation->set_rules('p_desc_short','Description Short','required');
			$this->form_validation->set_rules('p_price','price','required|numeric');
			$this->form_validation->set_rules('p_qty','Quantity','required|numeric');

			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				redirect("product/editproduct/".$this->session->flashdata('id'));
			}
			else
			{
				$name = $this->input->post('p_name');
				$desc_long = $this->input->post('p_desc_long');
				$desc_short = $this->input->post('p_desc_short');
				$status = $this->input->post('status');
				$qty = $this->input->post('p_qty');
				//$date = $this->input->post('created');
				
				$config['upload_path'] = '../uploads/product/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('image');
				if($res == "")
				{
					$this->product_model->update_product($id,$name,$desc_long,$desc_short,$status,$qty);
					$this->session->set_userdata('msg','product Updated Successfully!!!');
					redirect('product');	
				}
				else
				{
					$res= $this->product_model->get_img($id);
					$img = $res[0]->p_image;
					unlink("../uploads/product/$img");
					$image=$this->upload->data();
					$this->product_model->update_img_product($id,$name,$desc_long,$desc_short,$status,$qty,$image['file_name']);
					$this->session->set_userdata('msg','product Updated Successfully!!!');
					redirect('product');	
				}
			}
		}
		public function deleteproduct($id=NULL)
		{
			
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');				
				redirect('product');

			}
			else
			{
				$res= $this->product_model->get_img($id);
				if($res == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');				
					redirect('product');

				}
				else
				{
					$img = $res[0]->p_image;
					unlink("../uploads/product/$img");
					$this->product_model->delete_product($id);
					$this->session->set_userdata('msg','product Deleted Successfully!!!');
					
				}
				redirect('product');
			}
		}
		
		
		public function create()
		{
			$this->form_validation->set_rules('p_name','Name','required|alpha_numeric|min_length[3]|max_length[20]');
			$this->form_validation->set_rules('desc_long','Description Long','required');
			$this->form_validation->set_rules('desc_short','Description short','required');
			$this->form_validation->set_rules('price','Price','required|numeric');
			$this->form_validation->set_rules('p_qty','Quantity','required|numeric');

			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				$data['categories'] = $this->product_model->category_id();
				$data['title'] = "Product";
				$data['page'] = 'product/add_product';
				$this->load->view('templates/content',$data);
			}
			else
			{
				$name = $this->input->post('p_name');
				$desc_long = $this->input->post('desc_long');
				$desc_short = $this->input->post('desc_short');
				$status = $this->input->post('status');
				$price = $this->input->post('price');
				$c_id = $this->input->post('c_id');
				$qty = $this->input->post('p_qty');
				
				
				$config['upload_path'] = '../uploads/product/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('image');
				if($res)
				{
					$image=$this->upload->data();
					$this->product_model->set_product($name,$price,$desc_long,$desc_short,$status,$qty,$image['file_name'],$c_id);
					$this->session->set_userdata('msg','Product Added Successfully!!!');
					redirect('product');
				}
				else
				{
					$err=$this->upload->display_errors('<p>','</p>');
					$data['title'] = "Product";
					$data['page'] = 'product/add_product';
					$this->session->set_userdata('imgerror',$err);
					$this->load->view('templates/content',$data);
				}
			}
		}
		public function productview($id=NULL)
		{
			if($id == "")
			{
					$this->session->set_userdata('err','Record Not Found!!!');				
					redirect('product');

			}
			else
			{
				$data['product'] = $this->product_model->per_product($id);
				$data['product_data'] = $this->image_model->getPhotos($id);
				if($data['product'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');				
					redirect('product');

				}
				else
				{	
					$data['title'] = "Product";
					$data['page'] = 'product/view_product';
					$this->load->view('templates/content',$data);
				}
			}

		}
		
		
		public function addimages()
		{
			$p_id=$this->input->post('p_id');
			if(!is_dir('../uploads/product/'.$p_id))
			{
				mkdir('../uploads/product/'.$p_id,0755,true);
				mkdir('../uploads/product/'.$p_id.'/full',0755,true);
				mkdir('../uploads/product/'.$p_id.'/thumbs',0755,true);
				
			}
				
				$config['upload_path'] = '../uploads/product/'.$p_id.'/full';
				
				$config['allowed_types'] = 'gif|jpg|png|jpeg';
				$config['max_width']  = '5000';
				$config['max_height']  = '5000';
				$config['max_size'] = 2048;
				$config['encrypt_name'] =  TRUE;
				
	
			$c = $this->load->library('upload', $config);
			
			 
			$i = 0;
			foreach($_FILES as $key=>$val)
			{
									
				$cnt = count($_FILES['image']['name']);
				//echo "<pre>";print_r($cnt);
				for($j=0;$j<$cnt;$j++)
				{
				
					$img['name'] = $val['name'][$i];
					$img['type'] = $val['type'][$i];
					$img['tmp_name'] = $val['tmp_name'][$i];
					$img['error'] = $val['error'][$i];
					$img['size'] = $val['size'][$i];
					
					//echo "<pre>"; print_r($img); 
					//$this->upload->do_upload_ki($img);die;
					$i++;
					
					if ( ! $this->upload->do_upload_ki($img))
					{
					
						
						$this->session->set_userdata('err',$this->upload->display_errors());
						
						
						redirect('product/productview/'.$p_id);
					}
					else
					{
						
						$arr = $this->upload->data();
						
						$imageName = $arr['file_name'];
						
						$this->upload->resize($imageName,$config['upload_path'],'../uploads/product/'.$p_id.'/thumbs/');
						
						$res = $this->image_model->add_image($imageName,$p_id);
						
						$this->session->set_userdata('msg',"Images Added SuccesFully");
					}
					
				}
				
			}
			redirect('product/productview/'.$p_id);
	
	}
	
	
	
		
		
				
		public function productlist()
		{
				$id=$this->uri->segment(3);
				
				$result=$this->product_model->get_details($id);
				//echo "<pre>";print_r($result);die;
				
				$query=$this->image_model->getPhotos($id);
				if(empty($result))
					{
						
						$this->session->set_userdata('producterror','NO RECORD FOUND');
						$data['product']=$result;
						$data['page']='product/view_product';
						$this->load->view('templates/content',$data);
					}
					else
					{
					
						//$id=$result->p_id;
						
						$data['num']=$query->num_rows();
						//echo "<pre>";print_r($data['num']);die;
						$data['img']=$query->result();	
						$data['product']=$result;
						//echo "<pre>";print_r($data['product']);die;
						$data['page']='product/view_product';
						$this->load->view('templates/content',$data);
					}
				
		}
		
		public function deleteimage($image_id)
		{
			//$p_id=$this->uri->segment(3);
			if($image_id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');				
				redirect('product/productview');

			}
			else
			{
				$res= $this->image_model->getPhotos_delete($image_id);
				$p_id = $res[0]->p_id;
				if($res == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');				
					redirect('product/productview/'.$p_id);

				}
				else
				{
					$img = $res[0]->image;
					unlink("../uploads/product/$p_id/thumbs/$img");
					unlink("../uploads/product/$p_id/full/$img");
					$this->image_model->delete_image($image_id);
					$this->session->set_userdata('msg','product Deleted Successfully!!!');
					
				}
				redirect('product/productview/'.$p_id);
			}
		}
		
		public function checkBox()
		{				
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["enable"]) && $_POST["enable"]=="Enable Selected")
					{
						$this->product_model->enable_product($value);					
						$v="Selected Record Enabled Successfully...!!!";
					}
					else if( isset($_POST["disable"]) && $_POST["disable"]=="Disable Selected")
					{
						$this->product_model->disble_product($value);		
						$v="Selected Record Disabled Successfully...!!!";							
					}
					else if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->product_model->delete_product_all($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('product');	
			}
			redirect('product');	
		}
	
	}
?>