<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	 
	class Contacts extends CI_Controller
	{
		public function __construct()
		{
			parent :: __construct();
			$this->checkSession();
			$this->load->model('contacts_model');
		}
		
		
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
		
		public function index()
		{
			$data['contact'] = $this->contacts_model->get_contacts();
			$data['title'] = "Contacts";
			$data['page'] = 'contacts/contact_view';
			$this->load->view('templates/content',$data);
		}
		
		public function deletecontact($id = NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('contacts');
			}
			else
			{
				$data = $this->contacts_model->delete_contact($id);
				if($data == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
				}
				else
				{
					$this->session->set_userdata('msg','Contact Deleted Successfully!!!');
				}
					redirect('contacts');
			}
		}
		
		public function contactview($id=NULL)
		{
			if($id =="")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('contacts');
			}
			else
			{
				$data['contact'] = $this->contacts_model->per_contact($id);
				if($data['contact'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('contacts');

				}
				else
				{
					$data['title'] = "Contacts";
					$data['page'] = 'contacts/per_contact';
					$this->load->view('templates/content',$data);
				}
				
			}
		}
		
		public function checkBox()
		{				
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->contacts_model->delete_contact_all($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('contacts');	
			}
			redirect('contacts');	
		}

	}
?>