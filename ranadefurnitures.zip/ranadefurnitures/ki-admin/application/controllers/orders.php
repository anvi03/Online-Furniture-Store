<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	 
	class Orders extends CI_Controller
	{
		public function __construct()
		{
			parent :: __construct();
			$this->checkSession();
			$this->load->model('orders_model');
		}
		
		
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
		
		public function index()
		{
			$data['orders'] = $this->orders_model->get_total_orders();
			//echo "<pre>";print_r($data['orders']);die;
			$data['title'] = "Orders";
			$data['page'] = 'orders/order_list';
			$this->load->view('templates/content',$data);
		}
		
		public function deleteorder($id = NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('orders');
			}
			else
			{
				$data = $this->orders_model->delete_order($id);
				if($data == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
				}
				else
				{
					$this->session->set_userdata('msg','Contact Deleted Successfully!!!');
				}
					redirect('orders');
			}
		}
		
		public function orderview($id=NULL)
		{
			if($id =="")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('orders');
			}
			else
			{
				$data['order'] = $this->orders_model->per_order($id);
				//echo "<pre>";print_r($data['order']);
				if($data['order'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('orders');

				}
				else
				{
					$data['title'] = "Orders";
					$data['page'] = 'orders/per_order';
					$this->load->view('templates/content',$data);
				}
				
			}
		}
		public function update_status($id)
   		{
		  //echo $id;die;
		  //echo $this->session->userdata('ord_no');
		  $sta= $this->input->post('status');
		  //echo $sta;die;
		  $bill_email=$this->session->userdata('bill_email');
			//echo $bill_email;
		  $res=$this->orders_model->update_status($id);
		  if($res)
		  {
			  $this->session->set_userdata('msg','Status Updated');
			 
			 /* Email*/
			  $my_mail='ashwubhakz@gmail.com';
								$config = Array(
							  'protocol' => 'smtp',
							  'smtp_host' => 'ssl://smtp.googlemail.com',
							  'smtp_port' => 465,
							  'smtp_user' => 'ashwubhakz@gmail.com', // change it to yours email id
							  'smtp_pass' => 'koibhiaurkuchbhi', // change it to yours password
							  'mailtype' => 'html',
							  'charset' => 'iso-8859-1',
							  'wordwrap' => TRUE
								);
							
							// foreach($cart as $rec)
								//	  {
									$message = ' your order is on '.$sta.'
									  from  Shree Ranadefurniture...';
									//}
									$this->load->library('email', $config);
								  $this->email->set_newline("\r\n");
							
								  $this->email->from('ashwubhakz@gmail.com'); // change it to yours smtp user and  from should be same
							
								  $this->email->to($bill_email);// change it to yours
							
								  $this->email->subject('Order Placed');
							
								  $this->email->message($message);
								
								  if($this->email->send())
									 {
									$this->session->set_userdata('msg',"Send on Email");
									
									//redirect('login/view_login');
									 }
								 else
									{
										$this->session->set_userdata('err',"something went wrong!!");
										//$this->forget_view();
									}
				
			
				
			  redirect("orders/");
		  }
	  
   }
		public function checkBox()
		{				
			
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->orders_model->delete_order_all($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('orders');	
			}
			redirect('orders');	
		}
		public function packing_slip($ord_no=NULL)
		{
			if($ord_no == "")
			{
				redirect('orders');
			}
			else
			{	
				$data['order'] = $this->orders_model->per_order($ord_no);
				//echo "<pre>";print_r($data['order']);die;
				$this->load->view('packing_slip_view',$data);
			}	
		}

	}
?>