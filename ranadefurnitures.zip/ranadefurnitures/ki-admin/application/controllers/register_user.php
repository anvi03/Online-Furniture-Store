<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	 
	class Register_User extends CI_Controller
	{
		public function __construct()
		{
			parent :: __construct();
			$this->checkSession();
			$this->load->model('register_user_model');
		}
		
		
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
		
		public function index()
		{
			$data['user'] = $this->register_user_model->get_user();
			//echo "<pre>";print_r($data['contact']);die;
			$data['title'] = "Contacts";
			$data['page'] = 'register_user/register_view';
			$this->load->view('templates/content',$data);
		}
		
		public function deleteuser($id = NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('register_user');
			}
			else
			{
				$data = $this->register_user_model->delete_user($id);
				if($data == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
				}
				else
				{
					$this->session->set_userdata('msg','User Deleted Successfully!!!');
				}
					redirect('register_user');
			}
		}
		
		public function userview($id=NULL)
		{
			if($id =="")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('register_user');
			}
			else
			{
				$data['user'] = $this->register_user_model->per_user($id);
				if($data['user'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('register_user');

				}
				else
				{
					$data['title'] = "Contacts";
					$data['page'] = 'register_user/per_register';
					$this->load->view('templates/content',$data);
				}
				
			}
		}
		
		public function checkBox()
		{				
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->register_user_model->delete_user_all($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('register_user');	
			}
			redirect('register_user');	
		}

	}
?>