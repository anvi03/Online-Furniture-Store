<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class News extends CI_Controller {
		
		public function __construct()
		{
			parent::__construct();
            $this->load->model('news_model');
			$this->checkSession();
			$this->load->library("pagination");
		    $this->load->library("table");

		}
		
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('err',"Permission Denied");
				redirect('login');
			}
		}
	
		public function index()
		{
			
        	 $data['news_list'] = $this->news_model->get_news();
			 $data['title'] = "News";
			 $data['page'] = 'news/news_list';
			 $this->load->view('templates/content',$data);

		}
		
		public function create()
		{
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('desc','Description','required');
			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				$data['title'] = "News";
				$data['page'] = 'news/add_news';
				$this->load->view('templates/content',$data);
			}
			else
			{
				$title = $this->input->post('title');
				$desc = $this->input->post('desc');
				$status = $this->input->post('status');
				$date = $this->input->post('created');
				
				$config['upload_path'] = '../uploads/news/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('image');
				if($res)
				{
					$image=$this->upload->data();
					$this->news_model->set_news($title,$desc,$status,$image['file_name']);
					$this->session->set_userdata('msg','News Added Successfully!!!');
					redirect('news');
				}
				else
				{
					$err=$this->upload->display_errors('<p>','</p>');
					$data['title'] = "News";
					$data['page'] = 'news/add_news';
					$this->session->set_userdata('imgerror',$err);
					$this->load->view('templates/content',$data);
				}
			}
		}
		
		public function updatenews($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('news');
			}
			else
			{
				$this->session->set_flashdata('id',$id);
			
				$data['news'] = $this->news_model->get_data($id);
				if($data['news']==FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('news');
				}
				else
				{
					$data['title'] = "News";
					$data['page'] = 'news/edit_news';
					$this->load->view('templates/content',$data);
				}
				
			}
		}
		
		public function editnews()
		{
			$id = $this->input->post('id');
			$this->form_validation->set_rules('title','Title','required');
			$this->form_validation->set_rules('desc','Description','required');
			
			if($this->form_validation->run() == false)
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				redirect("news/updatenews/".$this->session->flashdata('id'));
			}
			else
			{
				$title = $this->input->post('title');
				$desc = $this->input->post('desc');
				$status = $this->input->post('status');
				$date = $this->input->post('created');
				
				$config['upload_path'] = '../uploads/news/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['encrypt_name'] = TRUE;
				
				$this->load->library('upload',$config);
				$res=$this->upload->do_upload('image');
				if($res == "")
				{
					$this->news_model->update_news($id,$title,$desc,$status);
					$this->session->set_userdata('msg','News Updated Successfully!!!');
					redirect('news');	
				}
				else
				{
					$res= $this->news_model->get_img($id);
					$img = $res[0]->image;
					unlink("../uploads/news/$img");
					$image=$this->upload->data();
					$this->news_model->update_img_news($id,$title,$desc,$status,$image['file_name']);
					$this->session->set_userdata('msg','News Updated Successfully!!!');
					redirect('news');	
				}
			}
		}
		
		public function deletenews($id=NULL)
		{
			if($id=="")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('news');
			}
			else
			{
				$res= $this->news_model->get_img($id);
				if($res == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');	
				}
				else
				{
					$img = $res[0]->image;
					unlink("../uploads/news/$img");
					$this->news_model->delete_news($id);
					$this->session->set_userdata('msg','News Deleted Successfully!!!');
				}
				redirect('news');
			}
		}
		public function newsview($id=NULL)
		{
			if($id == "")
			{
				$this->session->set_userdata('err','Record Not Found!!!');
				redirect('news');

			}
			else
			{
				$data['news'] = $this->news_model->per_news($id);
				if($data['news'] == FALSE)
				{
					$this->session->set_userdata('err','Record Not Found!!!');
					redirect('news');

				}
				else
				{	
					$data['title'] = "News";
					$data['page'] = 'news/view_news';
					$this->load->view('templates/content',$data);
				}
			}

		}
		
		
		public function checkBox()
		{				
			if(isset($_POST['chk']))
			{
				foreach($this->input->post('chk') as $value)
				{
					if(isset($_POST["enable"]) && $_POST["enable"]=="Enable Selected")
					{
						$this->news_model->enable_news($value);					
						$v="Selected Record Enabled Successfully...!!!";
					}
					else if( isset($_POST["disable"]) && $_POST["disable"]=="Disable Selected")
					{
						$this->news_model->disble_news($value);		
						$v="Selected Record Disabled Successfully...!!!";							
					}
					else if(isset($_POST["delete"]) && $_POST["delete"]=="Delete Selected")
					{
						$this->news_model->delete_news_all($value);
	
						$v="Selected Record Deleted Successfully...!!!";
							
					}
				}						
				$this->session->set_userdata('msg',$v);
				redirect('news');	
			}
			redirect('news');	
		}
		
	}
?>