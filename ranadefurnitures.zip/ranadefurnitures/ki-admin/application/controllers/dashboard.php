<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends CI_Controller{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('login_model');
		$this->checkSession();
	}
	
	public function index()
	{			
		if($this->session->userdata('is_logged_in'))
		{
			$this->load->model('contacts_model');
			$data['contact_obj']=$this->contacts_model->get_contact_list_notification();
			$this->load->model('dashboard_model');
			$data['curr_contact']=$this->dashboard_model->get_contact();
			
			$this->load->model('register_user_model');
			$data['user_obj']=$this->register_user_model->get_user_list_notification();
			$data['curr_user']=$this->dashboard_model->get_users();	
			
			$this->load->model('orders_model');
			$data['order_obj']=$this->orders_model->get_order_list_notification();
			$data['curr_order']=$this->dashboard_model->get_order();
							
			$this->load->model('login_model');
			$data['res'] = $this->login_model->get_data();
			
			$data['title']="Dashboard";
			$data['page'] = 'dash';
			$this->load->view('templates/content',$data);
		}
		else
		{
			redirect('login');
		}

	}
	
	public function checkSession()
	{
		$isloggedin = $this->session->userdata('is_logged_in');
		if(!isset($isloggedin) || $isloggedin != TRUE)
		{
			$this->session->set_userdata('err',"Permission Denied");
			redirect('login');
		}
	}
	
	public function logout()
	{
		$this->login_model->last_logout();
		$this->session->unset_userdata('username',$this->input->post('username'));
		$this->session->unset_userdata('is_logged_in',TRUE);
		
		$this->session->set_userdata('msg','You Logout Successfull.');
		redirect();
	}
}

?>