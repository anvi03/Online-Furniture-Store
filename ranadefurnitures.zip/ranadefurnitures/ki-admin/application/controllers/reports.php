<?php 
	class Reports extends CI_Controller
	{
		public function index()
		{
			echo "hi";
		}
	}
?>