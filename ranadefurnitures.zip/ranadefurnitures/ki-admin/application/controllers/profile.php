<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Profile extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
            
			$this->load->model('login_model');
			$this->checkSession();
		}
		
		public function checkSession()
		{
			$isloggedin = $this->session->userdata('is_logged_in');
			if(!isset($isloggedin) || $isloggedin != TRUE)
			{
				$this->session->set_userdata('msg',"Permission Denied");
				redirect('login');
			}
		}
		public function index()
		{	
			
			$data['admin_profile'] = $this->login_model->get_profile();
			$data['title']="Admin Profile";
			$data['page'] = 'admin_profile';
			$this->load->view('templates/content',$data);

		}
		public function update_admin()
		{
			
			$this->form_validation->set_rules('username','Username','required|min_length[5]|max_length[30]');
			$this->form_validation->set_rules('first_name','FirstName','required|alpha|min_length[3]|max_length[15]');
			$this->form_validation->set_rules('last_name','LastName','required|alpha|min_length[3]|max_length[15]');
			$this->form_validation->set_rules('email','Email','required|valid_email');
			if ($this->form_validation->run() == FALSE)
			{
			 	$this->session->set_userdata('validation_errors',validation_errors());
				$data['admin_profile'] = $this->login_model->get_profile();
				$data['title']="Admin Profile";
				$data['page'] = 'admin_profile';
				$this->load->view('templates/content',$data);

			}
			else
			{
					$update = $this->login_model->update_profile();
					if($update)
					{
						
						
						$this->session->set_userdata('msg',"Profile Update Successfully.");
						redirect('profile');

						
					}
					else
					{
							$data['admin_profile'] = $this->login_model->get_profile();
							$data['title']="Admin Profile";
							$data['page'] = 'admin_profile';
							$this->load->view('templates/content',$data);

					}
						
			}	
						
		}
		public function changepwd()
		{
			$this->load->model('login_model');
			$data['admin_profile'] = $this->login_model->get_profile();
			$data['title']="Admin Profile";
			$data['page'] = 'changepwd_view';
			$this->load->view('templates/content',$data);
		}
		public function update_pwd()
		{
				$this->form_validation->set_rules('password','Password','required|min_length[8]|max_length[20]');
				$this->form_validation->set_rules('newpwd','NewPassword','required|matches[confirmpwd]|min_length[8]|max_length[20]');
				$this->form_validation->set_rules('confirmpwd','ConfirmPassword','required');
				if ($this->form_validation->run() == FALSE)
				{
					
					$this->session->set_userdata('validation_errors',validation_errors());
					$data['admin_profile'] = $this->login_model->get_profile();
					$data['title']="Admin Profile";
					$data['page'] = 'changepwd_view';
					$this->load->view('templates/content',$data);

				}
				else
				{
						$pwd = $this->input->post('password');
						$newpwd = $this->input->post('newpwd');
						$confirmpwd = $this->input->post('confirmpwd');

						$res = $this->login_model->set_pwd($pwd,$newpwd);
						if(!$res)
						{
							$data['admin_profile'] = $this->login_model->get_profile();
							$this->session->set_userdata('err',"Please Enter Valid Password.");
							$data['title']="Admin Profile";
							$data['page'] = 'changepwd_view';
							$this->load->view('templates/content',$data);
			
						}
						else
						{
							
							$this->session->set_userdata('msg',"Your Password Change Successfull.");
							redirect('profile/changepwd');

						}
				}
		}
	
	}
?>