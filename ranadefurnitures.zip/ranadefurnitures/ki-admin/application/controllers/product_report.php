<?php
if(!defined('BASEPATH')) exit('No direct script access allowed.');
	class Product_report extends CI_Controller 
	{	
		public function __construct()
		{	
			parent::__construct();
			$this->session->userdata('is_logged_in');
			$this->load->model('prod_report_model');
		}
		
		public function index()
		{
			$data['arrobj'] = $this->prod_report_model->getproduct();
			foreach($data['arrobj'] as $a)
			{
				$qty[]=$this->prod_report_model->get_sales($a['p_id']);
			}
			foreach($qty as $t)
			{
			
				$tot[]=$t[0]['quantity'];
			}
			$data['total']=$tot;
			/*$result['page']='report/customer';
			$this->load->view('templates/content',$result);*/
		 /*?>echo "<pre>";
			print_r($id);
			die;<?php */
			$data['page'] = "reports/product";
			$this->load->view('templates/content',$data); 	
		}
		public function getPdf()
		{
		$data['product'] = $this->prod_report_model->getproduct();
			foreach($data['product'] as $a)
			{
				$qty[]=$this->prod_report_model->get_sales($a['p_id']);
			}
			foreach($qty as $t)
			{
			
				$tot[]=$t[0]['quantity'];
			}
			$data['total']=$tot;
		$this->load->model('fpdf');
		$this->fpdf->AddPage();
		$this->fpdf->SetFont('Arial','B',26);
		$this->fpdf->cell(88,20,"Product Report",'','','L');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(56,20,"Date : ".date('Y/m/d'),'','','L');
		$this->fpdf->SetFont('Arial','B',10);
		$this->fpdf->cell(40,20,"Total Sales Amount : ",'',1,'C');		
						
		$this->fpdf->SetLineWidth(.3);
		$data['product'];		
		$this->fpdf->SetFont('Arial','B',10);
        $this->fpdf->Cell(30,8,"product id",1,'','C');
		//$this->fpdf->Cell(50,8,"Customer Name",1,'','C');
		$this->fpdf->Cell(50,8,"Product Name",1,'','C');
		$this->fpdf->Cell(20,8,"Qty",1,'','C');
		$this->fpdf->Cell(30,8,"Price",1,'','C');
		$this->fpdf->Cell(40,8,"Total Amount",1,1,'C');
    	//$this->fpdf->Ln();	
		$this->fpdf->SetFillColor(500,500,500);
	    $this->fpdf->SetTextColor(0);
    	$this->fpdf->SetFont('');
		$fill = false;
		foreach($data['product'] as $row)
		{
			$this->fpdf->Cell(30,8,number_format($row['p_id']),'LR',0,'C',$fill);
			$this->fpdf->Cell(50,8,ucfirst($row['p_name']),'LR',0,'C',$fill);
			$this->fpdf->Cell(20,8,number_format($row['p_qty']),'LR',0,'C',$fill);
			$this->fpdf->Cell(30,8,number_format($row['p_price']),'LR',0,'C',$fill);
			$this->fpdf->Cell(40,8,number_format($row['p_qty']*$row['p_price']),'LR',0,'C',$fill);
			$this->fpdf->Ln();
			$fill = !$fill;
		}		
		$this->fpdf->Cell(170,0,"",1,'','C');
		$this->fpdf->Output();																
		}
		
		public function alpha_dash_space($str)
		{
			return(! preg_match("/^([0-9,a-z,A-Z,' ',-])+$/i",$str)) ? FALSE : TRUE ;
		}
		
		public function prodadd()
		{
				$this->form_validation->set_rules('prodName','Prod_Name','trim|required|callback_alpha_dash_space');
				$this->form_validation->set_rules('prodDesc','Prod_Discription','trim|required|min_length[10]');
				$this->form_validation->set_rules('prodQty','Prod_Quantity','trim|required|is_natural_no_zero|max_length[3]');
				$this->form_validation->set_rules('prodPrice','Prod_Price','trim|required|is_natural_no_zero|max_length[8]');
				
				if($this->form_validation->run() == TRUE)
				{	
					$config['upload_path'] = '../tv_image/products/';
					$config['allowed_types'] = 'gif|jpg|png';
					/*$config['max_size']	= '10000';
					$config['max_width']  = '1800';
					$config['max_height']  = '1200';*/
			
					$this->load->library('upload', $config);
			
					$val = $this->upload->do_upload('prodImage');
					
					if($val)
					{
						$imgarr = $this->upload->data();
						$fname = $imgarr['file_name'];
						
						$this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'thumbs/',150);					
						$this->upload->resize($fname,$config['upload_path'],$config['upload_path'].'main/',230);	
						if(($this->input->post('btnadd'))!="")
						{	
							$name = $this->input->post('prodName');	
							$desc = $this->input->post('prodDesc');	
							$image = $fname;
							$status = $this->input->post('prodStatus');	
							$bid = $this->input->post('manufacturer');
							$cid = $this->input->post('category');
							$qty = $this->input->post('prodQty');
							$price = $this->input->post('prodPrice');
						
						
						/*	if($bid == 0)
							{
								$this->session->set_userdata('err','Please select brand_id');
								$data['manu'] = $this->product_model->getmanu();
								$data['cat'] = $this->product_model->getcat();	
								$data['page'] = "product/productAdd";
								$this->load->view('templates/content',$data);
							}
							else
							{		*/			
								$sendarr = array(
									'prod_name' => $name, 
									'prod_desc' => $desc,
									'prod_image' => $fname,
									'prod_status' => $status,
									'm_id' => $bid,
									'c_id' => $cid,
									'prod_qty' => $qty,
									'prod_price' => $price
									);
								
								
								
								if($this->product_model->insertprod($sendarr)>0)
								{
									$this->session->set_userdata('msg',"Record inserted succesfully.");
								}
								else
								{
									$this->session->set_userdata('msg',"Record not be inserted.");
								}
								redirect('product');
							
						}
						else
						{
							$data['manu'] = $this->product_model->getmanu();	
							$data['cat'] = $this->product_model->getcat();	
							$data['page'] = "product/productAdd";
							$this->load->view('templates/content',$data);
						}
					}
					else
					{
						$data['img'] =  $this->upload->display_errors();
						$data['manu'] = $this->product_model->getmanu();
						$data['cat'] = $this->product_model->getcat();			
						$data['page'] = "product/productAdd";
						$this->load->view('templates/content',$data);
					}	
				}
				else
				{
					$data['manu'] = $this->product_model->getmanu();		
					$data['cat'] = $this->product_model->getcat();		
					$data['page'] = "product/productAdd";
					$this->load->view('templates/content',$data);
					
				}
		}
		
		public function proddel($id)
		{
			if($id)
			{
				$idArr = $id;
				$data['get'] = $this->product_model->getproduct($idArr);
				
				if(!$data['get'])
				{
					$this->session->set_userdata('err',"No record found!!!!!!");
					redirect('product');	
				}
				
				$img = $data['get']->prod_image;
				
				if(file_exists('../tv_image/products/'.$img))
				{
					unlink('../tv_image/products/'.$img);
				}
				
				
				$data['info'] = $this->product_model->deleteprod($idArr);
				
				if($data > 0)
				{
					$this->session->set_userdata('msg',"Record deleted succesfully.");
				}
				else
				{
					$this->session->set_userdata('msg',"Record not be deleted.");
				}
				redirect('product');
			}
			else
			{
				$this->session->set_userdata('err',"No record found!!!!!!");
				redirect('product');
			}
		}
		
		public function prodedit($prod_id)
		{
			if($prod_id)
			{
				$data['arrobj'] = $this->product_model->getproduct($prod_id);
				$data['manu'] = $this->product_model->getmanu();
				$data['cat'] = $this->product_model->getcat();		
				//$img = $data['arrobj']->prod_image
				
				if(!$data['arrobj'])
				{
					$this->session->set_userdata('err',"No record found!!!!!!");
					redirect('product');
				}
				
					
				$this->form_validation->set_rules('prodName','Prod_Name','trim|required|alpha_dash_space');
				$this->form_validation->set_rules('prodDesc','Prod_Discription','trim|required|min_length[10]');
				$this->form_validation->set_rules('prodQty','Prod_Quantity','trim|required|is_natural_no_zero');
				$this->form_validation->set_rules('prodPrice','Prod_Price','trim|required|is_natural_no_zero');
				
				if($this->form_validation->run() == TRUE)
				{		
					$config['upload_path'] = '../tv_image/products/';
					$config['allowed_types'] = 'gif|jpg|png';
					$config['max_size']	= '10000';
					$config['max_width']  = '1800';
					$config['max_height']  = '1200';
			
					$this->load->library('upload', $config);
			
					$val = $this->upload->do_upload('prodImage');
					
					if($val != "")
					{
						$img = $this->input->post('prodImg');
						
						if($img != $val)
						{
							if(file_exists('../tv_image/products/'.$img))
							{
								unlink('../tv_image/products/'.$img);
							}
						}
						
						$imgarr = $this->upload->data();
						$fname = $imgarr['file_name'];		
					}
					else
					{
						$imgarr = $this->upload->data();
						$fname = $this->input->post('prodImg');	
					}
							
					
					$name = $this->input->post('prodName');	
					$desc = $this->input->post('prodDesc');	
					$image = $fname;
					$status = $this->input->post('prodStatus');	
					$bid = $this->input->post('manufacturer');
					$cid = $this->input->post('category');
					$qty = $this->input->post('prodQty');
					$price = $this->input->post('prodPrice');		
					
					
				/*	if($bid == 0)
					{
						$this->session->set_userdata('err','Please select brand_id');
						$data['arrobj'] = $this->product_model->getproduct($prod_id);
						$data['manu'] = $this->product_model->getmanu();
						$data['cat'] = $this->product_model->getcat();
						$data['page'] = "product/productEdit";
						$this->load->view('templates/content',$data);
					}
					else
					{		*/
						$sendarr = array(
							'prod_name' => $name, 
							'prod_desc' => $desc,
							'prod_image' => $fname,
							'prod_status' => $status,
							'm_id' => $bid,
							'c_id' => $cid,
							'prod_qty' => $qty,
							'prod_price' => $price
							);	
							
							
									
							if($this->input->post('btnedit'))
							{	
								if($this->product_model->updateprod($prod_id,$sendarr)>0)
								{
									$this->session->set_userdata('msg',"Record Updated succesfully.");
								}
								else
								{
									$this->session->set_userdata('msg',"Record not be Updated.");
								}
								redirect('product');
							}
					
				}
				else
				{
					$data['arrobj'] = $this->product_model->getproduct($prod_id);
					$data['manu'] = $this->product_model->getmanu();
					$data['cat'] = $this->product_model->getcat();
					$data['page'] = "product/productEdit";
					$this->load->view('templates/content',$data);
				}
			}
			else
			{
				$this->session->set_userdata('err',"No record found!!!!!!");
				redirect('product');		
			}
		}
		
		public function prodview($prod_id)
		{
				if($prod_id)
				{
					$data['arrobj'] = $this->product_model->getproduct($prod_id);
					$data['images'] = $this->product_model->get_images($prod_id);
					if (!$data['arrobj'])
					{
						$this->session->set_userdata('err','No Record Found!!!!!');
						redirect('product');
					}
				
					//$data['admin_data']=$this->website_model->get_details();
					$data['page'] = 'product/productView';
					$this->load->view('templates/content',$data);
				}
				else
				{	
					$this->session->set_userdata('err',"No Record Found!!!!!");
					redirect('product');	
				}			
		}	
		
		public function addgallery($prod_id)
		{
			if(!is_dir('../tv_image/products/'.$prod_id))
			{
				mkdir('../tv_image/products/'.$prod_id,0777,true);
				mkdir('../tv_image/products/'.$prod_id.'/full',0777,true);
				mkdir('../tv_image/products/'.$prod_id.'/thumbs',0777,true);
				
			}
			$config['upload_path'] = '../tv_image/products/'.$prod_id.'/full';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$config['max_width']  = '5000';
			$config['max_height']  = '5000';
			$config['encrypt_name'] =  TRUE;
	
			$this->load->library('upload', $config);
			 
			$i = 0;
			foreach($_FILES as $key=>$val)
			{
				$cnt = count($_FILES['userfile']['name']);
				for($j=0;$j<$cnt;$j++)
				{
					$img['name'] = $val['name'][$i];
					$img['type'] = $val['type'][$i];
					$img['tmp_name'] = $val['tmp_name'][$i];
					$img['error'] = $val['error'][$i];
					$img['size'] = $val['size'][$i];
					
					//echo "<pre>"; print_r($img); 
					//$this->upload->do_upload_ki($img);
					$i++;
					if ( ! $this->upload->do_upload_ki($img))
					{
						$this->session->set_userdata('err',$this->upload->display_errors());
						
						redirect('product/productview/'.$prod_id);
					}
					else
					{
						$arr = $this->upload->data();
						$imageName = $arr['file_name'];
						$this->upload->resize($imageName,$config['upload_path'],'../tv_image/products/'.$prod_id.'/thumbs/');
						
						
						$res = $this->product_model->add_gallery($prod_id,$imageName);
						
					}
					
				}
			}
			redirect('product/prodview/'.$prod_id);
		}
		
		public function imgdel($prod_id,$photo_id)
		{
			$data['img'] = $this->product_model->get_photo($photo_id);
			
			$image = $data['img'][0]->fullname;
			
			if(file_exists('../tv_image/products/'.$prod_id.'/full/').$image)	
			{
				unlink('../tv_image/products/'.$prod_id.'/full/'.$image);
			}
			
			if(file_exists('../tv_image/products/'.$prod_id.'/thumbs/').$image)	
			{
				unlink('../tv_image/products/'.$prod_id.'/thumbs/'.$image);
			} 
			
			$res = $this->product_model->delete_image($prod_id,$photo_id); 
			
			if($res)
			{
				$this->session->set_userdata('msg','Image Deleted Succesfully');
				redirect('product/prodview/'.$prod_id);
			}
			else
			{
				redirect('product/prodview/'.$prod_id);
			}
				
		}
		
		public function delete_multiple()
		{
		
			if($this->input->post('del'))
			{
				$box = $this->input->post('selector');
				if($box == "")
				{
					$this->session->set_userdata('err','Please select at least 1 record... ');
					redirect('product');
				}
				else
				{
					foreach($box as $key => $value)
					{
						$data['arrobj'] = $this->product_model->get_img($value);
						$img = $data['arrobj']->prod_image;
					
						if(file_exists('../tv_image/products/'.$img))
						{
							unlink('../tv_image/products/'.$img);
						}
						$res = $this->product_model->del_multiple($value);	
					}
					$this->session->set_userdata('msg','Records are deleted succesfully.');
				}
				redirect('product');
			}
			elseif($this->input->post('enable'))
			{
				$box = $this->input->post('selector');
				if($box == "")
				{
					$this->session->set_userdata('err','Please select at least 1 record... ');
					redirect('product');
				}
				else
				{
					foreach($box as $key => $value)
					{
						$res = $this->product_model->enable_multiple($value);	
					}
					$this->session->set_userdata('msg','Records are enable succesfully.');
				}
				redirect('product');
			}
			elseif($this->input->post('disable'))
			{
				$box = $this->input->post('selector');
				if($box == "")
				{
					$this->session->set_userdata('err','Please select at least 1 record... ');
					redirect('product');
				}
				else
				{
					foreach($box as $key => $value)
					{
						$res = $this->product_model->disable_multiple($value);	
					}
					$this->session->set_userdata('msg','Records are disable succesfully.');
				}
				redirect('product');
			}
			else
			{
				echo "Please Select";
			}
		}
		
		public function cat($id=FALSE)
		{
			$data['subcat'] = $this->product_model->get_sub_cat($id);		
			$data['page'] = "product/productAdd";
			$this->load->view('templates/content',$data);
		}
		
		public function get_subcat($id=FALSE)
		{
			$data['subcat'] = $this->product_model->get_sub_cat($id);		
			$this->load->view('product/get_sub_cat',$data);
			
		}
	  }
?>