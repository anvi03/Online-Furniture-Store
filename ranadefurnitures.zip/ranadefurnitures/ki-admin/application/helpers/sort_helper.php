<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function get_sort_vars($uri_segment = 3, $base_url = '', $sortable_fields = array())
{
 $CI =& get_instance();

 $sort = NULL;
 if ($CI->uri->segment($uri_segment) == 'sort') {
  $field = $CI->uri->segment($uri_segment + 1);
  if ($field !== FALSE)
  {
   $sort_field_names = array_flip($sortable_fields);
   $sort = $sort_field_names[$field];
   $base_url .= "/sort/{$field}";
   $uri_segment++;
   $order = strtolower($CI->uri->segment($uri_segment + 1, 'asc'));
   if ($order == 'asc' || $order == 'desc')
   {
    $sort .= ' ' . $order;
    $base_url .= "/{$order}";
    $uri_segment += 2;
   }
   $sort = urldecode($sort);
  }
 }
 return array($sort, $uri_segment, $base_url);
}

