<?php
	class Banner_model extends CI_Model {
		
		public function get_banner()
		{
			$this->db->order_by("id", "desc"); 
			$query = $this->db->get('banner');
			return $query->result();
		}
		public function news()
		{
			$rst = $this->db->get('news');
			return $rst;
		}
		
		public function set_banner($title,$status,$image)
		{
			
			$data=array('title'=>"$title",'image'=>"$image",'status'=>"$status");
			$this->db->insert('banner',$data);
		}
		
		public function get_data($id)
		{
			$data['res'] = $this->view_banner($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$query = $this->db->get('banner');
				return $query->result();
			}
		}
		
		public function update_img_banner($id,$title,$status,$image)
		{
			
			$data=array('title'=>"$title",'image'=>"$image",'status'=>"$status");
			$this->db->where('id',$id);
			$this->db->update('banner',$data);
		}
		
		public function update_banner($id,$title,$status)
		{
			
			$data=array('title'=>"$title",'status'=>"$status");
			$this->db->where('id',$id);
			$this->db->update('banner',$data);
		}
		
		public function get_img($id)
		{
			$this->db->where('id',$id);
			$qry = $this->db->get('banner');
			return $qry->result();
		}
		
		public function delete_banner($id)
		{
			$data['res'] = $this->view_banner($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$this->db->delete('banner');
				return true;
			}
		}
		public function view_banner($id)	
		{
			$this->db->where('id',$id);
			$query = $this->db->get('banner');
			return $query->result();
			
		}
		public function per_banner($id)	
		{
			$data['res'] = $this->view_banner($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$query = $this->db->get('banner');
				return $query->result();
			}
			
		}
		
		public function enable_banner($id)
		{
			$data=array('status'=>1);
			$this->db->where('id',$id)->update('banner',$data);
			return true;
		}
		
		public function disble_banner($id)
		{
			$data=array('status'=>0);
			return $this->db->where('id',$id)->update('banner',$data);
		}
		public function delete_banner_all($id)
		{
			 $query = $this->db->where('id',$id)->delete('banner');
			 return true;
		}


}
?>