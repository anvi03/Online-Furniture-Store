<?php 
	class Product_model extends CI_Model
	{
		public function product_view()
		{	
			$this->db->order_by("p_id", "desc");			
			$query = $this->db->get('product');
			return $query->result();
		}
		public function category_id()
		{
			//$this->db->select('c_id');
			$query = $this->db->get('categories');
			return $query->result();
			
		}
		public function get_product($id)
		{
			
			$this->db->where('c_id',$id);
			$query = $this->db->get('product');
			return $query->result();

		}
		public function set_product($name,$price,$desc_long,$desc_short,$status,$qty,$image,$c_id)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('p_name'=>"$name",'p_price'=>"$price",'p_desc_long'=>"$desc_long",'p_desc_short'=>"$desc_short",'p_image'=>"$image",'p_status'=>"$status",'p_qty'=>"$qty",'p_created'=>"$date",'p_updated'=>"$date",'c_id'=>"$c_id");
			$this->db->insert('product',$data);
		}
		public function product_data($id)
		{
			$data['res'] = $this->view_product($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('p_id',$id);
				$query = $this->db->get('product');
				return $query->result();
			}
		}
		
		public function update_img_product($id,$name,$desc_long,$desc_short,$status,$qty,$image)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('p_name'=>"$name",'p_desc_long'=>"$desc_long",'p_image'=>"$image",'p_status'=>"$status",'p_qty'=>"$qty",'p_created'=>"$date",'p_updated'=>"$date");	
			$this->db->where('p_id',$id);
			$this->db->update('product',$data);
		}
		
		public function update_product($id,$name,$desc_long,$desc_short,$status,$qty)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('p_name'=>"$name",'p_desc_long'=>"$desc_long",'p_desc_short'=>"$desc_short",'p_status'=>"$status",'p_qty'=>"$qty",'p_created'=>"$date");
			$this->db->where('p_id',$id);
			$this->db->update('product',$data);
		}
		
		public function get_img($id)
		{
			$this->db->where('p_id',$id);
			$qry = $this->db->get('product');
			return $qry->result();
		}
		public function delete_product($id)
		{
			$data['res'] = $this->view_product($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('p_id',$id);
				$this->db->delete('product');
				return true;
			}
		}
		public function view_product($id)
		{
			$this->db->where('p_id',$id);
			$query = $this->db->get('product');
			return $query->result();

		}
		public function per_product($id)
		{
			$data['res'] = $this->view_product($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('p_id',$id);
				$query = $this->db->get('product');
				return $query->result();
			}

		}

		public function get_details($id)
		{
			
			$this->db->where('p_id',$id);
			$res=$this->db->get('product');
			return $res->result_object();
		}
		
		public function enable_product($id)
		{
			$data=array('p_status'=>1);
			$this->db->where('p_id',$id)->update('product',$data);
			return true;
		}
		
		public function disble_product($id)
		{
			$data=array('p_status'=>0);
			return $this->db->where('p_id',$id)->update('product',$data);
		}
		public function delete_product_all($id)
		{
			 $query = $this->db->where('p_id',$id)->delete('product');
			 return true;
		}


	}
?>