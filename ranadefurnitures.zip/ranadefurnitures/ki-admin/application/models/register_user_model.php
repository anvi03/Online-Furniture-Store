<?php
	class Register_user_Model extends CI_Model
	{
		public function get_user()
		{
			$this->db->order_by("id","desc");
			$query = $this->db->get('regi');
			return $query->result();
			
		}
		
		public function view_user($id)	
		{
			$this->db->where('id',$id);
			$query = $this->db->get('regi');
			return $query->result();
			
		}
		public function per_user($id)	
		{
			$data['res'] = $this->view_user($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{

				$this->db->where('id',$id);
				$query = $this->db->get('regi');
				return $query->result();
			}
				
		}
				
		public function delete_user($id)
		{
			$data['res'] = $this->view_user($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$this->db->delete('regi');
				return true;
			}
		}
		
		
		public function delete_user_all($id)
		{
			 $query = $this->db->where('id',$id)->delete('regi');
			 return true;
		}
		public function get_user_list_notification()
		{
			$this->db->order_by('created','desc');
			$query = $this->db->get('regi',5);
			return $query->result();
		}

	}
?>