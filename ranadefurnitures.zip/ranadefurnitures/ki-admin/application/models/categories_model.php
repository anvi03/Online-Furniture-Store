<?php
	class Categories_Model extends CI_Model
	{
		
		public function get_categories()
		{
			$this->db->order_by('c_id',"desc");
			$query = $this->db->get('categories');
			return $query->result();
		}
		public function get_parent()
		{
			
			//$this->db->select('c_name');
			$this->db->where('parent_id','c_id');
			$query = $this->db->get('categories');
			return $query->result();
		}
		public function set_categories($c_name,$parent_id,$status,$c_image)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('c_name'=>"$c_name",'c_image'=>"$c_image",'parent_id'=>"$parent_id",'c_status'=>"$status",'created'=>"$date",'updated'=>"$date");
			$this->db->insert('categories',$data);
		}
		public function categories_data($id)
		{
			$data['res'] = $this->view_category($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('c_id',$id);
				$query = $this->db->get('categories');
				return $query->result();
			}
		}
		public function get_data($id)
		{
			$this->db->where('c_id',$id);
			$query = $this->db->get('categories');
			return $query->result();
		}
		public function update_img_categories($id,$name,$status,$image)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('c_name'=>"$name",'c_image'=>"$image",'c_status'=>"$status",'updated'=>"$date");
			$this->db->where('c_id',$id);
			$this->db->update('categories',$data);

		}
		public function update_categories($id,$name,$status)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('c_name'=>"$name",'c_status'=>"$status",'updated'=>"$date");
			$this->db->where('c_id',$id);
			$this->db->update('categories',$data);

		}
		public function get_img($id)
		{
			$this->db->where('c_id',$id);
			$qry = $this->db->get('categories');
			return $qry->result();
		}
		public function delete_categories($id)
		{
			$data['res'] = $this->view_category($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('c_id',$id);
				$this->db->delete('categories');
				return true;
			}

		}
		
		public function view_category($id)
		{
			$this->db->where('c_id',$id);
			$query = $this->db->get('categories');
			return $query->result();
			
		}
		
		public function per_category($id)
		{
			$data['res'] = $this->view_category($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('c_id',$id);
				$query = $this->db->get('categories');
				return $query->result();
			}
			
		}
		
		
		public function enable_categories($id)
		{
			$data=array('c_status'=>1);
			$this->db->where('c_id',$id)->update('categories',$data);
			return true;
		}
		
		public function disble_categories($id)
		{
			$data=array('c_status'=>0);
			return $this->db->where('c_id',$id)->update('categories',$data);
		}
		public function delete_category($id)
		{
			 $query = $this->db->where('c_id',$id)->delete('categories');
			 return true;
		}

	}
?>