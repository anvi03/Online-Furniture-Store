<?php
	class Contacts_Model extends CI_Model
	{
		public function get_contacts()
		{
			$this->db->order_by("contact_id","desc");
			$query = $this->db->get('contacts');
			return $query->result();
			
		}
		
		public function view_contact($id)	
		{
			$this->db->where('contact_id',$id);
			$query = $this->db->get('contacts');
			return $query->result();
			
		}
		public function per_contact($id)	
		{
			$data['res'] = $this->view_contact($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{

				$this->db->where('contact_id',$id);
				$query = $this->db->get('contacts');
				return $query->result();
			}
				
		}
				
		public function delete_contact($id)
		{
			$data['res'] = $this->view_contact($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('contact_id',$id);
				$this->db->delete('contacts');
				return true;
			}
		}
		
		
		public function delete_contact_all($id)
		{
			 $query = $this->db->where('contact_id',$id)->delete('contacts');
			 return true;
		}
		public function get_contact_list_notification()
		{
			$this->db->order_by('contact_date','desc');
			$query = $this->db->get('contacts',5);
			return $query->result();
		}

	}
?>