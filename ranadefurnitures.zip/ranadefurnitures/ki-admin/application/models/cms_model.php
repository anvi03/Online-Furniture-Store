<?php 
	class Cms_Model extends CI_Model
	{
		public function cms_list()
		{
			$this->db->order_by("p_id", "desc");
			$query = $this->db->get('cms');
			return $query->result();
		}
		
		public function set_cms($title,$page_url_key,$status,$content,$metakeywords,$metadesc)
		{
			$data = array(
							'page_title'=>"$title",
							'page_url_key'=>"$page_url_key",
							'status'=>"$status",
							'content'=>"$content",
							'metakeywords'=>"$metakeywords",
							'meta_desc'=>"$metadesc"
						 );
			$this->db->insert('cms',$data);
		}
		
		public function view_page($id)	
		{
			$this->db->where('p_id',$id);
			$query = $this->db->get('cms');
			return $query->result();
			
		}
		
		
		public function get_data($id)
		{
			$data['res'] = $this->view_page($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('p_id',$id);
				$query = $this->db->get('cms');
				return $query->result();
			}
		}
		
		
		public function update_page($id,$title,$page_url_key,$status,$content,$metakeywords,$metadesc)
		{
			//$date = date('Y-m-d');
			$data=array('page_title'=>"$title",'page_url_key'=>"$page_url_key",'status'=>"$status",'content'=>"$content",'metakeywords'=>"$metakeywords",'meta_desc'=>"$metadesc");
			$this->db->where('p_id',$id);
			$this->db->update('cms',$data);
		}
		
		public function get_page($id)
		{
			$this->db->where('p_id',$id);
			$qry = $this->db->get('cms');
			return $qry->result();
		}
		
		public function delete_page($id)
		{
			$data['res'] = $this->view_page($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('p_id',$id);
				$this->db->delete('cms');
				return true;
			}
		}
		
		public function per_page($id)
		{
			$data['res'] = $this->view_page($id);
			$num = count($data['res']);
			if($num<1)
			{
				return FALSE;
			}
			else
			{
				$this->db->where('p_id',$id);
				$query = $this->db->get('cms');
				return $query->result();
			}
			
		}
		
		public function enable_cms($id)
		{
			$data=array('status'=>1);
			$this->db->where('p_id',$id)->update('cms',$data);
			return true;
		}
		
		public function disble_cms($id)
		{
			$data=array('status'=>0);
			return $this->db->where('p_id',$id)->update('cms',$data);
		}
		public function delete_cms($id)
		{
			 $query = $this->db->where('p_id',$id)->delete('cms');
			 return true;
		}

	
	}
?>