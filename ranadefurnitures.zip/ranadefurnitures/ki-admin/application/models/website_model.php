<?php 
class Website_Model extends CI_Model
{
	public function get_details()
	{
		$qry = $this->db->get('admin');
		return $qry->row();
	}
	public function get_details()
	{
		$qry = $this->db->get('admin');
		return $qry->row();
	}
	public function update_admin()
	{
		$data = array(
						'username' => $this->input->post('username'),
						'first_name' => $this->input->post('first_name'),
						'last_name' => $this->input->post('last_name'),
						'email' => $this->input->post('email')
					);
		$res = $this->db->update('admin',$data);
		if($res)
		{
			return true;
		}	
		
}	}
?>