<?php
	class Login_model extends CI_Model{
		
		public function validate()
		{	
			$this->db->where('username',trim($this->input->post('user')));
			$this->db->where('password',trim(md5($this->input->post('pass'))));
			$query = $this->db->get('admin');
			
			if($query->num_rows == 1)
			{	
					return true;	
			}
		}
		public function get_profile()
		{
			$rst = $this->db->get('admin');
			return $rst->row();
		}
		public function update_profile()
		{
			$data = array(
								'username' => trim($this->input->post('username')),
								'first_name' => trim($this->input->post('first_name')),
								'last_name' => trim($this->input->post('last_name')),
								'email' => trim($this->input->post('email'))
						 );
			$update = $this->db->update('admin',$data);
			if($update)
			{
				return true;
			}
		}
		public function set_pwd($pwd,$newpwd)
		{
			$oldpwd = trim(md5($this->input->post('password')));
			$data = array('password' => trim(md5($newpwd)));
			$uname = $this->session->userdata('username');
			$this->db->where('username',$uname);
			$q = $this->db->get('admin');
			$res = $q->result_array();
		
			$dboldpwd = $res[0]['password'];
		
			if($dboldpwd == $oldpwd)
			{
				
				$update = $this->db->update('admin',$data);
				if($update)
				{
					return true;
				}
			}
			else
			{
				return false;
			}
			
		}
		public function last_login()
		{
			$date= date('Y-m-d H:m:s');

			$data = array(
							'last_login'=> "$date"
						 );	
			$update = $this->db->update('admin',$data);
			if($update)
			{
				return true;
			}
		}
		public function get_data()
		{
			$q = $this->db->get('admin');
			return $q->result();
		}
		public function last_logout()
		{
			$this->db->set('last_logout','NOW()',FALSE);
			$this->db->update('admin');
		}


} 
?>