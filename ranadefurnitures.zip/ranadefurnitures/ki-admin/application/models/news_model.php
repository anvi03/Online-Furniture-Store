<?php
	class News_model extends CI_Model {
		
		public function get_news()
		{
			$this->db->order_by("id", "desc"); 
			$query = $this->db->get('news');
			return $query->result();
		}
		public function news()
		{
			$rst = $this->db->get('news');
			return $rst;
		}
		
		public function set_news($title,$desc,$status,$image)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('title'=>"$title",'description'=>"$desc",'image'=>"$image",'status'=>"$status",'created'=>"$date");
			$this->db->insert('news',$data);
		}
		
		public function get_data($id)
		{
			$data['res'] = $this->view_news($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$query = $this->db->get('news');
				return $query->result();
			}
		}
		
		public function update_img_news($id,$title,$desc,$status,$image)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('title'=>"$title",'description'=>"$desc",'image'=>"$image",'status'=>"$status",'created'=>"$date");
			$this->db->where('id',$id);
			$this->db->update('news',$data);
		}
		
		public function update_news($id,$title,$desc,$status)
		{
			$date = date('Y-m-d H:m:s');
			$data=array('title'=>"$title",'description'=>"$desc",'status'=>"$status",'created'=>"$date");
			$this->db->where('id',$id);
			$this->db->update('news',$data);
		}
		
		public function get_img($id)
		{
			$this->db->where('id',$id);
			$qry = $this->db->get('news');
			return $qry->result();
		}
		
		public function delete_news($id)
		{
			$data['res'] = $this->view_news($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$this->db->delete('news');
				return true;
			}
		}
		public function view_news($id)	
		{
			$this->db->where('id',$id);
			$query = $this->db->get('news');
			return $query->result();
			
		}
		public function per_news($id)	
		{
			$data['res'] = $this->view_news($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$query = $this->db->get('news');
				return $query->result();
			}
			
		}
		
		public function enable_news($id)
		{
			$data=array('status'=>1);
			$this->db->where('id',$id)->update('news',$data);
			return true;
		}
		
		public function disble_news($id)
		{
			$data=array('status'=>0);
			return $this->db->where('id',$id)->update('news',$data);
		}
		public function delete_news_all($id)
		{
			 $query = $this->db->where('id',$id)->delete('news');
			 return true;
		}


}
?>