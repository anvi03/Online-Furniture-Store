<?php

	class prod_report_model extends CI_Model
	{
		public function getproduct($id = FALSE)
		{	
			if($id)
			{	
				$this->db->where('p_id',$id);
				$res = $this->db->get('product');	
				$res_obj = $res->row();
			}
			else
			{
				$this->db->order_by('p_id','desc');
				$res = $this->db->get('product');	
				$res_obj = $res->result_array();
			}
			return $res_obj;	
		}
		public function get_sales($id)
		{
			$this->db->where('product_id',$id);
			$this->db->select_sum('quantity');			
			$result=$this->db->get('order_items');
			
			return $result->result_array();
		
		}
		public function getmanu()
		{
			$this->db->select('m_id');
			$this->db->select('m_name');
			$res = $this->db->get('menufacture');	
	
			return $res->result_array();
		}
		
		public function getcat()
		{
			$this->db->select('cat_id');
			$this->db->select('cat_name');
			$this->db->where('par_id','0');
			$res = $this->db->get('categories');
			return $res->result_array();
		}
		
		public function insertprod($sendarr)
		{
			$this->db->set('prod_created','NOW()',FALSE);
			
			$this->db->insert('products',$sendarr);
			$r = $this->db->insert_id();			//insert_id is the no of inserted row.
			return $r;
		}
		
		public function deleteprod($idArr)
		{
			$this->db->where('prod_id',$idArr);
			$this->db->delete('products');
			$affrows = $this->db->affected_rows();  //affacted_rows is the row which one deleted.
			return $affrows;
		}
		
		public function updateprod($prod_id,$sendarr)
		{		
			$this->db->set('prod_created','NOW()',FALSE);
			
			$this->db->where('prod_id',$prod_id);
			$qry = $this->db->update('products',$sendarr);
			$r = $this->db->affected_rows();			//insert_id is the no of inserted row.
			return $r;
		}
		
/*MULTIPLE_IMG_UPLOAD*/
		public function add_gallery($prod_id,$imageName)
		{
			
			$data=array(
				'prod_id' => $prod_id,
				'fullname'=>$imageName,
				'shortname'=>'thumb_'.$imageName
				);
			$this->db->where('prod_id',$prod_id);
			$this->db->insert('photos',$data);
			
			
		}
		
		public function get_images($prod_id)
		{
			$this->db->where('prod_id',$prod_id);
			$image = $this->db->get('photos');
			
			return $image->result();
		}
		
		public function search()
		{
			$res = $this->db->get('product');
			return 	$res->result();
		}
		
		public function delete_image($prod_id,$photo_id)
		{
			$this->db->where('photo_id',$photo_id);
			$this->db->delete('photos');
		}
	
		public function get_photo($photo_id)
		{
			$this->db->where('photo_id',$photo_id);
			$image = $this->db->get('photos');
			
			return $image->result();
		}
		
/*Multiple chkbox*/

		public function del_multiple($box)
		{
			$this->db->where('prod_id',$box);
			$query = $this->db->delete('products');
			return TRUE;
		}
		
		public function enable_multiple($box)
		{
			$this->db->where('prod_id',$box);
			return $this->db->update('products',array('prod_status'=>'1'));
		}
		
		public function disable_multiple($box)
		{
			$this->db->where('prod_id',$box);
			return $this->db->update('products',array('prod_status'=>'0'));
		}
		
		public function get_img($prod_id)
		{
			$this->db->select('prod_image');
			$this->db->where('prod_id',$id);
			$res = $this->db->get('products');
			$r=$res->row();
			return $r;
		}
		
		public function get_sub_cat($id)
		{
			$this->db->where('par_id',$id);
			$result = $this->db->get('categories');
			return $result->result();
		}
				
	}
?>