<?php
	class Cust_report_model extends CI_Model
	{
		public function getcustomer($id = FALSE)
		{	
			//echo $id;die;
			if($id)
			{	
				$this->db->where('id',$id);
				$res = $this->db->get('regi');	
				$res_obj = $res->row();
			}
			else
			{
				$this->db->order_by('id','desc');
				$res = $this->db->get('regi');	
				$res_obj = $res->result_array();
			}
			return $res_obj;	
		}	
		public function get_total($id)
		{
			$this->db->where('customer_id',$id);
			$this->db->select_sum('total');			
			$result=$this->db->get('orders');
			return $result->result_array();
		
		}
		public function get_customer_display()
		{
			//$this->db->limit(5);
			$this->db->order_by('id','desc');
			$qry=$this->db->get('regi');	
			return $qry->result();	
		}	
		public function enable_news($id)
		{
			$data=array('status'=>0);
			return $this->db->where('regi_id',$id)->update('registration',$data);
		}
		
		public function delete_news($id)
		{
			return $this->db->where('regi_id',$id)->delete('registration');
		}
		public function selected_record($id)
		{
			$this->db->where('regi_id',$id);
			$qry=$this->db->get('registration');
			if($qry->num_rows()<1)
			{
				return false;	
			}
			else
			{
				return $qry->result_array();
			}
		}
		public function delete($id)
		{
				$res=$this->selected_record($id);
				if($res==false)
				{
					return false;	
				}
				else
				{
					$this->db->where('regi_id',$id);
					$res=$this->db->delete('registration');
					return true; 
				}
		}
	}
?>