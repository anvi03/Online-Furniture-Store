<?php
	class Orders_Model extends CI_Model
	{
		public function update_status($id)
		{
	   
		   $status=$this->input->post('status');
		   
		   $data = array('status' =>$status
				   );
				   $this->db->where('order_no',$id);
		   $result=$this->db->update('orders', $data);
		   return TRUE;
		}
		public function change_status($id,$status)
		{
				$data = array('status' => $status);
				$this->db->where('order_no',$id);
				
				$query = $this->db->update('orders',$data);
				if($query)
				{
					return true;
				}	
		}
		public function get_total_orders()
		{	
				
			$this->db->select('order_items.*,orders.*,regi.*,product.*');
	    	$this->db->from('order_items');
			$this->db->join('orders', 'orders.order_no = order_items.order_id', 'inner'); 						
			$this->db->join('regi', 'orders.customer_id = regi.id', 'inner');
			$this->db->join('product', 'order_items.product_id = product.p_id', 'inner'); 						
    		return $this->db->get()->result();			
		}
		public function get_orders()
		{
			$this->db->order_by("to_date","desc");
			$query = $this->db->get('cart');
			return $query->result();
			
		}
		
		public function view_order($id)	
		{
			$this->db->where('order_no',$id);
			$query = $this->db->get('orders');
			return $query->result();
			
		}
		public function per_order($id)	
		{
			$data['res'] = $this->view_order($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{

				$this->db->select('order_items.*,orders.*,regi.*,product.*');
				$this->db->from('order_items');
				$this->db->where('order_no',$id);
				$this->db->join('orders', 'orders.order_no = order_items.order_id', 'inner'); 						
				$this->db->join('regi', 'orders.customer_id = regi.id', 'inner');
				$this->db->join('product', 'order_items.product_id = product.p_id', 'inner'); 						
				return $this->db->get()->result();
			}
				
		}
				
		public function delete_order($id)
		{
			$data['res'] = $this->view_order($id);
			$num = count($data['res']);
			if($num<1)
			{
				return false;
			}
			else
			{
				$this->db->where('id',$id);
				$this->db->delete('cart');
				return true;
			}
		}
		
		
		public function delete_order_all($id)
		{
			 $query = $this->db->where('id',$id)->delete('cart');
			 return true;
		}

		public function get_order_list_notification()
		{
			$this->db->order_by('ordered_on','desc');
			$query = $this->db->get('orders',5);
			return $query->result();
		}
		/*public function get_orderitems_notification($ord_no)
		{
			//echo $ord_no;die;		
			$this->db->where('order_id',$ord_no);
			$query = $this->db->get('order_items',5);
			return $query->result();
		}
		public function get_product_notification($id)
		{
			$this->db->where('p_id',$id);
			$query = $this->db->get('product',5);
			//echo "<Pre>";print_r($query);die;
			return $query->result();
			
		}*/
	}
?>