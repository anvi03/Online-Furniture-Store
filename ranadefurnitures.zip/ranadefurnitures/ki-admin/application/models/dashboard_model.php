<?php 
	class Dashboard_model extends CI_Model
	{
		public function last_logout()
		{
			$this->db->select('last_logout');
			return $this->db->get('admin')->row();
		}
		public function get_contact()
		{
			$this->db->select('last_logout');
			$res=$this->db->get('admin')->row();
			$last=$res->last_logout;
			//echo "<pre>";print_r($last);die;
			$this->db->select('contact_date');
			$this->db->where('contact_date >',$last);
			$result=$this->db->get('contacts')->result();
			$num=sizeof($result);
			return $num;
		}
		
		public function get_users()
		{
			$this->db->select('last_logout');
			$res=$this->db->get('admin')->row();
			$last=$res->last_logout;
			//echo "<pre>";print_r($last);die;
			$this->db->select('created');
			$this->db->where('created >',$last);
			$result=$this->db->get('regi')->result();
			$num=sizeof($result);
			return $num;
		}


		public function get_order()
		{
			$this->db->select('last_logout');
			$res=$this->db->get('admin')->row();
			$last=$res->last_logout;
			//echo "<pre>";print_r($last);die;
			$this->db->select('ordered_on');
			$this->db->where('ordered_on >',$last);
			$result=$this->db->get('orders')->result();
			$num=sizeof($result);
			return $num;
		}
	}
?>