<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Image_model extends CI_Model
{
	public function add_image($imageName,$product_id)
	{
		
		$data = array ( 'p_id' => $product_id,
						'image' => $imageName,
						'small_image' => $imageName );
		$res = $this->db->insert('images',$data);
		if($res)
		{
			return TRUE;
		}
	}
	
	public function getPhotos($p_id)
	{
		$this->db->where('p_id',$p_id);
		$res = $this->db->get('images');
		//echo "<pre>";print_r($res);die;
		return $res->result();
		
	}
	
	public function getPhotos_delete($image_id)
	{
		$this->db->where('image_id',$image_id);
		$res = $this->db->get('images');
		//echo "<pre>";print_r($res);die;
		return $res->result();
		
	}
	
	public function delete_image($image_id)
		{
				$this->db->where('image_id',$image_id);
				$this->db->delete('images');
				return true;
		}
 
}