<?php
class Single_model extends CI_Model {
		
		public function get_product($id)
		{
		
			$this->db->where('p_id',$id);
			$query = $this->db->get('product');
			return $query->result();
		}
		
		public function get_num($id)
		{
			$this->db->where('c_id',$id);
			$query=$this->db->get('product');
			return $query;
		}
		public function get_images($id)
		{
			//echo $id;
			//$this->db->select('image,small_image');
			$this->db->where('p_id',$id);
			$query = $this->db->get('images');
			return $query->result();
			
		}
}
?>