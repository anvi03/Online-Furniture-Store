<?php 
class User_Model extends CI_Model
{
	
}
?>