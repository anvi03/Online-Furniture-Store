<?php
class Nread_model extends CI_Model
{
	public function get_rnews()
	{
		//$this->db->where('status',1);
		
		//$this->db->where('p_id',$id);
		$query = $this->db->get('News');
		
		return $query->result();
		
	}
}
?>