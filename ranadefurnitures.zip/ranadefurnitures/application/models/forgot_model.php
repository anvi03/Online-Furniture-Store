<?php
class forgot_model extends CI_Model
{
public function retrive($uname,$email)
	{
		
		//$this->db->set('registerd','NOW()',FALSE);
		$this->db->where('username',$uname);
		$this->db->where('email',$email);
		$result=$this->db->get('regi');
		
		if($result->num_rows()==1)
		{
			return true;
		}
	}
	public function generated($npwd,$uname,$email)
	{
		
		//$this->db->set('registerd','NOW()',FALSE);
		$this->db->where('username',$uname);
		$this->db->where('email',$email);
		$arr=array(
				'password'=>md5($npwd)
			);
		$result=$this->db->update('regi',$arr);
		if($result)
		{
			return TRUE;
		}
	}
}
?>