<?php 
	class Cart_Model extends CI_Model
	{
		function update_cart($rowid, $qty, $price, $amount)
	    {
			$data = array(
				'rowid'   => $rowid,
				'qty'     => $qty,
				'price'   => $price,
				'amount'   => $amount
			);
	
			$this->cart->update($data);
	   }
	}
?>