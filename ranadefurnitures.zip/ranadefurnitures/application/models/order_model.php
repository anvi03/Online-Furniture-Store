<?php 
class Order_Model extends CI_Model
{
		public function get_cust_id($uname)
		{
			$this->db->where('username',$uname);
			$query = $this->db->get('regi');
			return $query->row();
		}
		public function inert_detail($detail)
		{
			$this->db->set('ordered_on','NOW()',FALSE);
			$res=$this->db->insert('orders',$detail);
			if($res)
			{
				return true;	
			}	
		}	
		public function insert_product($product)
		{
			$res=$this->db->insert('order_items',$product);
			if($res)
			{
				return true;	
			}
		}
		public function order_details($ord)
		{
			$this->db->where('order_no',$ord);
			$query = $this->db->get('orders');
			return $query->result();
			//echo "<pre>";print_r($query);die;
		}
		public function get_order_no($order)
		{
			//echo $order;die;
			$this->db->select('product_id,quantity');
			$this->db->where('order_id',$order);
			$query = $this->db->get('order_items');
			//echo "<pre>";print_r($query);die;
			return $query->result_array();
			
		}
		public function get_product($productid)
		{
			
				//echo "<pre>";print_r($pid);die;
				$this->db->select('p_name,p_price,p_desc_short');
				$this->db->where('p_id',$productid);
				$query = $this->db->get('product');
				return $query->result_array();
				
		}
	
}
?>