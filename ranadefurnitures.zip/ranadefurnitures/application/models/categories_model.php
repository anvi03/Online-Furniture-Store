<?php
class Categories_model extends CI_Model {
		
		public function get_categories($limit,$offset)
		{
			$this->db->where('c_status',1);
			$query = $this->db->get('categories',$limit,$offset);
			return $query->result();
		}
		public function get_num()
		{
			$query=$this->db->get('categories');
			return $query;
		}
		public function view()
		{
		
			$query = $this->db->get('categories');
			
			return $query->result();
		}
		public function get_parent_category()
		{
			$this->db->where('parent_id',0);
			$query = $this->db->get('categories');
			return $query->result();
			
		}
		public function get_child_category($id)
		{
			$this->db->where('parent_id',$id);
			$query = $this->db->get('categories');
			return $query->result_array();
		}
		public function view_cat($id)
		{
			$this->db->where('c_id',$id);
			$query = $this->db->get('categories');
			
			return $query->result();
		}
		public function view_categories($limit,$offset)
		{
			$this->db->where('c_status',1);
			$query = $this->db->get('categories',$limit,$offset);
			return $query->result();
		}
		public function view_sub_categories($id)
		{
			$this->db->where('parent_id',$id);
			$query = $this->db->get('categories');
			return $query->result();
			
		}
		public function get_numrows()
		{
			$this->db->order_by("c_id","desc");
			$result=$this->db->get('categories');
			
			return $result->num_rows();
		}
}
?>