<?php 
	class Banner_model extends CI_Model
	{
		public function get_banner()
		{
			$this->db->where('status',1); 
			$query = $this->db->get('banner');
			return $query->result();
		}
		public function arriaval_product()
		{
			$this->db->order_by('p_id','desc');
			$this->db->select('p_name,p_image');
			$query = $this->db->get('product',6);
			return $query->result();
		}
	}
?>