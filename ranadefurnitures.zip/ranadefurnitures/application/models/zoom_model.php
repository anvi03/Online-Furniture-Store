<?php
class zoom_model extends CI_Model
{
	public function get_product($id)
	{
		//$this->db->where('status',1);
		
		$this->db->where('p_id',$id);
		$query = $this->db->get('product');
		
		return $query->result();
		
	}
}
?>