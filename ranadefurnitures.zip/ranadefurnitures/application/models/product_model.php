<?php
class Product_model extends CI_Model {
		
		public function get_product()
		{
			$this->db->where('p_status',1);
			$query = $this->db->get('product');
			return $query->result();
		}
		public function view_product($id,$limit,$offset)
		{
			
			$this->db->where('p_status',1);
			$this->db->where('c_id',$id);
			$query = $this->db->get('product',$limit,$offset);
			//echo "<pre>";print_r($query);die;
			return $query->result();
		}
		
		public function get_numrows()
		{
			$this->db->order_by("p_id","desc");
			//$this->db->where('c_id',$id);
			$result=$this->db->get('product');
			//echo "<pre>";print_r($result);die;
			return $result->num_rows();
		}
		
}
?>