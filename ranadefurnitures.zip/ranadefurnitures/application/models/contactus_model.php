<?php
class Contactus_model extends CI_Model {
	
	public function __construct()
	{
		$this->load->database();
	}
	public function contactus()
	{
			//$date = NOW();
			$this->db->set('contact_date','NOW()',FALSE);
			$data = array(
			'contact_name' => $this->input->post('name'),
			'contact_email' =>$this->input->post('email'),
			'company_name' =>$this->input->post('company_name'),
			'Subject' =>$this->input->post('subject')
			);
			$query = $this->db->insert('contacts',$data);
			return $query;

	}
}
		
		