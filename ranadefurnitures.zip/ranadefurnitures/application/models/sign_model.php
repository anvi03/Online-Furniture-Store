<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sign_model extends CI_Model 
{	
	public function cheak_login()
	{
		$username = $this->input->post('username');
		$pass = md5($this->input->post('password'));
		//$this->db->order_by('cat_id' , 'desc');
		$this->db->where('username',$username);
		$this->db->where('password',$pass);
		$qry=$this->db->get('regi');
		
		//echo "<pre>";print_r($qry->result());die;
		if($qry->num_rows() == 1)
		{
			
			//return $qry->result();
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	public function in_cart($data)
	{
		
		$dat=$this->db->insert('cart',$data);
		if($dat)
		{
			return $dat;
		}
	}
	public function del_cart($data)
	{
		$this->db->where('id',$data);
		$dat=$this->db->delete('cart');
		if($dat)
		{
			return $dat;
		}
	}
	public function get_cart($data)
	{
		$this->db->where('id',$data);
		$dat=$this->db->get('cart');
		if($dat)
		{
			return $dat->result();
		}
	}
	public function display_user()
	{
		//$email=$this->session->userdata('email');
		$uname=$this->session->userdata('username');
		//$this->db->where('email',$email);
		$this->db->where('username',$uname);
		$qry=$this->db->get('regi');
		
		if($qry)
		{
			
			return $qry->result();
		}
	
	}
	public function uname($email,$pass)
	{
		$passw = md5($pass);
		$this->db->where('username',$email);
		$this->db->where('password',$passw);
		$qry=$this->db->get('regi');
		//echo "<pre>";print_r($qry);die;
		return $qry->row();
		
	}
	
	public function update_user($data)
	{
		$qry=$this->db->update('regi',$data);
		if($qry)
		{
			
			return TRUE;
		}
	}
	public function chkpwd()
	{
		//echo $this->session->userdata('username');die;
		$this->db->where('id', $this->session->userdata('id'));
		$this->db->where('password' , md5($this->input->post("current_pwd")));
		$this->db->where('username', $this->session->userdata('username'));

		$qry=$this->db->get('regi');
		//echo "<pre>";print_r($qry);die;
		if($qry->num_rows == 1)
		{
			//echo 'hiii';die;		
			return TRUE;
		}
		else
		{
			
			//echo 'byyyyyy';die;
			return FALSE;
		}
		
	}
	public function updpwd()
	{
			$data = array(
			'password' => md5($this->input->post('new_pwd'))
							);
			$this->db->where('id', $this->session->userdata('id'));
			$this->db->where('username', $this->session->userdata('username'));
			$qry=$this->db->update('regi',$data);
			//echo $qry->num_rows;die;	 
		
		if($qry)
		{
			
			return TRUE;
		}
	}
	
}