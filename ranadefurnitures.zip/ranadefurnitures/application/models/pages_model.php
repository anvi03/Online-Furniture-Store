<?php
class Pages_model extends CI_Model
{
	public function offers($id)
	{
		$this->load->database();
		$this->db->where("id",$id);
		$res=$this->db->get('offers');
		return $res->result_array();
	}
	
	public function offerss()
	{
		$this->load->database();
		$this->db->order_by("id","DESC");	
		$res=$this->db->get('offers');
		return $res->result_array();
	}
	public function categories()
	{
		$this->load->database();
		$res=$this->db->get('category');
		return $res->result();
	}
	
	
	public function views()
	{
		$this->load->database();
		$query=$this->db->get('news');
		return $query->result();
	}
	public function get_stock($id)
	{
		$this->db->where('p_id',$id);
		$this->db->select('p_qty');
		$result=$this->db->get('product');
	
		return $result->result_array();
		
	}
	public function update_stock($id,$qty)
	{
		$data=array('p_qty'=>$qty);
		$this->db->where('p_id',$id);
		$this->db->update('product',$data);
	}
	public function products()
	{
		$this->load->database();
		$this->db->limit(12);
		$this->db->order_by('p_id','desc');
		$query=$this->db->get('products');
		return $query->result();
	}
	
	
}

?>