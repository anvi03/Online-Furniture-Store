<?php
class Model_Changepsw extends CI_Model
{
	public function changepwd($username,$firstname,$lastname,$email,$mobile_no,$password)
	{
		$this->db->set('created','NOW()',FALSE);
		$data=array(
					'username'=>$username,
					'firstname'=>$firstname,
					'lastname'=>$lastname,
					'mobile_no'=>$mobile_no,
					'email'=>$email,
					'password'=>$password
				);
		
		$res=$this->db->insert('regi',$data);
		
		if($res)
		{
			return TRUE;
		}
		
		
	}
}
?>