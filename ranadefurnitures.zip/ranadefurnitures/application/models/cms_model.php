<?php

class Cms_model extends CI_Model{

	public function get_content()
	{
		$this->db->select('*');
		$this->db->where('status',1);
		$this->db->where('page_title','about');
		$this->db->select('content');
		$query = $this->db->get('cms');
		return $query->result();
	}
}

?>