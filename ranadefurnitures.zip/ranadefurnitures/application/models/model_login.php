<?php
class Model_Login extends CI_Model
{
	public function login()
	{
		
		$username=$this->input->post('username');
		$password=trim(md5($this->input->post('password')));
		
		$data = array(
			'username' => "$username",
			'password' => "$password"
		);
		$query=$this->db->get_where('regi',$data);
		if($query ->num_rows()==1)
		{
			return true;
		}
	}
}
?>