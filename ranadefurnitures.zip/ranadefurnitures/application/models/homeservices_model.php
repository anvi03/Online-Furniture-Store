<?php 
class Homeservices_Model extends CI_Model
{
	public function get_services()
	{
		$this->db->select('*');
		$this->db->where('status',1);
		$this->db->where('page_title','homeservices');
		$query = $this->db->get('cms');
		return $query->result();
	}
}
?>