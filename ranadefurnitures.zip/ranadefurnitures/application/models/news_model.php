<?php
class News_model extends CI_Model {
		
		public function get_news($limit,$offset)
		{
			$this->db->where('status',1);
		
			$query = $this->db->get('news',$limit,$offset);
			return $query->result();
		}
		
		public function get_num()
		{
			$query=$this->db->get('news');
			return $query;
		}
		public function get_per_news($id)
		{
			$this->db->where('id',$id);
			$query = $this->db->get('news');
			return $query->result();
		}
		public function get_numrows()
		{
			$this->db->order_by("id","desc");
			$result=$this->db->get('news');
			
			return $result->num_rows();
		}
}
?>