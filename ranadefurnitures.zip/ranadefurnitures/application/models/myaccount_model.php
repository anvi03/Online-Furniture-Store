<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Myaccount_model extends CI_Model
{
	/*public function index()
	{
		if($this->session->userdata('username')!="")
		{
			$this->session->set_userdata('err','not allowed');
			redirect('login');	
		}	
	}*/
	public function subscribe($uname)
	{
		
		
		//$this->db->get('regi');
		//if($r->num_rows()==0)
		//{
			
			$ar=array('subscription'=>'1');
			$this->db->where('username',$uname);
			$result=$this->db->update('registration',$ar);
			if($result)
			{
				return true;
				/*$this->db->where('username',$uname);
				$res=$this->db->get('regi');
				$res=$res->result_array();
				
				$arr=array('s_email'=>$email= $res[0]['email']);
				$this->db->set('s_time','NOW()',FALSE);
				$ress=$this->db->insert('subscribe',$arr);
				if($ress)
				{
					return TRUE;	
				}*/
				/*echo"<pre>";
				print_r($res->result_array());
				die;*/
			}
			
		//}
	}
	public function add_wish($id)
	{
			$this->db->where('username',$this->session->userdata('username'));
			$this->db->select('id');
			$rid=$this->db->get('regi');
			$rid=$rid->result_array();
			$rid=$rid[0]['id'];
			$wish=array(
			'cust_id'=>$rid,
			'product_id'=>$id
			);
			$this->db->insert('wishlist',$wish);
	}
	public function unsubscribe($uname)
	{
		
		//$this->db->get('regi');
		//if($r->num_rows()==0)
		//{
			
			$ar=array('subscription'=>'0');
			$this->db->where('username',$uname);
			$result=$this->db->update('registration',$ar);
			if($result)
			{
				return true;	
			}
			/*if($result)
			{
				$this->db->where('username',$uname);
				$res=$this->db->get('regi');
				$res=$res->result_array();
				
				$arr=array('s_email'=>$email= $res[0]['email']);
				$this->db->set('s_time','NOW()',FALSE);
				$ress=$this->db->delete('subscribe',$arr);
				if($ress)
				{
					return TRUE;	
				}
				/*echo"<pre>";
				print_r($res->result_array());
				die;
					}*/
	}
	public function get_all_wishlist()
	{
			$this->db->where('username',$this->session->userdata('username'));
			$this->db->select('id');
			$rid=$this->db->get('regi');
			$rid=$rid->result_array();
			$rid=$rid[0]['id'];
			$this->db->where('cust_id',$rid);
			$result=$this->db->get('wishlist');
			$result=$result->result_array();
			if($result)
			{
				foreach($result as $r)
				{
					$arr[]=$r['product_id'];	
				}
				$this->db->or_where_in('p_id',$arr);
				$product=$this->db->get('product');
				return $product->result_array();
				
			}
			else
			{
				return false;	
			}
			
	}
	public function remove_product_wishlist($id)
	{
			$this->db->where('username',$this->session->userdata('username'));
			$this->db->select('id');
			$rid=$this->db->get('regi');
			$rid=$rid->result_array();
			$rid=$rid[0]['id'];
			
			$this->db->where('cust_id',$rid);
			$this->db->where('product_id',$id);
			$res=$this->db->delete('wishlist');
			if($res)
			{
				return true;		
			}
				
	}
	public function my_whishlist($uname,$id)
	{
		$this->db->set('created','NOW()',FALSE);
		$this->db->set('updated','NOW()',FALSE);
		$this->db->where('username',$uname);
		$this->db->where('product_id',$id);
		$r=$this->db->get('whishlist');
		if($r->num_rows()==0)
		{
			$arr=array('username'=>$uname,'product_id'=>$id);
			$result=$this->db->insert('whishlist',$arr);
			if($result)
			{
				return TRUE;
			}
		}
		else
		{
			$this->db->where('username',$uname);
			$this->db->where('product_id',$id);
			$result=$this->db->delete('whishlist');
			if($result)
			{
				return TRUE;
			}
		}
		//$qry=$this->db->get('regi');
		//return $qry->row();	
	}
	public function  my_whishes($uname)
	{
		
			$result=$this->db->get_where('whishlist',array('username'=>$uname));
			/*echo "<pre>";
			print_r($result->result_array());
			die;*/
			if($result->num_rows>0)
			{
				$arr_obj=$result->result_array();
			}
			else 
			{
				$arr_obj=$this->session->set_userdata('err',"Whishlist Not Found.");
			}
			return $arr_obj;
			
		//	$uname=$this->session->userdata('username');
			/*echo $uname;
			die;*/
			//$result=$this->db->get_where('whishlist',array('username'=>$uname));
			/*echo "<pre>";
			print_r($result->result_array());
			die;*/
			//if($result->num_rows>0)
			//{
				//$arr_obj=$result->result_array();
		//	}
			//else 
		//	{
				//$arr_obj=$this->session->set_userdata('err',"Whishlist Not Found.");
			//}
			//return $arr_obj;
			
	}
	public function get_notify()
	{	//$this->db->get_where('news',array('status'== '1'));
		$this->db->order_by('contact_id','desc');
		$result=$this->db->get('contact',3);
		if($result->num_rows>0 )
		{
			//$arr_obj=$this->session->set_userdata('msg','Notification arrived');
			$arr_obj=$result->result();
		}
		
		return $arr_obj;
	}
	public function get_regi_notify()
	{	//$this->db->get_where('news',array('status'== '1'));
		$this->db->order_by('regi_id','desc');
		$result=$this->db->get('regi',3);
		if($result->num_rows>0 )
		{
			//$arr_obj=$this->session->set_userdata('msg','Notification arrived');
			$arr_obje=$result->result();
		}
		
		return $arr_obje;
	}
	public function count_regi()
	{
		$this->db->order_by('regi_id');
		$result=$this->db->get('regi');
		return $result->num_rows();
	}
	public function count_feedbacks()
	{
		$this->db->order_by('contact_id');
		$result=$this->db->get('contact');
		return $result->num_rows();
	}
	public function checkoldpwd()
	{
		//$cpwd=md5($this->input->post('Currentpwd'));
		$opwd=$this->input->post('Currentpwd');
		$this->db->where('password',$opwd);	
		$number=$this->db->get('registration');	
		return $number->num_rows();
		
	}
	public function update_password()
	{
		$npwd=$this->input->post('NewPassword');
		$data = array('password'=>$npwd);
		$this->db->where('username',$this->session->userdata('username'));
		$this->db->update('registration',$data);
	}
	public function get_details()
	{
		$this->db->where('username',$this->session->userdata('username'));
		$qry=$this->db->get('registration');
		/*echo "<pre>";
		print_r($qry->result_array());
		die;*/
		return $qry->result_array();
	}
	public function get_regi_details()
	{
		/*echo $this->session->userdata('username');
		die;*/
		$this->db->where('username',$this->session->userdata('username'));
		$qry=$this->db->get('registration');
		return $qry->result_array();
	}
	
	public function get_data($uname)
	{
		$this->db->where('username',$uname);
		$qry=$this->db->get('users_data');
		return $qry->row();
		/*$id=$this->session->userdata('id');
		//if($this->session->userdata('username'))
		if($this->session->userdata('logged_in'))
		{
			$this->db->where('id',$id);
			$qry=$this->db->get('users_data');
			return $qry->row();	
		}
		else
		{
			$this->session->set_userdata('err','Access permission denied');
			redirect('login');	
		}*/
	}
	public function set_data($id,$data)
	{
		if($this->session->userdata('username'))
		{
			$this->db->where('id',$id);
			$res=$this->db->update('users_data',$data);
			if($res)
			{
				return TRUE;
			}	
		
		}
		else
		{
			$this->session->set_userdata('err','access denied');
			redirect('login');	
		}
		
	}
	public function check_user($id)
	{
		if($this->$session->userdata('username'))
		{
			$this->db->select('password');
			$this->db->where('id',$id);
			$qry=$this->db->get('users_data');
			return $qry->row();	
		}	
	}
	public function update_user()
	{
		$data=array(
					'f_name'=>$this->input->post('f_name'),
					'l_name'=>$this->input->post('l_name'),
					'mobile_no'=>$this->input->post('mobile_no'),
					'email'=>$this->input->post('email'),
					'address'=>$this->input->post('address')
		);
			/*echo "<pre>";
			print_r($data);
			echo $this->input->post('id'); 
			die;*/
		$this->db->where('regi_id',$this->input->post('id'));
		$res=$this->db->update('registration',$data);
		if($res)
		{
			return TRUE;	
		}
	}
	public function get_whishlist($uname,$id)
	{
		$this->db->where('username',$uname);
		$this->db->where('product_id',$id);
		$r=$this->db->get('whishlist');
		if($r->num_rows()==1)
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}
?>