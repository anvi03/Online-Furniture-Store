<?php
$grand_total = 0;

if ($cart = $this->cart->contents()):
	foreach ($cart as $item):
		$grand_total = $grand_total + $item['subtotal'];
	endforeach;
endif;
?>
<div class="wrap">
		 <div class="main">
			<div class="content">
			<div class="section group">
				<div class="col span_2_of_3" style="margin-left:300px;">
				<?php if($this->session->userdata('validation_errors'))
				{
					echo $this->session->userdata('validation_errors');
					$this->session->unset_userdata('validation_errors');
				}
				?>
				  <div class="contact-form">
				<?php echo form_open('billing/save_order');?>
					<input type="hidden" name="command" />
					
						<h1 align="center">Billing Info</h1>
						<table border="0" cellpadding="2px">
							
							<span>Your Name</span>
							<span><?php echo form_input('name','','required');?></span>
							<span>Address</span><span><?php echo form_textarea('address','','required');?></span>
							<span>Email</span><span><?php echo form_input('email','','required');?></span>
							<span>Phone</span><span><?php echo form_input('phone','','required');?></span>
							<br />
							<tr><td>Order Total&nbsp;:&nbsp;&nbsp;</td><td><strong>RS<?php echo number_format($grand_total,2); ?></strong></td></tr>
							<span><input type="submit" name=""value="Place Order" /></span>
						</table>
					
				<?php echo form_close();?>
				
			      </div>
			    </div>
			  </div>
			 </div> 
		</div>
</div>				
</body>
</html>