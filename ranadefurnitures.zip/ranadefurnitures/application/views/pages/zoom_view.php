			
	    		<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
					</div>				    
              		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
        <div class="section group">
        
		<?php
		//$k=0;
		 
							if(sizeof($product)>=1)
								{
									foreach($product as $product_list): ?>
                                    <div class="grid_1_of_4 images_1_of_4" style="width:100%"> <?php //if($k==0){echo 'style="margin-left: 18px ;"';$k++;} ?>

										<div class="col_1_of_4">
                                        
                                        
                                        <h3><?php echo $name = $product_list->p_name;
											 ?></h3>

                                        
                                       <img src="<?php echo base_url();?>./uploads/product/<?php echo $product_list->p_image;?>" alt="product_image" width="350px" height="" />
                                   
						
											
                                            
                                              </div>  
                                        
                                                
                                                 
                                                 <div class="col_1_of_4">
												 <br />
                                                 
                                              	<?php   $price = $product_list->p_price ; 
											echo "Price:".$price;?>
                                            <br/>
                                           	 <?php  $description =$product_list->p_desc_short; ?>
												<?php echo "desc:".$description;?>
                                                 
                                               </div>
                                        </div>
                                                                                                
											
											
										
								<?php
									endforeach;
								}
									 

								else
								{
								?>
                                	<div>
										<!--<h2><b>No Records found...!</b></h2>-->
                                        </div>
                                        
                                       
									 
								<?php
								}
								?>
                                
	
        </div>
        </div>
        </div>
		</div>
	    	<!--<div class="section group">
				<div class="grid_1_of_4 images_1_of_4">
					 <a class="fancybox" href="<?php// echo base_url(''); ?>images/gallery-img1.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php //echo base_url(''); ?>images/gallery-img1.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img2.jpg" data-fancybox-group="gallery" title="Etiam quis mi eu elit temp"><img src="<?php// echo base_url();?>images/gallery-img2.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img3.jpg" data-fancybox-group="gallery" title="Cras neque mi, semper leon"><img src="<?php// echo base_url();?>images/gallery-img3.jpg" alt=""/><span> </span></a>
					<h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img4.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php //echo base_url();?>images/gallery-img4.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
			</div>    
			<div class="section group">
				<div class="grid_1_of_4 images_1_of_4">
					 <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img5.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img5.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img6.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img6.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img7.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img7.jpg" alt=""/><span> </span></a>
					<h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img8.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php //echo base_url();?>images/gallery-img8.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
			</div>--> 	   
		