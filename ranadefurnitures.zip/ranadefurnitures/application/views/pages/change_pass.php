<style>
.errvalidation
{
	color:#FF0000;
	float:right;
}
</style>
<div class="logo">
		<h1><span>F</span>urniture <span>M</span>all</h1>
</div>			
<div class="wrap">
    <div class="main">
	    <div class="content">
		<div class="section group" style="margin-left:300px;">
		<div class="col span_2_of_3">
			<div class="contact-form" style="padding-left:20px; padding-right:20px;">
				<div class="logo" style="margin-right:250px;">	
				  	<h1>Change Password</h1>
				</div>
				<div style="color:#006600;">
                <?php if($this->session->userdata('msg'))
					  {
					  	?><span style="color:#00CC00;"><?php echo $this->session->userdata('msg');?></span><?php 
						$this->session->unset_userdata('msg');
					  }
				?>
                </div>
				<div style="color:#FF0000;">
                <?php if($this->session->userdata('err'))
					  {
					  	?><span style="color:#FF0000;"><?php echo $this->session->userdata('err');?></span><?php 
						$this->session->unset_userdata('err');
					  }
				?>
                </div>
				<?php echo form_open('signin/chang_ppwd');?>
					    	<div>
						    	<span><?php echo form_label('Current Password'); ?></span>

								
						    	<span><?Php echo form_password('current_pwd',set_value('current_pwd'),'placeholder="Current Password" required');?></span>
								<span><?php echo form_error('current_pwd','<div class="errvalidation">','</div>');?></span>
						    </div>	
							
							<div>
						    	<span><?php echo form_label('New Password'); ?></span>

								
						    	<span><?Php echo form_password('new_pwd','','placeholder="New Password" required');?></span>
								<span><?php echo form_error('new_pwd','<div class="errvalidation">','</div>');?></span>
						    </div>
							
							<div>
						    	<span><?php echo form_label('Confirm Password'); ?></span>

								
						    	<span><?Php echo form_password('confirm_pwd','','placeholder="Confirm Password" required');?></span>
								<span><?php echo form_error('confirm_pwd','<div class="errvalidation">','</div>');?></span>
						    </div>
							<br />
							
							<div>
						   		<span><?php echo form_submit('change_pwd','Update Password');?></span>
						  </div>
				<?php echo form_close();?>			
			</div>	
		</div>	
		</div>	
		</div>
	</div>
</div>		