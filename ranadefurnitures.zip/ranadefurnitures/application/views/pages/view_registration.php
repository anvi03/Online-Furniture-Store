<style>
.errvalidation
{
	color:#FF0000;
	float:right;
}
</style>

<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
			</div>	
  </div>
  		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
	    	   	   <div class="section group">				
				<?php /*?><div class="col contact">
					<div class="contact_info">
			    	 	<h2>Find Us Here</h2>
			    	 		<div class="map">
					   			<iframe width="100%" height="175" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#666;text-align:left;font-size:12px">View Larger Map</a></small>
					   		</div>
      				</div>
      			<div class="company_address address">
				     	<h2>Ranade Furnitures :</h2>
						    	<p>shop no.19,Avishkar Apartment,</p>
						   		<p>Makarpur Road,</p>
						   		<p>Bharuch</p>
				   		<p>Phone:695971</p>
				   		<p>Fax: 9327328886</p>
				 	 	<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				</div><?php */?>			
				<div class="col span_2_of_3" style="margin-left:240px;">
                <div style="color:#0F0;">
                <?php echo $this->session->userdata('msg');
				
				
				$this->session->unset_userdata('msg');
				?>
                </div>
				  
				  <div class="contact-form">
                
                 
                  <?php //echo validation_errors('<div style="color:#F00;">','</div>');?>
                  
                  
				  	<h2>Registration</h2>
                    
                    <?php echo form_open('registration/signin');?>
                    
					    
                      
					    	<!--<div>
						    	<span><label>Name</label></span>
						    	<span><input type="text" value="" name="name" required></span>
						    </div>-->
                            
                            <div>
                           <span><?php echo form_label('Username');?></span>
						   
                           <span><?php echo form_input('username',set_value('username'),'required');?></span>
						   <span><?php echo form_error('username','<div class="errvalidation">','</div>');?></span>
                            </div>
                            <div>
                            <span><?php echo form_label('Firstname');?></span>
							
                           <span><?php echo form_input('firstname',set_value('firstname'),'required');?></span>
						   <span><?php echo form_error('firstname','<div class="errvalidation">','</div>');?></span>
                           </div>
                           <div>
                           <span><?php echo form_label('Lastname');?></span>
						   
                           <span><?php echo form_input('lastname',set_value('lastname'),'required');?></span>
                          <span><?php echo form_error('lastname','<div class="errvalidation">','</div>');?></span> 
                           </div>
                           <div>
                          <span> <?php echo form_label('Email');?></span>
						  
                          <span><?php echo form_input('email',set_value('email'),'required');?></span>
						  <span><?php echo form_error('email','<div class="errvalidation">','</div>');?></span>
                           
                           </div>
						   
						   <div>
                          <span> <?php echo form_label('Mobile No');?></span>
						  
                          <span><?php echo form_input('mobile_no',set_value('mobile_no'),'required');?></span>
						  <span><?php echo form_error('mobile_no','<div class="errvalidation">','</div>');?></span>
                           
                           </div>
                            <div>
                          <span><?php echo form_label('Password');?></span>
						  
                          <span><?php echo form_password('password','','required');?></span>
						  <span><?php echo form_error('password','<div class="errvalidation">','</div>');?></span>
                           </div>
                           <div>
                          <span><?php echo form_label('Confirmpassword');?></span>
						  
                           <span><?php echo form_password('confirmpassword','','required');?></span>
                          <span><?php echo form_error('confirmpassword','<div class="errvalidation">','</div>');?></span>
						  <br /> 
                           </div>
                           <div>
                           
                        <?php echo form_submit('Submit','SignUp');?>
                           </div>
                           
                           
                           
                           
						  <!-- <div>
						    	<span><label>E-mail</label></span>
						    	<span><input type="text" value="" name="email" required></span>
						    </div>-->
						  <!--  <div>
						     	<span><label>Company Name</label></span>
						    	<span><input type="text" value="" name="cname" required></span>
						    </div>-->
						   <!-- <div>
						    	<span><label>Subject</label></span>
						    	<span><textarea name="subject" required> </textarea></span>
						    </div>-->
						  <!-- <div>
						   		<span><input type="submit" name="submit" value="Submit"></span>
						  </div>-->
					    <!--</form>-->
                        <?php echo form_close();?>
                        &nbsp;&nbsp;
                        <?php //echo anchor('website/signin',"signin"); ?>
                        </div>
                        
				    </div>
  				</div>				
			  </div>
		</div> 
		</div>  
     </div>	
    


