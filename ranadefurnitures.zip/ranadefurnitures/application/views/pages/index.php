	    		<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
					</div>	
			    <div class="header_bottom">	
			    	<div class="wrap">
			    	<!--- Slider --->				
						<section class="slider">
					        <div class="flexslider">
					          <ul class="slides">
							  <?php foreach($banner as $banner_item): ?>
							  	<li data-thumb="<?php echo base_url();?>./uploads/banner/<?php echo $banner_item->image;?>">
								
								<img src="<?php echo base_url();?>./uploads/banner/<?php echo $banner_item->image;?>" alt="banner_item" /></li>
							  <?php endforeach;?>
							   
					            <?php /*?><li data-thumb="<?php echo base_url('');?>images/slider-1.jpg">
					  	    	    <img src="<?php echo base_url('');?>images/slider-1.jpg" alt=""/>
					  	    		</li>					  	    		
					  	    		<li data-thumb="<?php echo base_url('');?>images/slider-3.jpg">
					  	    	    <img src="<?php echo base_url('');?>images/slider-3.jpg" alt=""/>
					  	    		</li>
					  	    		<li data-thumb="<?php echo base_url('');?>images/slider-2.jpg">
					  	    	    <img src="<?php echo base_url('');?>images/slider-2.jpg" alt=""/>
					  	    		</li>
					  	    		<li data-thumb="<?php echo base_url('');?>images/slider-4.jpg">
					  	    	    <img src="<?php echo base_url('');?>images/slider-4.jpg" alt=""/>
					  	    		</li>
					  	    		<li data-thumb="<?php echo base_url('');?>images/slider-5.jpg">
					  	    	    <img src="<?php echo base_url('');?>images/slider-5.jpg" alt=""/>
					  	    		</li><?php */?>
					          </ul>
					        </div>
					   </section>
					   <!-- jQuery -->
  
			     <!--- End Slider --->
		   </div>
	  </div>
  </div>		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
	    	<div class="content_top">
	    	  <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
					<div class="num-heading">
				       <div class="number">
							<figure><span>1</span></figure>
					    </div>
					       		<div class="heading">								
									<h4>Doors</h4>
									<h4>design</h4>
							     </div>
							 <div class="clear"></div>
						</div> 
						    <div class="heading-desc">	
							     	<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
					       		</div>	
				 </div>
				<div class="col_1_of_4 span_1_of_4">
					<div class="num-heading">
				       <div class="number">
							<figure><span>2</span></figure>
					    </div>
					       		<div class="heading">								
									<h4>Interior</h4>
									<h4>design</h4>
							     </div>
							 <div class="clear"></div>
						</div> 
						    <div class="heading-desc">	
							     	<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
					       		</div>					
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<div class="num-heading">
				       <div class="number">
							<figure><span>3</span></figure>
					    </div>
					       		<div class="heading">								
									<h4>Exterior</h4>
									<h4>design</h4>
							     </div>
							 <div class="clear"></div>
						</div> 
						    <div class="heading-desc">	
							     	<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
					       		</div>					
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<div class="num-heading">
				       <div class="number">
							<figure><span>4</span></figure>
					    </div>
					       		<div class="heading">								
									<h4>Outdoor</h4>
									<h4>design</h4>
							     </div>
							 <div class="clear"></div>
						</div> 
						    <div class="heading-desc">	
							     	<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
					       		</div>
				    </div>
			   </div>
	    	</div>	
	    	   <div class="content-bottom">
		    	   	<div class="section group">
						<div class="col_1_of_3 span_1_of_3">
							<h3>What we do</h3>
							<?php foreach($services as $content)
							{
							
									echo $content->content; 
							}?>
							   <!--<ul>
		  						<li>Lorem ipsum dolor sit amet qui officia</li>
		  						<li>Duis aute irure dolor in culpa qui</li>
		  						<li>Sunt in culpa qui officia vel illum qui</li>
		  						<li>vel illum qui dolorem eum wise man therefore</li>
		  						<li>The wise man therefore in culpa qui officia</li>
		  						<li>Sunt in culpa qui officia culpa qui officia</li>
		  						<li>Lorem ipsum dolor sit amet qui officia</li>
		  						<li>Duis aute irure dolor in culpa qui</li>
		  						<li>Sunt in culpa qui officia vel illum qui</li>
		  						<li>vel illum qui dolorem eum wise man therefore</li>
		  						<li>The wise man therefore in culpa qui officia</li>
		  						<li>Sunt in culpa qui officia culpa qui officia</li>
		  			        </ul>-->
						</div>
					<div class="col_1_of_3 span_1_of_3">
						<h3>Welcome</h3>
						<img src="<?php echo base_url('');?>images/welcome.jpg" alt=""/>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
					</div>
						<div class="col_1_of_3 span_1_of_3">
						  <div class="new-products">
						  
							<h3>New Products</h3>
							<?php foreach($ariaval_pro as $pro_data)
								  {?>
								<p><a class="fancybox" href="<?php echo base_url();?>./uploads/product/<?php echo $pro_data->p_image?>" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php echo base_url('');?>./uploads/product/<?php echo $pro_data->p_image?>" alt="" height=100px/><span> </span></a></p>
								<?php }?>
								<?php /*?><p><a class="fancybox" href="images/product2.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php echo base_url('');?>images/product2.jpg" alt=""/><span> </span></a></p>
								<p><a class="fancybox" href="images/product3.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php echo base_url('');?>images/product3.jpg" alt=""/><span> </span></a></p>
								<p><a class="fancybox" href="images/product4.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php echo base_url('');?>images/product4.jpg" alt=""/><span> </span></a></p>
								<p><a class="fancybox" href="images/gallery-img4.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php echo base_url('');?>images/gallery-img4.jpg" alt=""/><span> </span></a></p>
								<p><a class="fancybox" href="images/gallery-img8.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php echo base_url('');?>images/gallery-img8.jpg" alt=""/><span> </span></a></p><?php */?>
					</div>
				  </div>
			   </div>
		    </div>
		</div> 
		</div>  
     </div>	  