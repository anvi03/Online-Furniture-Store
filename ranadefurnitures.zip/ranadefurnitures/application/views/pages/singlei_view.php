<!--the popup in multiimage-->
  <link rel="stylesheet" href="<?php echo base_url('');?>css/popup/vlightbox1.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo base_url('');?>css/popup/visuallightbox.css" type="text/css" media="screen" />
<script src="<?php echo base_url('');?>js/popup/jquery.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url('');?>js/popup/visuallightbox.js" type="text/javascript"></script>
        	<script src="<?php echo base_url('');?>js/popup/thumbscript1.js" type="text/javascript"></script>
	<script src="<?php echo base_url('');?>js/popup/vlbdata1.js" type="text/javascript"></script>
		<!-- End VisualLightBox.com HEAD section -->

							<div class="logo">
								<h1><span>F</span>urniture <span>M</span>all</h1>
							</div>				    
							
		   <div class="wrap">
			 <div class="main">
				<div class="content">
				<div class="section group">
				
				
				
				<?php
				
				
				 
									if(sizeof($product)>=1)
										{
											foreach($product as $product_list): ?>
											<div class="grid_1_of_4 images_1_of_4">
		
												<div class="col_1_of_4">
												
												
							   
	
	<a class="vlightbox1"  href="<?php echo base_url(); ?>uploads/product/<?php echo $product_list->p_image?>"  title="<?php echo $product_list->p_name;?>"><img src="<?php echo base_url();?>./uploads/product/<?php echo $product_list->p_image;?>" alt="" width="350px" align="left" /></a>
	
	
	
	<?php /*?><a class="fancybox" href="<?php echo base_url(); ?>uploads/product/<?php echo $product_list->p_image?>" data-fancybox-group="gallery"><img src="<?php echo base_url();?>./uploads/product/<?php echo $product_list->p_image;?>" alt="product_image" width="400px" /><span> </span></a><?php */?>							
													
								<div class="logo1">
								<h2><?php echo $name = $product_list->p_name;?></h2>
								 </div>
												 
													 <div style="float:left;">
													 <?php foreach($product_images as $pimg)
	{
	
			?>
			<a class="vlightbox1"  href="<?php echo base_url(); ?>uploads/product/<?php echo $pimg->p_id;?>/full/<?php echo $pimg->small_image;?>" title=""><img src="<?php echo base_url();?>./uploads/product/<?php echo $pimg->p_id;?>/thumbs/<?php echo $pimg->small_image;?>" alt="" width="100px" align="left" /></a><?php 
	}?></div></div>	
	
													<?php   $price = $product_list->p_price ; 
													//echo "Price:".$price;?>
													<br/>
													<?php  $description = $product_list->p_desc_long;?>
													<?php $id = $product_list->p_id;
														  $stock = $product_list->p_qty;?>
													   <br/>
													   <?php $image = $product_list->p_image;?>
															<?php  //$qty = $product_list->p_qty;?>
													
													
														
																				
		
												<div class="col_1_of_4_1">
												
												<?php echo form_open('cart');
													echo form_hidden('id',$id);
													echo form_hidden('name',$name);
													echo form_hidden('stock',$stock);
													echo form_hidden('price',$price);
													echo form_hidden('image',$image);
													
												?>
													<div class="logo3">
													<h3>
														<span>
															<?php //echo $name; ?>
														</span>	
													</h3>
														<div style=" width:550px;">
														<?php echo $description; ?>
														</div>
														<br  />
														Price:<big>
																<?php echo $price; ?></big>
																
														<br  />
														
														<?php echo form_label('Quantity');?>																		 															<input type="number" value="1" min="1" name="qty" required/>		
														<br  />
														
														<?php
																																												 																echo form_submit('submit','Add to Cart');
																		
																echo form_submit('wishlist','Add to Wishlist');																																												
																echo form_close();
																?>
													</div>
													<?php /*?><table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; margin-left:50px; margin-top:50px; font-size:15px;" height="100%" width="80%">
													<tr>
														
														
														<td><?php echo $name; ?></td>
													</tr>
													
													<tr>
																
																<td><?php echo $description; ?></td>
													</tr>
													<tr>
													<td>
													<?php echo anchor('read_more','Read More');?>
													</td>
													</tr>
													<tr>
														<td></td>
													</tr>
													<tr>
																<td>Price:<big style="color:green">
																<?php echo $price; ?></big></td>
													</tr>
													<tr>
																<td>																			     														<?php echo form_label('Quantity');?>																		 															<input type="number" value="1" min="1" name="qty" required/></td>
													</tr>
													<tr>
														<td>
																<?php
																																												 																echo form_submit('submit','Add to Cart');
																		
																echo form_submit('wishlist','Add to Wishlist');																																												
																echo form_close();
																?>
														</td>
													</tr>
													
													</table>
<?php */?>													</div>
													
													
												
											</div>
										<?php
											endforeach;
										}
											 
		
										else
										{
										?>
											<div>
												<h2><b>No Records found...!</b></h2>
												</div>
												
											 
										<?php
										}
										?>
			
				</div>
				
					<?php echo $this->pagination->create_links();?>        
				</div>
				</div>
					<!--<div class="section group">
						<div class="grid_1_of_4 images_1_of_4">
							 <a class="fancybox" href="<?php// echo base_url(''); ?>images/gallery-img1.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php //echo base_url(''); ?>images/gallery-img1.jpg" alt=""/><span> </span></a>
							 <h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
						<div class="grid_1_of_4 images_1_of_4">
							  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img2.jpg" data-fancybox-group="gallery" title="Etiam quis mi eu elit temp"><img src="<?php// echo base_url();?>images/gallery-img2.jpg" alt=""/><span> </span></a>
							 <h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
						<div class="grid_1_of_4 images_1_of_4">
							  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img3.jpg" data-fancybox-group="gallery" title="Cras neque mi, semper leon"><img src="<?php// echo base_url();?>images/gallery-img3.jpg" alt=""/><span> </span></a>
							<h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
						<div class="grid_1_of_4 images_1_of_4">
							  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img4.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php //echo base_url();?>images/gallery-img4.jpg" alt=""/><span> </span></a>
							 <h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
					</div>    
					<div class="section group">
						<div class="grid_1_of_4 images_1_of_4">
							 <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img5.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img5.jpg" alt=""/><span> </span></a>
							 <h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
						<div class="grid_1_of_4 images_1_of_4">
							  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img6.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img6.jpg" alt=""/><span> </span></a>
							 <h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
						<div class="grid_1_of_4 images_1_of_4">
							  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img7.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img7.jpg" alt=""/><span> </span></a>
							<h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
						<div class="grid_1_of_4 images_1_of_4">
							  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img8.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php //echo base_url();?>images/gallery-img8.jpg" alt=""/><span> </span></a>
							 <h3>Product Name</h3>
							 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
						</div>
					</div>--> 	   
					<div class="clear"></div>
				  
			 
		
		
		</div>