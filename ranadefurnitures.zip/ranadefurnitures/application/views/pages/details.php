<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Free Furniture Mall Website Template | Blog :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href='http://fonts.googleapis.com/css?family=Milonga' rel='stylesheet' type='text/css'>
</head>
<body>
  <div class="header">
		 <div class="header_top">
		 	 <div class="wrap">
		 			<div class="social-icons">					
		                <ul>
		                    <li><a class="facebook" href="#" target="_blank"> </a></li>
		                    <li><a class="twitter" href="#" target="_blank"></a></li>
		                    <li><a class="googleplus" href="#" target="_blank"></a></li>
		                    <li><a class="pinterest" href="#" target="_blank"></a></li>
		                    <li><a class="dribbble" href="#" target="_blank"></a></li>
		                    <li><a class="vimeo" href="#" target="_blank"></a></li>
		                    <div class="clear"></div>
		                </ul>
		 		    </div>
					<div class="menu">
					    <ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="about.php">About</a></li>
							<li class="active"><a href="gallery.php">Gallery</a></li>
							<li><a href="services.php">Services</a></li>
							<li><a href="contact.php">Contact</a></li>
							<div class="clear"></div>
						</ul>
					</div>
	    		 <div class="clear"></div>
	    	 </div>
//	    </div>
	    		<div class="logo">
						<a href="index.php"><h1><span>F</span>urniture <span>M</span>all</h1></a>
					</div>				    
              </div>		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
	    	<div class="image group">
				<div class="grid images_3_of_1">
					<img src="images/gallery-img1.jpg" alt=""/>
				</div>
				<div class="grid blog">
					<h3>Lorem Ipsum is simply dummy text </h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
					<div class="price">
						<p>Price: <span>$799</span></p>
					</div>
					<div class="available">
						<p>Available :<span>In Stock</span></p>
					</div>
				<div class="add-cart">
					<div class="button"><span><a href="#">Add to Cart</a></span></div>
				</div>
			</div>
			   </div>
		   <div class="image group">
				<div class="grid images_3_of_1">
					<img src="images/gallery-img2.jpg" alt=""/>
				</div>
				<div class="grid blog">
					<h3>Lorem Ipsum is simply dummy text </h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
					<div class="price">
						<p>Price: <span>$599</span></p>
					</div>
					<div class="available">
						<p>Available :<span>In Stock</span></p>
					</div>
				<div class="add-cart">
					<div class="button"><span><a href="#">Add to Cart</a></span></div>
				</div>
			</div>
		   </div> 
		   <div class="image group">
				<div class="grid images_3_of_1">
					<img src="images/gallery-img5.jpg" alt=""/>
				</div>
				<div class="grid blog">
					<h3>Lorem Ipsum is simply dummy text </h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
					<div class="price">
						<p>Price: <span>$999</span></p>
					</div>
					<div class="available">
						<p>Available :<span>In Stock</span></p>
					</div>
				<div class="add-cart">
					<div class="button"><span><a href="#">Add to Cart</a></span></div>
				</div>
			</div>
		   </div>   
		   </div>	  	   				   
		</div> 
    </div>  
   

