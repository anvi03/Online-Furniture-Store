<style>
.button
{
	float:left;
}

.errvalidation
{
	color:#FF0000;
	float:right;
}

</style>				
	    		<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
			</div>	
  </div>		
   <div class="wrap" style="margin-left:340px">
   	 <div class="main">
	    <div class="content">
	    	   	   <div class="section group">				
				<!--<div class="col contact">
					<div class="contact_info">
			    	 	<h2>Find Us Here</h2>
			    	 		<div class="map">
					   			<iframe width="100%" height="175" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#666;text-align:left;font-size:12px">View Larger Map</a></small>
					   		</div>
      				</div>
      			<div class="company_address address">
				     	<h2>Ranade Furnitures :</h2>
						    	<p>Shop no.19,Avishkar Apartment,</p>
						   		<p>Makarpur Road,</p>
						   		<p>Bharuch</p>
				   		<p>Phone:02642695971</p>
				   		<p>Mobile No: 9327328886</p>
				 	 	<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				</div>				
				
                <div style="color:#0F0;">
                <?php if($this->session->userdata('msg'))
						{$this->session->userdata('msg');
					$this->session->unset_userdata('msg');}
				?>
                </div>-->
                <div class="col span_2_of_3">
				  <div class="contact-form">
                  
                 
                  <?php //echo validation_errors('<div style="color:#F00;">','</div>');?>
                  
                  
				  	<h2>Shipping Address</h2>
                    
                    <?php echo form_open('cart/shipping');?>
                    
					    <?php $ship = $this->session->userdata('ship');?>
                      
					    	
                            <div>
                           <span><?php echo form_label('First Name');?></span>
						   
						   
                           <span><?php if($ship['fisrtname'])
						   {
						   echo form_input('firstname',$ship['fisrtname'],'required');
						   }
						   else
						   { echo form_input('firstname',set_value('firstname'),'required');
						   }?></span>
						   <span><?php echo form_error('firstname','<div class="errvalidation">','</div>');?></span>
						   

                            </div>
                           <div>
                           <span><?php echo form_label('Last Name');?></span>
						   
                           <span><?php if($ship['lastname'])
						   {
						   echo form_input('lastname',$ship['lastname'],'required');
						   }
						   else 
						   {
						   echo form_input('lastname',set_value('lastname'),'required');
						   }?></span>
						   <span><?php echo form_error('lastname','<div class="errvalidation">','</div>');?></span>
						   
                           </div>
						   
						   <div>
                           <span><?php echo form_label('Email');?></span>
                           <span><?php if($ship['email'])
						   {
						   echo form_input('email',$ship['email'],'required');
						   }
						   else 
						   { echo form_input('email',set_value('email'),'required');
						   }?></span>
                           <span><?php echo form_error('email','<div class="errvalidation">','</div>');?></span>
						   </div>
						   
						   <div>
                           <span><?php form_label('Phone');?></span>
                           <span><?php if($ship['phone'])
						   {
						   echo form_input('phone',$ship['phone'],'required');
						   }
						   else 
						   { echo form_input('phone',set_value('phone'),'required');
						   }?></span>
                           <span><?php echo form_error('phone','<div class="errvalidation">','</div>');?></span>
						   </div>
						   <div>
                           <span><?php echo form_label('Address1');?></span>
                           <span><?php if($ship['address1'])
						   {
						   echo form_textarea('address1',$ship['address1'],'required');
						   }
						   else 
						   {  echo form_textarea('address1',set_value('address1'),'required');
						   }?></span>
						   <span><?php echo form_error('address1','<div class="errvalidation">','</div>');?></span>
                           </div>
						   
						   <div>
                           <span><?php echo form_label('Address2');?></span>
                           <span><?php if($ship['address2'])
						   {
						   	echo form_textarea('address2',$ship['address2'],'required');
						   }
						   else 
						   { echo form_textarea('address2',set_value('address2'),'required');
						   }?></span>
                           </div>
						   <div>
                           <span><?php echo form_label('Pin Code');?></span>
                           <span><?php if($ship['pin_code'])
						   {
						   echo form_input('pin_code',$ship['pin_code'],'required');
						   }
						   else 
						   { echo form_input('pin_code',set_value('pin_code'),'required');
						   }?></span>
						   <span><?php echo form_error('pin_code','<div class="errvalidation">','</div>');?></span><br/>
                           </div>
                           <div>
                           
                        
						<?php echo form_submit('countinue','Countinue','class="button"');?>
                           </div>
                        <?php echo form_close();?>
                        &nbsp;&nbsp;
                       
				    </div>
                 </div>   
  								
			  </div>
		</div> 
		</div>  
     </div>	
    


