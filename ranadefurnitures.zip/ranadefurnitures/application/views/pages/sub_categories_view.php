
<div class="logo">
		<h1><span>F</span>urniture <span>M</span>all</h1>
</div>				    
<div class="wrap">

   	 						
<div id='cssmenu'>
<ul>
   <li><a href="<?php echo site_url();?>/product"><span>All Categories</span></a></li>
   
   <?php foreach($categories as $categories_list): ?>
						
								<?php $p_id = $categories_list->parent_id;?>
								<?php $c_id = $categories_list->c_id;?>
								<?php $name = $categories_list->c_name;?>
   <li class="active has-sub"><a href="<?php echo site_url();?>/product/view_product/<?php echo $c_id;?>"><span><?php echo $name;?></span></a>
   <?php foreach($child_cat as $child):
	   if(count($child)>0)
											{
												for($i=0;$i<count($child);$i++)
												{
													if($categories_list->c_id==$child[$i]['parent_id'])
													{
	?>
		  <ul>
         <li><a href="<?php echo site_url();?>/product/view_product/<?php echo $child[$i]['c_id'];?>"><span><?php echo $child[$i]['c_name'];?></span></a>
            
         </li>
		 
		 
         
      </ul><?php 
													  }
													}
											}		  
	   endforeach;?>
	 <?php endforeach;?> 
   </li>
   
</ul>


</div>

	<div class="content">					
		<div class="section group1">
        
		<?php 
		$k = 0;				
		
							//echo "<pre>";print_r($child_cat);die;
								if(sizeof($categories_data)>=1)
									{
									
										foreach($categories_data as $categories_list): ?>
										<div class="grid_1_of_4 images_1_of_4_1">
	
											<div class="col_1_of_4">
											<?php //echo $parent_id = $child_list['parent_id'];?>
									   
												
									 			
													<h3><a href="<?php echo base_url(); ?>index.php/product/product_view_subcategories/<?php echo $categories_list->c_id;?>"><img src="<?php echo base_url();?>./uploads/categories/<?php echo $categories_list->c_image;?>"alt="categories_image" width="200px" height="150" /></a></h3>
												   <h3><?php $name=$categories_list->c_name;
													echo anchor("product/view_categories/$name","$name");?></h3>
													<br />
												
												</div>
												<br />
													
											</div>
											
													
													
												
											
									<?php
										endforeach;
									}
										 
	
									else
									{
									?>
										<div>
											<h2><b>No Records found...!</b></h2>
											</div>
											
											
										 
									<?php
						
									}
									?>
															
		
        </div>
		
		
        </div>
        		
		
		</div>
	
		
        
      </div>
   			 



	    	<!--<div class="section group">
				<div class="grid_1_of_4 images_1_of_4">
					 <a class="fancybox" href="<?php// echo base_url(''); ?>images/gallery-img1.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php //echo base_url(''); ?>images/gallery-img1.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img2.jpg" data-fancybox-group="gallery" title="Etiam quis mi eu elit temp"><img src="<?php// echo base_url();?>images/gallery-img2.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img3.jpg" data-fancybox-group="gallery" title="Cras neque mi, semper leon"><img src="<?php// echo base_url();?>images/gallery-img3.jpg" alt=""/><span> </span></a>
					<h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img4.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php //echo base_url();?>images/gallery-img4.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
			</div>    
			<div class="section group">
				<div class="grid_1_of_4 images_1_of_4">
					 <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img5.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img5.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img6.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img6.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img7.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php// echo base_url();?>images/gallery-img7.jpg" alt=""/><span> </span></a>
					<h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					  <a class="fancybox" href="<?php //echo base_url(''); ?>images/gallery-img8.jpg" data-fancybox-group="gallery" title="Sed vel sapien vel sem uno"><img src="<?php //echo base_url();?>images/gallery-img8.jpg" alt=""/><span> </span></a>
					 <h3>Product Name</h3>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua<span><a href="details.php">[...]</a></span></p>
				</div>
			</div>--> 	   
		
         
		  
		
     


