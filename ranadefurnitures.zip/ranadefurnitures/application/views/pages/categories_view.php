<style>
.pagination
{
    border: 1px solid #AAA;
    border-radius: 5px;
    padding: 2px 5px;
    margin: 0px 3px;
    cursor: pointer;
    color: #333 !important;
}
}
</style>
<div class="logo">
		<h1><span>F</span>urniture <span>M</span>all</h1>
</div>				    
<div class="wrap">

<div class="content"> 	 						
<div id='cssmenu'>
<ul>
   <li><a href="<?php echo site_url();?>/product"><span>All Categories</span></a></li>
   
   <?php foreach($categories as $categories_list): ?>
						
								<?php $p_id = $categories_list->parent_id;?>
								<?php $c_id = $categories_list->c_id;?>
								<?php $name = $categories_list->c_name;?>
   <li class="active has-sub"><a href="<?php echo site_url();?>/product/view_product/<?php echo $c_id;?>"><span><?php echo $name;?></span></a>
   <?php foreach($child_cat as $child):
	   if(count($child)>0)
											{
												for($i=0;$i<count($child);$i++)
												{
													if($categories_list->c_id==$child[$i]['parent_id'])
													{
	?>
		  <ul>
         <li><a href="<?php echo site_url();?>/product/view_product/<?php echo $child[$i]['c_id'];?>"><span><?php echo $child[$i]['c_name'];?></span></a>
            
         </li>
		 
		 
         
      </ul><?php 
													  }
													}
											}		  
	   endforeach;?>
	 <?php endforeach;?> 
   </li>
   
</ul>


</div>

						
		<div class="section group1">
        
		<?php 
		$k = 0;				
		
							
								if(sizeof($categories_data)>=1)
									{
										foreach($categories_data as $categories_list): ?>
										<div class="grid_1_of_4 images_1_of_4_1">
	
											<div class="col_1_of_4">
									   
												
												
												<h3><a href="<?php echo base_url(); ?>index.php/categories/get_sub_categories/<?php echo $categories_list->c_id?>"><img src="<?php echo base_url();?>./uploads/categories/<?php echo $categories_list->c_image;?>"alt="categories_image" width="200px" height="150" /></a></h3>
											   <h3><?php $name=$categories_list->c_name;
												echo anchor("product/view_categories/$name","$name");?></h3>
												<br />
											
												</div>
												<br />
													
											</div>
											
													
													
												
											
									<?php
										endforeach;
									}
										 
	
									else
									{
									?>
										<div>
											<h2><b>No Records found...!</b></h2>
										</div>
											
											
										 
									<?php
						
									}
									?>
				
				 <div>
				 <div class="clear"></div>
				 
                  	<ul>
                    <a><?php echo $link;?></a>
                	</ul>
				</div>
        </div>
			
		
</div>
        		
		
</div>