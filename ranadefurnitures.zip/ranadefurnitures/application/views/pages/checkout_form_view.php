<style>
.button
{
	float:left;
}

.errvalidation
{
	color:#FF0000;
	float:right;
}

</style>	
			
	    		<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
			</div>	
  </div>		
   <div class="wrap" style="margin-left:340px">
   	 <div class="main">
	    <div class="content">
	    	   	   <div class="section group">				
				<!--<div class="col contact">
					<div class="contact_info">
			    	 	<h2>Find Us Here</h2>
			    	 		<div class="map">
					   			<iframe width="100%" height="175" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#666;text-align:left;font-size:12px">View Larger Map</a></small>
					   		</div>
      				</div>
      			<div class="company_address address">
				     	<h2>Ranade Furnitures :</h2>
						    	<p>Shop no.19,Avishkar Apartment,</p>
						   		<p>Makarpur Road,</p>
						   		<p>Bharuch</p>
				   		<p>Phone:02642695971</p>
				   		<p>Mobile No: 9327328886</p>
				 	 	<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				</div>				
				
                <div style="color:#0F0;">
                <?php if($this->session->userdata('msg'))
						{$this->session->userdata('msg');
					$this->session->unset_userdata('msg');}
				?>
                </div>-->
                <div class="col span_2_of_3">
				  <div class="contact-form">
                  
                 
                  <?php //echo validation_errors('<div style="color:#F00;">','</div>');?>
                  
                  
				  	
                    
                    <?php echo form_open('cart/checkout');?>
					
                    <?php $arr = array(
											'0' => "Free shipping",
											'1' => "Express Shipping"
									   );
						echo form_dropdown('exprship', $arr, 'large');			   
					?>
					<h2>Billing Address</h2>
					    
                     <?php $bill = $this->session->userdata('bill');?>
					    	<!--<div>
						    	<span><label>Name</label></span>
						    	<span><input type="text" value="" name="name" required></span>
						    </div>-->
                            <div>
                           <span><?php echo form_label('First Name');?></span>
						   
						   
                           <span>
						   <?php if($bill['fisrtname'])
						   {
						   echo form_input('firstname',$bill['fisrtname'],'required');
						   }
						   else
						   {
						   		echo form_input('firstname',set_value('firstname'),'required');
						   }
						   ?>
						   </span>
						   <span><?php echo form_error('firstname','<div class="errvalidation">','</div>');?></span>
						   

                            </div>
                           <div>
                           <span><?php echo form_label('Last Name');?></span>
						   
                           <span>
						   <?php if($bill['fisrtname'])
						   {
						   		echo form_input('lastname',$bill['lastname'],'required');
						   }
						   else
						   {
						   	echo form_input('lastname',set_value('lastname'),'required');
						   }?>
							</span>
						   <span><?php echo form_error('lastname','<div class="errvalidation">','</div>');?></span>
						   
                           </div>
						   
						   <div>
                           <span><?php echo form_label('Email');?></span>
                           <span>
						   <?php if($bill['email'])
						   {
						   		echo form_input('email',$bill['email'],'required');
						   }
						   else
						   {
						   echo form_input('email',set_value('email'),'required');
						   }
						   ?></span>
                           <span><?php echo form_error('email','<div class="errvalidation">','</div>');?></span>
						   </div>
						   
						   <div>
                           <span><?php echo form_label('Phone');?></span>
                           <span><?php if($bill['phone'])
						   {
						   		echo form_input('phone',$bill['phone'],'required');
						   }
						   else
						   {
						   		echo form_input('phone',set_value('phone'),'required');
						   }?></span>
                           <span><?php echo form_error('phone','<div class="errvalidation">','</div>');?></span>
						   </div>
						   <div>
                           <span><?php echo form_label('Address1');?></span>
                           <span><?php if($bill['address1'])
						   {
						   		echo form_textarea('address1',$bill['address1'],'required');
						   }
						   else
						   { echo form_textarea('address1',set_value('address1'),'required');
						   }?></span>
						   <span><?php echo form_error('address1','<div class="errvalidation">','</div>');?></span>
                           </div>
						   
						   <div>
                           <span><?php echo form_label('Address2');?></span>
                           <span><?php if($bill['address2'])
						   {
						   		echo form_textarea('address2',$bill['address2'],'required');
						   }
						   else 
						   {
						   echo form_textarea('address2',set_value('address2'),'required');
						   }?></span>
                           </div>
						   <div>
                           <span><?php echo form_label('Pin Code');?></span>
                           <span><?php if($bill['pin_code'])
						   {
						   		echo form_input('pin_code',$bill['pin_code'],'required');
						   }
						   else
						   {
						   echo form_input('pin_code',set_value('pin_code'),'required');
						   }?></span>
						   <span><?php echo form_error('pin_code','<div class="errvalidation">','</div>');?></span><br  />
                           </div>
						   <div>
						   		<input type="checkbox" name="chk" value="5" />
								<span style="display:inline"><?php echo form_label('Ship to this address');?></span>
						   </div>
						   <?php /*?><div>
						   		<input type="checkbox" name="chkship" value="5" />
								<span style="display:inline"><?php echo form_label('Express Shipping');?></span>
						   </div>
<?php */?>                           <div>
                           
                        <?php echo form_submit('countinue','Countinue','class="button"');?>
                           </div>
                           
                           
                           
						  <!-- <div>
						    	<span><label>E-mail</label></span>
						    	<span><input type="text" value="" name="email" required></span>
						    </div>-->
						  <!--  <div>
						     	<span><label>Company Name</label></span>
						    	<span><input type="text" value="" name="cname" required></span>
						    </div>-->
						   <!-- <div>
						    	<span><label>Subject</label></span>
						    	<span><textarea name="subject" required> </textarea></span>
						    </div>-->
						  <!-- <div>
						   		<span><input type="submit" name="submit" value="Submit"></span>
						  </div>-->
					    <!--</form>-->
                        <?php echo form_close();?>
                        &nbsp;&nbsp;
                        <?php //echo anchor('registration/signin',"SignUp" ,'style="float:left;"'); ?>
				    </div>
                 </div>   
  								
			  </div>
		</div> 
		</div>  
     </div>	
    


