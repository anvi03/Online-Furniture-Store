<?php
foreach($content as $detail)
{
		print_r($detail->content);
}
?>


