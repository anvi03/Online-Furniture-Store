			
	    		<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
					</div>				    
         		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
        <div class="section group">
        
		<?php
		//$k=0;
		 
							if(($news_list)>=1)
								{
									foreach($news_list as $news_item): ?>
                                    <div class="grid_1_of_4 images_1_of_4"> 
                                       	 <div class="col_1_of_4">
										 
											<img src="<?php echo base_url();?>./uploads/news/<?php echo $news_item->image;?>" alt="news_image" style="padding-right:20px;" width="300px" height="" align="left"/>
									   
												<div class="logo3">
												<h3><span><?php echo $news_item->title;?></span></h3>
												</div>
												
											
											
												<div class="logo3" style="padding-right:20px;">
												
												<?php echo $news_item->description; ?>
											
												</div>
												<div  class="logo3" style="float:right;">
													
												<h3><?php $date = $news_item->created;
													echo "$date";?></h3>
												</div>
                                             
											
										</div>	 
                                     </div>
                                    
                                      
								<?php
									endforeach;
								}
									 

								else
								{
								?>
									<div>
										<h2><b>No Records found...!</b></h2>
									</div>
								<?php
								}
								?>
		 </div>
                                                
											    

								        
                                       
									 
								
                                
	
        </div>
        </div>
        </div>