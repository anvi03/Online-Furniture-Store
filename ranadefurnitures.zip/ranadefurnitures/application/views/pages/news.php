<!--<style>
.box
{
	border:4px solid #9C9;
	border-radius:10px;
	margin:4px;
	padding:4px;
	min-width:150px;
	min-height:150px;
	float:left;
}

</style>-->

	    		<div class="logo">
						<a href="index.php"><h1><span>F</span>urniture <span>M</span>all</h1></a>
				</div>	
		
   <div class="wrap">
   			
   	 <div class="main">
	    <div class="content">
        	<h2><span>N</span>ews <span>D</span>isplay</h2>
        <div class="section group">
        <?php 
		$k=0;
								if(sizeof($news_list)>=1)
								{
									foreach($news_list as $news_item): ?>
                                    
                                    
										<div class="grid_1_of_4 images_1_of_4_1" <?php if($k==0){echo 'style="margin-left: 18px;"';$k++;} ?>>

										<div class="col_1_of_4">
                                        <img src="<?php echo base_url();?>./uploads/news/<?php echo $news_item->image;?>" alt="news_image" width="200px" height="150" />
                                        
                                        <h3><?php echo $news_item->title;?></h3>
										
											<?php echo $news_item->description; ?>
                                            <br/>
										
											<?php if($news_item->status == 1) 
													{
														echo "Enabled";
													}
													else
													{
														echo "Disable";
													}?> <br />
											<?php $date = $news_item->created;
												echo "$date";?>
                                               </div>
                                       </div>
                                      
								<?php
									endforeach;
								}
									 

								else
								{
								?>
									<div>
										<h2><b>No Records found...!</b></h2>
									</div>
								<?php
								}
								?>
		 </div>
     </div>
   </div>
  </div>						
