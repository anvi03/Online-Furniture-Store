<?php /*?><ul>
							 <li><span><?php echo anchor('product',"All Categories");?>
					
							
						<?php foreach($categories as $categories_list): ?>
						
								<?php $p_id = $categories_list->parent_id;?>
								<?php $c_id = $categories_list->c_id;?>
								
								
								
									
								
									<ul><li class='active has-sub'><span><?php $name = $categories_list->c_name;
									echo anchor('product/view_product/'.$c_id,$name);?>
								
								
								<?php foreach($child_cat as $child):
								
								
										?><ul><li class="has-sub"><span><?php 
										if(count($child)>0)
									    {
											for($i=0;$i<count($child);$i++)
											{
												if($categories_list->c_id==$child[$i]['parent_id'])
												{
													
													echo "<br>&nbsp;&nbsp;&nbsp;".anchor('product/view_product/'.$child[$i]['c_id'],$child[$i]['c_name']);
													
												}
											}
										}	
			
								?>		
								 </span>
								 </li></ul>
								
							    <?php endforeach;?>
								 
								

								
							</span></lis>
							</ul>						
						<?php
							endforeach;?>
							
							</span></li>
							</ul>
	
											
						
							</div>	
								
						
			<?php */?>	 
