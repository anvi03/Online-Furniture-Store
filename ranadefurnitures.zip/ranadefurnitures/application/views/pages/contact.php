<style>
.errvalidation
{
	color:#FF0000;
	float:right;
}
</style>
	    	<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
			</div>	
  </div>		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
	    	   	   <div class="section group">				
				<div class="col contact">
					<div class="contact_info">
			    	 	<h2>Find Us Here</h2>
			    	 		<div id="googleMap" style="height:300px;width:300px;">
					   			
					   		</div>
      				</div>
      			<div class="company_address address">
				     	<h2>Ranade Furnitures :</h2>
						    	<p>shop no.19,Avishkar Apartment,</p>
						   		<p>Makarpur Road,</p>
						   		<p>Bharuch</p>
				   		<p>Phone:695971</p>
				   		<p>Fax: 9327328886</p>
				   		<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				</div>				
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Contact Us</h2>
					<div style="color:#00FF00;">
						<?php if($this->session->userdata('msg'))
							  {
							  	echo $this->session->userdata('msg');
								$this->session->unset_userdata('msg');
							  }
						?>
					</div>
					
					    <?php echo form_open('contactus/add');?>
					    	<div>
						    	<span><?php echo form_label('Name'); ?></span>

								
						    	<span><?Php echo form_input('name',set_value('name'),'placeholder="Name" required');?></span>
								<span><?php echo form_error('name','<div class="errvalidation">','</div>');?></span>
						    </div>
						    <div>
						    	<span><?php echo form_label('E-Mail'); ?></span>
								
						    	<span><?Php echo form_input('email',set_value('email'),'placeholder="EMail" required');?></span>
								<span><?php echo form_error('email','<div class="errvalidation">','</div>');?></span>

						    </div>
						    <div>
						     	<span><?php echo form_label('Company Name'); ?></span>
								
						    	<span><?Php echo form_input('company_name',set_value('company_name'),'placeholder="Company Name" required');?></span>
								<span><?php echo form_error('company_name','<div class="errvalidation">','</div>');?></span>

						    </div>
						    <div>
						    	<span><?php echo form_label('Subject'); ?></span>
								

						    	<span><?Php echo form_textarea('subject',set_value('subject'),'placeholder="Subject" required');?></span>
								<span><?php echo form_error('subject','<div class="errvalidation">','</div>');?></span>
								<br />
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit"></span>
						  </div>
					    </form>
				    </div>
  				</div>				
			  </div>
		</div> 
		</div>  
     </div>	
    


