<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
			</div>	
  </div>		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
			<div id='cssmenu'>
				<ul>
				   <li class="active has-sub"><a href="<?php echo site_url();?>/signin/setting"><span>Settings</span></a>
				   		<ul>
         					<li>
								<a href="<?php echo site_url();?>/signin/chang_ppwd">Change Password</a>
							</li>
							
						
         					<li>
								<a href="<?php echo site_url();?>/signin/setting">My Profile</a>
							</li>
						</ul>	
					</li>
					
				   <li><a href="<?php echo site_url();?>/wishlist"><span>Wishlist</span></a>				   
				</ul>
			</div>
			<div class="section group1">
			<div class="logo3">
				<h1><?php echo "Welcome to Online Furniture Mall";?></h1>
				<?php //echo $this->session->userdata('username');die;?>
							<h1><?php echo $this->session->userdata('username');?></h1>	
						
			</div>	
			</div>
		</div>
	</div>
	</div>		