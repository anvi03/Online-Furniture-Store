<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
</div>
<div class="wrap" style="margin-left:340px">
    <div class="main">
	    <div class="content">
	    	   	   <div class="section group">				
				
                   <h1><span>CheckOut</span></h1>
				   <br />
				   <div>
				   <table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; float:left; font-size:15px; background-color:#E1E1E1" height="100%" width="80%">
				   
					   <tr style="float:left; margin-bottom:10px;"><th><?php 
					   echo form_open('cart/checkout');
					   echo form_submit('change_billing',"Edit Billing"); 
					   echo form_close();?></th>
					   <th style=" padding-left:400px;">
						<?php echo form_open('cart/shipping');
						echo form_submit('change_shipping',"Edit Shipping");
						echo form_close();?></th>
					   </tr>
					   </table>
					  </div> 
					  <div>
					    <table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; float:left; font-size:15px; background-color:#E1E1E1" height="100%" width="80%">
					   <?php 
					  	$billing = $this->session->userdata('bill');
					  ?><tr style="padding-bottom:20px;">
					  		<td style="padding-bottom:20px;">
								  <?php echo $billing['fisrtname'];?>
								  <?php echo $billing['lastname'];?><br  />
								  <?php echo $billing['address1'];?>
								  <?php echo br(2);?>
								  
								  <?php echo $billing['email'];?>
								  <?php echo br(2);?>
								  
								  <?php echo $billing['phone'];?>
							</td>
							<?php 
								$shipping = $this->session->userdata('ship');
						
						 ?> <td style="padding-left:318px;padding-bottom:20px;">
								 <?php echo $shipping['fisrtname'];?>
								 <?php echo $shipping['lastname'];?><br  />
								 <?php echo $shipping['address1'];?>
								 <?php echo br(2);?>
								 
								 <?php echo $shipping['email'];?>
								 <?php echo br(2);?>
								 
								 <?php echo $shipping['phone'];?>
							</td>
						</tr>
					   
				  
				  </table> 
				   </div> 
				   
				   
				   <div style="padding-top:20px;">
				   <br /><br /><br /><br /><br /><br /><br /><br />
					   <?php echo form_open('cart/order');?>
					   <table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; padding-top:20px; font-size:15px; background-color:#E1E1E1; " height="100%" width="80%">
						   <tr align="center">
								<th style="border:1px solid #666666;">Name</th>
								
								<th style="border:1px solid #666666;">Price</th>
								
								
								
								<th style="border:1px solid #666666;">Quantity</th>
								
								<th style="border:1px solid #666666;">Totals</th>
						   </tr>
						   <?php $cart = $this->cart->contents();
						   foreach ($cart as $item):?>

						  
						   <tr align="center">
						   		<td style="border:1px solid #666666;">
									<?php 
										echo $item['name'];
									?>
								</td>
								<td style="border:1px solid #666666;">
									<?php 
										echo $item['price'];
									?>
								</td>
								
								<td style="border:1px solid #666666;">
									<?php 
										echo $item['qty'];
									?>
								</td>
								<td style="border:1px solid #666666;">
									<?php 
										echo $item['subtotal'];
									?>
								</td>
								
						   </tr>
						   
						   <?php endforeach; ?>
						   
						  		<tr align="center">
						   		<th style="border:1px solid #666666;" colspan="3">Total</th>
								<td style="border:1px solid #666666;">
									<?php echo $this->cart->total();?>
								</td>
						   </tr>
								<?php $total = $this->cart->total();?>
						  		<?php if($billing['shipping_method'] == 1)
									  {
									  		?>
											<tr align="center">
												<th style="border:1px solid #666666;" colspan="3">Shipping Charges</th>
												<td style="border:1px solid #666666;">
												<?php 
													$ship = $total*5/100;
													echo $ship;
												?>
												</td>
											</tr><?php 
									  }
									  else
									  {
									  	?><tr align="center">
												<th style="border:1px solid #666666;" colspan="3">Shipping Charges</th>
												<td style="border:1px solid #666666;">
													<?php 
														$ship = 0;
														echo $ship;
													?>
												</td>
											</tr>
											<?php			
									  }
									?>
						  
						   <tr align="center">
						   		<th style="border:1px solid #666666;" colspan="3">Grand Total</th>
								<td style="border:1px solid #666666;">
									<?php $grandt = $this->cart->total();
											echo $grandt + $ship;
									?>
								</td>
						   </tr>
						   
					   </table>
					  
					   <?php echo form_submit('checkout',"Continue");?>
					   <?php echo form_close();?>
					   
				   </div>
  								
			  </div>
		</div> 
	</div>  
 </div>	
    


