
  <style>
.errvalidation
{
	color:#FF0000;
	float:right;
}
</style>
	    	<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
			</div>	
  </div>		
   <div class="wrap">
   	 <div class="main">
	    <div class="content">
	    	   	   <div class="section group">				
				<div class="col contact">
					<div class="contact_info">
			    	 	<h2>Find Us Here</h2>
			    	 		<div id="googleMap" style="height:300px;width:300px;">
					   			
					   		</div>
      				</div>
      			<div class="company_address address">
				     	<h2>Ranade Furnitures :</h2>
						    	<p>shop no.19,Avishkar Apartment,</p>
						   		<p>Makarpur Road,</p>
						   		<p>Bharuch</p>
				   		<p>Phone:695971</p>
				   		<p>Fax: 9327328886</p>
				   		<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				</div>				
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Forget Password</h2>
					<div style="color:#009900;">
						<?php if($this->session->userdata('succ'))
							  {
							  	echo $this->session->userdata('succ');
								$this->session->unset_userdata('succ');
							  }
						?>
					</div>
					
					<div style="color:#FF0000;">
						<?php if($this->session->userdata('err'))
							  {
							  	echo $this->session->userdata('err');
								$this->session->unset_userdata('err');
							  }
						?>
					</div>
					
					    <?php echo form_open('forgot/retrive_pwd');?>
					    	<div>
						    	<span><?php echo form_label('UserName'); ?></span>

								
						    	<span><input type="text" name="username"placeholder="username" required></span>
								<span><?php echo form_error('username','<div class="errvalidation">','</div>');?></span>
						    </div>
						    <div>
						    	<span><?php echo form_label('E-Mail'); ?></span>
								
						    	<span><input type="text" name="email" placeholder="email" style="border-radius: 0 0 7px 7px;" required></span>
								<span><?php echo form_error('email','<div class="errvalidation">','</div>');?></span>

						    </div>
						    
						   <div>
						   		<button>Sent Mail</button>
						   		
						  </div>
					    </form>
				    </div>
  				</div>				
			  </div>
		</div> 
		</div>  
     </div>	