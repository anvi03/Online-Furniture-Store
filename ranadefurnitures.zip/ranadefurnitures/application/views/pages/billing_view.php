	<div class="wrap" style="margin-left:340px">
		 <div class="main">
			<div class="content">
						
					   <?php  foreach($order as $order_list):?>
						<h1>Order No:
						<?php echo $order_list->order_no;?>
						</h1>
						<?php endforeach;?> 
	
					  <table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; font-size:15px;" height="100%" width="80%">
					   <div>
					   <h1>
					   <tr style="float:left; font-size:18px; margin-top:20px;">						
					   <th>
								Account Information</th>
							<th style="padding-left:275px;">Shipping & Billing Information</th>
						</tr>
						</h1>
						</div></table>
						<table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; font-size:15px; " height="100%" width="80%">
						
						<div style="margin-top:20px;">
						<tr>
						<td>
						<?php echo $order_list->bill_firstname;?>&nbsp;<?php echo $order_list->bill_lastname;?> 
						<br /><?php echo $order_list->bill_email;?><br />
						
						<?php echo $order_list->bill_phone;?>
						</td>
						<td style="margin-left:100px;padding-left:230px;"><?php echo $order_list->ship_firstname;?>&nbsp;<?php echo $order_list->ship_lastname;?><br >
								<?php echo $order_list->ship_address1;?>
								
								
								<br ><?php echo $order_list->ship_email;?>
								
								<br ><?php echo $order_list->ship_phone;?>
								</td></tr>
					   </div>
					   </table>
					   <br>
					   <table border="0" cellpadding="5px" cellspacing="1px" style="font-family:Verdana, Geneva, sans-serif; font-size:15px; background-color:#E1E1E1" height="100%" width="80%">
					   <div>
									<tr>
										<th style="border:1px solid #666666;">Name</th>
									
										<th style="border:1px solid #666666;">Price</th>
										
										<th style="border:1px solid #666666;">Description</th>
										
										<th style="border:1px solid #666666;">Quantity</th>
										
										<th style="border:1px solid #666666;">Totals</th>
									</tr>
									<?php $i=0;?>
									 <?php  foreach($product_lst as $product):?>
									 <tr>
									 	<td style="border:1px solid #666666;"><?php echo $product[0]['p_name'];?></td>
										<td style="border:1px solid #666666;"><?php echo $product[0]['p_price'];?></td>	
										<td style="border:1px solid #666666;"><?php echo $product[0]['p_desc_short'];?></td>
									
										<td style="border:1px solid #666666;"><?php echo $arr[$i];?></td>
										
										<td style="border:1px solid #666666;">
										
														<?php echo $total[$i];?></td>
											
										<?php  $i++;?>					
									 </tr>
									 <tr>
										<th style="border:1px solid #666666;" colspan="4"> Shipping Charges</th>
										<td style="border:1px solid #666666;">
											<?php $ship_mthd = $order_list->shipping_method;
													echo $ship_mthd;
											?>
										</td>
									</tr>
									<?php endforeach;?>	
									<tr>
										<th style="border:1px solid #666666;" colspan="4">Grand Total</th>
										<td style="border:1px solid #666666;">
											<?php  $tot = $this->cart->total();
													echo $tot+$ship_mthd;?>
										</td>
									</tr>								 	 
						</div>			
					   </table>	   
			</div>
		 </div>
	</div>	 						   