<!--<style>
.box
{
	border:4px solid #9C9;
	border-radius:10px;
	margin:4px;
	padding:4px;
	min-width:150px;
	min-height:150px;
	float:left;
}

</style>-->

	    		<div class="logo">
						<h1><span>F</span>urniture <span>M</span>all</h1>
				</div>	
		
   <div class="wrap">
   			
   	 <div class="main">
	    <div class="content">
        	<div class="logo"><h2>News Display</h2></div>
        <div class="section groupnews">
        <?php 
		//$k=0;
								
								if(sizeof($news_list)>=1)
								{
									foreach($news_list as $news_item): ?>
                                    
                                    
										<div class="grid_1_of_4 images_1_of_4_1">

										<div class="col_1_of_4">
                                       <h3><a href="<?php echo base_url(); ?>index.php/news/per_view/<?php echo  $news_item->id?>">
                                        <img src="<?php echo base_url();?>./uploads/news/<?php echo $news_item->image;?>" alt="news_image" width="200px" height="150" /></a></h3>
                                        <div class="logo3">
                                        <h3><span><?php echo $news_item->title;?></span></h3>
										</div>
										
										<div class="logo3">
                                        <h3>
											<span>
													<?php $desc = $news_item->description;
															echo substr($desc,0,20).'..';
													?>
											</span>
										</h3>
										</div>
										</div>
										
                                       </div>
                                      
								<?php
									endforeach;
								}
									 

								else
								{
								?>
									<div>
										<h2><b>No Records found...!</b></h2>
									</div>
								<?php
								}
								?>
								
				<div class="posts" style="border:none">
				 <div class="clear"></div>
				 <table>
				 <td>
                  	<ul class="pagination">
                    <li><?php echo $link;?></li>
                	</ul>
				</td>	
				</table>	
	
				</div>
		 </div>
         
     </div>
     </div>
  </div>						