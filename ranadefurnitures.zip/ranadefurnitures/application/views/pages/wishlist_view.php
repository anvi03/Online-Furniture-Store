<div class="wrap">
	<div class="main">
		<div class="content">
			<h1 align="center">Your Wishlist</h1>
			<?php //echo "<pre>";print_r($result);die;?>
	<?php if($result)
		  {
			foreach($result as $product_list): ?>
			<div class="grid_1_of_4 images_1_of_4_1">
	
				<div class="col_1_of_4">
					<h3><a href="<?php echo base_url(); ?>index.php/single/index/<?php echo $product_list['p_id'];?>"><img src="<?php echo base_url();?>./uploads/product/<?php echo $product_list['p_image'];?>"alt="categories_image" width="200px" height="150" /></a></h3>
					<div class="logoprice">
						
						Price:<?php echo $product_list['p_price'];?>
					
					<?php 
					$id = $product_list['p_id'];
					$base = base_url();?>
						<a href="<?php echo base_url();?>index.php/wishlist/remove_wish/<?php echo $product_list['p_id'];?>" style="float:right;"><img src="<?php echo base_url();?>./images/remove1.png" width="25px" onclick="return window.confirm('Are you Sure ?');"/></a>
						<?php //echo anchor("","",'onclick="return window.confirm(\'Are you Sure ?\');"');?>
					</div>
				</div>
			</div>		
			<?php endforeach;
			}
			else
			{
				?><h1 align="center"><?php echo $no_record;?></h1><?php 
			}
			?>
			
		</div>
	</div>
</div>		