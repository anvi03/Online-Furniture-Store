<style>
.errvalidation
{
	color:#FF0000;
	float:right;
}
</style>
<div class="logo">
		<h1><span>F</span>urniture <span>M</span>all</h1>
</div>			
<div class="wrap">
    <div class="main">
	    <div class="content">
		<div class="section group">
		<div class="col span_2_of_3" style="margin-left:235px;" >
			<div class="contact-form">
				<div class="logo" style="margin-right:250px;">	
				  	<h1>Users</h1>
				</div>
				<div style="color:#006600;">
                <?php if($this->session->userdata('msg'))
					  {
					  	?><span style="color:#00CC00;"><?php echo $this->session->userdata('msg');?></span><?php 
						$this->session->unset_userdata('msg');
					  }
				?>
                </div>
				<div style="color:#FF0000;">
                <?php if($this->session->userdata('err'))
					  {
					  	?><span style="color:#FF0000;"><?php echo $this->session->userdata('err');?></span><?php 
						$this->session->unset_userdata('err');
					  }
				?>
                </div>
				<?php echo form_open('signin/update_user');?>
					<div>
						<?php foreach($user_data as $user_list): ?>
						
						    	
							<div>
								
						    	<span><?php echo form_label('Username'); ?></span>

								
						    	<span><?Php echo form_input('username',$user_list->username,'placeholder="Username" required');?></span>
								<span><?php echo form_error('username','<div class="errvalidation">','</div>');?></span>
						    </div>
							
							<div>
								
						    	<span><?php echo form_label('First Name'); ?></span>

								
						    	<span><?Php echo form_input('firstname',$user_list->firstname,'placeholder="First Name" required');?></span>
								<span><?php echo form_error('firstname','<div class="errvalidation">','</div>');?></span>
						    </div>
							
							<div>
								
						    	<span><?php echo form_label('Last Name'); ?></span>

								
						    	<span><?Php echo form_input('lastname',$user_list->lastname,'placeholder="Last Name" required');?></span>
								<span><?php echo form_error('lastname','<div class="errvalidation">','</div>');?></span>
						    </div>
							
							<div>
								
						    	<span><?php echo form_label('Email'); ?></span>

								
						    	<span><?Php echo form_input('email',$user_list->email,'placeholder="Email" required');?></span>
								<span><?php echo form_error('email','<div class="errvalidation">','</div>');?></span>
						    </div>							

							<div>
								
						    	<span><?php echo form_label('Mobile No'); ?></span>

								
						    	<span><?Php echo form_input('mobile',$user_list->mobile_no,'placeholder="Mobile No" required');?></span>
								<span><?php echo form_error('mobile','<div class="errvalidation">','</div>');?></span>
								<span><?php echo form_submit('update','Update');?></span>
						    </div>
								<?php endforeach ?>
				</div>
				<?php echo form_close();?>
			</div>
		</div>	
		</div>
		</div>
	</div>
</div>			