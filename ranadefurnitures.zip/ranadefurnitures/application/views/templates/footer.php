 
  <div class="footer"> 	
   <div class="wrap">
   	 <div class="footer_grides">
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
					<h3>Latest Comments</h3>
						<div class="post">
				    		<p><span><a href="#">Tuesday,June 31th,2013</a></span></p>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,Ut enim ad minim veniam sed do <span><a href="#">[...]</a></span></p>
				       </div>
				       <div class="post">
				    		<p><span><a href="#">Monday,May 21th,2013</a></span></p>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,Ut enim ad minim veniam sed do<span><a href="#">[...]</a></span></p>
				       </div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h3>Connect With Us</h3>
					<div class="social_icons">
                	<ul>
                    	<li><a href="https://www.facebook.com/pages/Kalikund-infotech/626532630710606?rf=212942888866470" class="facebook">
                        	<span class="icon"> &nbsp;</span> <span class="inner"><strong>Facebook</strong> <br>+ 12, 297</span>
                        </a></li>
                        <li><a href="https://twitter.com/kalikundinfo" class="twitter">
                        	<span class="icon"> &nbsp;</span> <span class="inner"><strong>Twitter</strong> <br>+ 5, 287</span>
                        </a></li>
                         <li><a href="" class="rss">
                        	<span class="icon"> &nbsp;</span> <span class="inner"><strong>Rss</strong> <br>+ 77, 287</span>
                        </a></li>
                    </ul>
                </div>
				</div>
				
				<div class="col_1_of_4 span_1_of_4">
					<h3>Navigate</h3>
					          <ul>
                             <li> <?php echo anchor('home','Home'); ?></li>
                             <li> <?php echo anchor('about','About'); ?></li>
                             <li> <?php echo anchor('categories','Product'); ?></li>
                             <li> <?php echo anchor('services','Services'); ?></li>
                             <li> <?php echo anchor('news','News'); ?></li>
                             <li> <?php echo anchor('contact','Contact'); ?></li>
                             
						          <!-- <li><a href="index.php">Home</a></li>
                                  
						     		<li><a href="about.php">About</a></li>
						     		<li><a href="gallery.php">Gallery</a></li>
						     		<li><a href="services.php">Blog</a></li>	
						     		<li><a href="services.php">Services</a></li>						     		
						     		<li><a href="contact.php">Contact</a></li>-->
						   	   </ul>
				</div><div class="col_1_of_4 span_1_of_4">
					<h3>Location</h3>
					      <ul>
						  	  <li>Ranade Furnitures,</li>
						  	  <!--<li>dolor sit amet,</li>-->
						  	   
                               <li>Shop no.19, Avishkar Apartment, </li>
                               <li>Makarpur Road,</li>
                               <li>Bharuch.</li>
						  	<!-- <li><span>E-mail :</span> www.yourcompany@gmail.com</li>-->
						  	 <li><span>Phone :</span> 02642695971</li>
						  	 <li><span>Mobile No :</span>  9327328886</li>
						  </ul>
				</div>
			</div>
	    </div>
  </div>
		 <div class="copy_right">
		 	 <div class="wrap">
				
		</div>	
  </div>
  </div>
  <script src="http://maps.googleapis.com/maps/api/js"></script>
<script>
function initialize() {
  var mapProp = {
    center:new google.maps.LatLng(22.2490731,73.1970053),
    zoom:17,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
}
google.maps.event.addDomListener(window, 'load', initialize);
</script>
  </body>
  </html>
