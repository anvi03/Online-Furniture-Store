<!DOCTYPE HTML>
<html>
<head>
<title><?php echo $title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link href="<?php echo base_url('');?>css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link rel="stylesheet" href="<?php echo base_url('');?>css/flexslider.css" type="text/css" media="screen" />
<link href="http://fonts.googleapis.com/css?family=Coda" rel="stylesheet" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Milonga' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="<?php echo base_url('');?>css/examples.css" type="text/css" media="all" />
<script src="<?php echo base_url('');?>js/jquery-1.8.1.min.js"></script>
<script src="<?php echo base_url();?>jquery-latest.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/script.js"></script>
  <!-- FlexSlider -->
  
 <script defer src="<?php echo base_url('');?>js/jquery.flexslider.js"></script>
 <script type="text/javascript">
    $(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
      $('.flexslider').flexslider({
        animation: "slide",
        controlNav: "thumbnails",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });
  </script>
  
  
	<script type="text/javascript" src="<?php echo base_url('');?>js/jquery-1.10.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url('');?>js/jquery.mousewheel-3.0.6.pack.js"></script>	
	<script type="text/javascript" src="<?php echo base_url('');?>js/jquery.fancybox.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('');?>css/jquery.fancybox.css" media="screen" />
    	
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

		});
	</script>
	
</head>
<body>
  <div class="header">
		 <div class="header_top">
		 
		 	 <div class="wrap">
		 			<div class="social-icons">					
		                <ul>
		                    <li><a class="facebook" href="https://www.facebook.com/pages/Kalikund-infotech/626532630710606?rf=212942888866470" target="_blank"> </a></li>
		                    <li><a class="twitter" href="https://twitter.com/kalikundinfo" target="_blank"></a></li>
		                    <li><a class="googleplus" href="https://plus.google.com/109336227971514447297" target="_blank"></a></li>
		                   <!-- <li><a class="pinterest" href="#" target="_blank"></a></li>
		                    <li><a class="dribbble" href="#" target="_blank"></a></li>
		                    <li><a class="vimeo" href="#" target="_blank"></a></li>-->
		                    <div class="clear"></div>
		                </ul>
		 		    </div>
					<div>
					</div>
                    <?php
					include_once('menu.php');
					?>
					
	    		 <div class="clear"></div>
	    	 </div>
	    </div>
