<div class="menu">
					    <ul>
							
                            <li <?php echo activate_menu('home');?>><?php echo anchor('home','Home');?></li>
                            
							<li <?php echo activate_menu('about');?>><?php echo anchor('about','About');?></li>
							<li <?php echo activate_menu('product');?>><?php echo anchor('product','Categories')?>
                           
                            <li <?php echo activate_menu('services');?>><?php echo anchor('services','Services')?></li>
							
                            <li <?php echo activate_menu('news');?>><?php echo anchor('news','News')?></li>
							
							<li <?php echo activate_menu('contact');?>><?php echo anchor('contact','Contact');?></li><?php //echo $this->session->userdata('userdata');die?>
                          	<?php if($this->session->userdata('username'))
							{?>
								
								
								<li <?php echo activate_menu('useraccount');?>><?php echo anchor('useraccount','Account');?>
								<ul>
									
									<li>
										<?php echo anchor('useraccount','Settings');?>
									</li>
									
									<li>
										<?php echo anchor('cart','Your Cart');?>
									</li>
									
									<div class="clear"></div>
								</ul>
								
								</li>
								<li><?php echo anchor('signin/logout','Logout');?></li><?php 

							  }
							  else
							  {?>
							 		 
									
								<li <?php echo activate_menu('login');?>><?php echo anchor('login','Login');?></li>	<?php }
							  								  ?>
							<div class="clear"></div>
						</ul>
					</div>
