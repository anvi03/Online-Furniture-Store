<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Website extends CI_Controller
{
	public function construct()
	{
		parent::__Construct();
	}
	public function logout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('is_logged_in');
		$this->session->set_userdata('msg',"you have successfuly logout");
		redirect('login');		
	}
	public function dashbord()
	{
		if($this->session->userdata('is_logged_in')!=true)
		{
			$data['page']='pages/view_login';
			$this->load->view('templates/content',$data);
	
		}
		else
		{
			$data['page']='pages/dashbord';
			$this->load->view('templates/content',$data);
	
		}
	}
	public function setting()
	{
		$this->load->model('website_model');
		$data['admin_data'] = $this->website_model->getdetails();
		$this->load->view('adminprofile',$data);
	}
			//$data['page'] = 'admin_profile';
			//$this->load->view('admin_profile',$data);
	public function update_admin()
	{
		
		$this->load->model('website_model');
		$res=$this->website_model->update_model();
		/*$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('firstname', 'first_name', 'required');
		$this->form_validation->set_rules('lastname', 'last_name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');*/
		

		if($res)
		{
			$this->session->set_userdata('succ',"update successfully");
			redirect('website/dashbord');
		}
			/*
			if ($this->form_validation->run() == FALSE)
			{
				$this->load->view('adminprofile',$data);
			}
			else
			{
				$this->session->set_userdata('succ',"update successfully");
				$this->setting();
			}*/
		
	
	}
}
?>