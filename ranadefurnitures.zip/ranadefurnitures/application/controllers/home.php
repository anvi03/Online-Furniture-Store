<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class Home extends CI_Controller{
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('banner_model');
		$this->load->model('homeservices_model');
	}
	public function index()
	{
		$data['title'] = "Ranade Furniture|Home";
		$data['banner'] = $this->banner_model->get_banner();
		$data['services'] = $this->homeservices_model->get_services();
		$data['ariaval_pro'] = $this->banner_model->arriaval_product();
		//echo "<pre>";print_r($data['ariaval_pro']);die;
		$data['page'] = 'pages/index';
		$this->load->view('templates/content',$data);
	}
}
?>