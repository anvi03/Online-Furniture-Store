<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class News extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->library('pagination');
			$this->load->library('table');
			
			$this->load->model('news_model');
		}
		
		public function pagination()
		{
		$this->load->model('news_model');
		$query=$this->news_model->get_num();
		$config['base_url']='http://localhost/ranadefurnitures/index.php/news/index';
		$config['total_rows']=$query->num_rows();
		$config['per_page']=3;
		$config['num_links']=5;
		
		$this->pagination->initialize($config);
		
		}
		public function index()
		{
		
			$this->load->library('pagination');
			$config['base_url']= site_url()."/news/index/";
			$config['total_rows']=$this->news_model->get_numrows();
			$config['per_page']=6;
			$this->pagination->initialize($config);
			$this->load->model('news_model');
			$data['title'] = "Ranade Furniture|News";
			$data['news_list']=$this->news_model->get_news($config['per_page'],$this->uri->segment(3));
			$data['link']=$this->pagination->create_links();
			$data['page'] = 'pages/news_view';
			$this->load->view('templates/content',$data);
		}
		
		public function per_view($id = NULL)
		{
			if($id == "")
			{
				redirect('news');
			}
			else
			{
				
				$data['news_list'] = $this->news_model->get_per_news($id);
				$data['title'] = "Ranade Furniture|News";
				$data['page']='pages/nread_view';
				$this->load->view('templates/content',$data);
			}
		}
		
	//public function pagination()
	//{
		//$this->load->model('news_model');
		//$query=$this->news_model->get_num();
		//$config['base_url']='http://localhost/ranadefurnitures123/index.php/pages/news';
		//$config['total_rows']=$query->num_rows();
		//$config['per_page']=4;
		//$config['num_links']=5;
		
		//$this->pagination->initialize($config);
		
	//}
	//public function news($offset=0)
	//{
		
		//$this->pagination();
		//$this->load->model('news_model');
		//$data['news_list']=$this->news_model->get_news(4,$offset);
		//$data['page'] = 'pages/news_view';
		//$this->load->view('templates/content',$data);
	//}
	}

?>