<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller{
	function __Construct()
	{
		parent::__Construct();
	}
	public function index()
	{
		
		//$this->load->view('pages/view_login');
		
		
		$data['title'] = "Ranade Furniture|Login";
		$data['page']='pages/view_login';
		$this->load->view('templates/content',$data);
	}
	public function regi()
	{
		$this->load->library("form_validation");
		$this->form_validation->set_rules('username','Username','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required');
		if($this->form_validation->run()==false)
		{
			$data['title'] = "Ranade Furniture|Login";
			$data['page']='pages/view_login';
			$this->load->view('templates/content',$data);
	
		
		}
		else
		{
			$user=$this->input->post('username');
			$pwd=$this->input->post('password');
			$this->load->model('model_login');
			$result=$this->model_login->login();
			if($result)
			{
				$newdata=array(
				'username'=>$this->input->post('username'),
				'is_logged_in'=>true
				);
				 $this->session->set_userdata($newdata);
				redirect('home');
			
			}
			else
			{
				$this->session->set_userdata("err","invalid username and password");
				$this->index();
				//echo '<h1>login succesfully</h1>';
				
			}

		}
	}
}
?>