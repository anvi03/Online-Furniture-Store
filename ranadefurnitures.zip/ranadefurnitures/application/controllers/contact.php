<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php

	class Contact extends CI_Controller
	{
		function index()
		{
			$data['title'] = "Ranade Furniture|Contacts";
			$data['page']='pages/contact';
			$this->load->view('templates/content',$data);	
		}
	}

?>