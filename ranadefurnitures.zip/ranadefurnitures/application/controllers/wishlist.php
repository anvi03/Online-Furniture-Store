<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Wishlist extends CI_Controller
	{
		public function index()
		{
			$this->load->model('myaccount_model');
			$data['result']=$this->myaccount_model->get_all_wishlist();	
			if($data['result']==false)
			{
				$data['no_record']="there is no product in your wishlist";	
			}
			$data['title'] = "Ranade Furniture|Wishlist";
			$data['page']='pages/wishlist_view';
			$this->load->view('templates/content',$data);
		}
		
		public function add_to_wishlist($id=NULL)
		{
			if($id=="")
			{
				redirect('home');	
			}
			if(!$this->session->userdata('username'))
			{
				$this->session->set_userdata('err','you must login first to add product in your wishlist');
				redirect('login');	
			}
			$this->load->model('myaccount_model');
			$this->myaccount_model->add_wish($id);
			redirect('wishlist');
		}
		
		public function remove_wish($id=NULL)
		{
			if($id=="")
			{
				redirect('wishlist');	
			}
			$this->load->model('myaccount_model');
			$res=$this->myaccount_model->remove_product_wishlist($id);
			if($res)
			{
				$this->session->set_userdata('succ','product remove from your wishlist');	
			}
			else
			{
				$this->session->set_userdata('err','something went wrong please try again');	
			}
			redirect('wishlist');
		}
		
	}
?>