<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php

	class Gallery extends CI_Controller
	{
		function index()
		{
			$data['title'] = "Ranade Furniture|Products";
			$data['page']='pages/gallery';
			$this->load->view('templates/content',$data);	
		}
	}

?>