<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class Categories extends CI_Controller
{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('categories_model');
		}
		
		public function pagination()
		{
			$this->load->model('categories_model');
			$query=$this->categories_model->get_num();
			$config['base_url']='http://localhost/ranadefurnitures/index.php/categories/index';
			$config['total_rows']=$query->num_rows();
			$config['per_page']=3;
			$config['num_links']=5;
		
		$this->pagination->initialize($config);
			
		}
		public function index($offset=0)
		{
			$this->pagination();
	
			$this->load->model('categories_model');
			$data['title'] = "Ranade Furniture|Product";
			$data['categories']=$this->categories_model->get_categories(3,$offset);
			//$data['page']='pages/gallery';
			//$this->load->view('templates/content',$data);
		}
		public function get_sub_categories($id=NULL)
		{
			if($id == "")
			{
				redirect('product');
			}
			else
			{
				$data['categories'] = $this->categories_model->get_parent_category();
				//echo "<pre>";print_r($data['categories']);die;
				
				foreach($data['categories'] as $val)
				{
					//echo "<pre>";print_r($val);
					
					$child_cat[]=$this->categories_model->get_child_category($val->c_id);
				}
				$data['child_cat'] = $child_cat;
				//echo "<pre>";print_r($data['child_cat']);die;
				$data['categories_data'] = $this->categories_model->view_sub_categories($id);
				
				$data['title'] = "Ranade Furniure|Product";
				$data['page']='pages/sub_categories_view';
				$this->load->view('templates/content',$data);
			}
		}	
	}
?>