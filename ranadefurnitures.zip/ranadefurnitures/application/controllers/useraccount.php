<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Useraccount extends CI_Controller
{
	public function index()
	{
			$data['title'] = "Ranade Furniture|Account";
			$data['page'] = 'pages/account_user';
			$this->load->view('templates/content',$data);
	}
}
?>