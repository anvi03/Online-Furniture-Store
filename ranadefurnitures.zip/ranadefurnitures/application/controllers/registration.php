<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Registration extends CI_Controller{
	function __Construct()
	{
		parent::__Construct();
	}
	public function index()
	{
		
		//$this->load->view('pages/view_login');
		
		
		$data['title'] = "Ranade Furniture|Ragistration";
		$data['page']='pages/view_registration';
		$this->load->view('templates/content',$data);
	}
	public function signin()
	{
		
		$this->load->library('form_validation');
	
		
		
		$this->form_validation->set_rules('username', 'UserName', 'trim|required|min_length[3]|max_length[30]|is_unique[regi.username]');
		$this->form_validation->set_rules('firstname', 'Firstname','trim|required|alpha');
		$this->form_validation->set_rules('lastname', 'Lastname','trim|required|alpha');
		$this->form_validation->set_rules('mobile_no', 'Mobile No','trim|required|min_length[10]|min_length[10]|numeric');
		$this->form_validation->set_rules('email', 'E-mail', 'trim|required|valid_email');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[15]|matches[confirmpassword]');
		$this->form_validation->set_rules('confirmpassword','ConfirmPassword','trim|required');
		
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['title'] = 'Ranade Furniture|Registration';
			$data['page'] = 'pages/view_registration';
			$this->load->view('templates/content',$data);
		}
		else
		{
			$username=$this->input->post('username');
			$firstname=$this->input->post('firstname');
			$lastname=$this->input->post('lastname');
			$email=$this->input->post('email');
			$mobile_no=$this->input->post('mobile_no');
			$password=md5($this->input->post('password'));
			$flag=$this->load->model('model_changepsw');
			$flag=$this->model_changepsw->changepwd($username,$firstname,$lastname,$email,$mobile_no,$password);
			if($flag)
			{
					$this->session->set_userdata('msg',"You are register Successfull, Please Login");
					redirect('login');
					//$data['page']='pages/view_registration';
					//$this->load->view('templates/content',$data);
					
			}
		}
		

		
	}
}
?>