<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Pages extends CI_Controller{
	public function index()
{
 // Capitalize the first letter

	$this->load->view('templates/header');
	$this->load->view('pages/index');
	$this->load->view('templates/footer');

}

	
	//public function index()
	//{
		//$data['page'] = 'pages/index';
		//$this->load->view('templates/content',$data);
	//}
	//public function about()
	//{
		
		//$data['page'] = 'pages/about';
		//$this->load->view('templates/content',$data);
	//}
	
	//public function gallery()
	//{
		
		//$data['page'] = 'pages/gallery';
		//$this->load->view('templates/content',$data);
	//}
	//public function Services()
	//{
		
		//$data['page'] = 'pages/services';
		//$this->load->view('templates/content',$data);
	//}
	//public function contact()
	//{
		
		//$data['page'] = 'pages/contact';
		//$this->load->view('templates/content',$data);
	//}
	
	
	
	
	
}

?>