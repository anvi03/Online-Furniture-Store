<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Nread extends CI_Controller{
	
	public function construct()
	{
		parent::__construct();
		$this->load->model('nread_model');
	}
	public function index()
	{
		
		$this->load->model('nread_model');
		
		$data['title'] = "Ranade Furniture|News";
		$data['page']='pages/nread_view';
		$this->load->view('templates/content',$data);
	}

	public function view()
	{
		//echo"hi";die;
		$this->load->model('nread_model');
		
		$data['news_list']=$this->nread_model->get_rnews();
		$data['title'] = "Ranade Furniture|News";
		$data['page']='pages/nread_view';
		$this->load->view('templates/content',$data);
		
	}

}
?>