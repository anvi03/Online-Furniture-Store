<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class signin extends CI_Controller 
{
	public function __construct()
	{
		
		parent::__construct();
		//$this->load->view('pages/signin');
		$this->load->model('sign_model');
	}
	public function index()
	{
				$data['title'] = "Ranade Furniture|Registration";
				$data['page'] = 'pages/view_login';
				$this->load->view('templates/content',$data);
	}
	
	public function login()
	{
		//$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		
		//$this->form_validation->set_rules('cpass', 'Password Confirmation', 'trim|required|md5');
		//$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required');
		//$this->form_validation->set_rules('mo_no', 'Mobile No', 'trim|required|min_length[10]|max_length[13]|xss_clean');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->session->set_userdata('validation_errors',validation_errors());
			$data['title'] = "Ranade Furniture|Login";
			$data['page'] = 'pages/view_login';
			$this->load->view('templates/content',$data);		}
		else
		{
			
					//'username'=>$this->input->post('username'),
							
					//print_r($data);die;
					$data=$this->sign_model->cheak_login();
					//echo $this->input->post('username');die;
					//print_r($data);die;
					if($data)
					{
							$res['uname']=$this->sign_model->uname($this->input->post('username'),$this->input->post('password'));
							//echo "<pre>";print_r($res['uname']);die;
							$uname = $res['uname']->username;
							$id = $res['uname']->id;
						//echo $id;die;
						//$this->session->set_userdata('succ','You have successfull Register');
						//$username=$data['info'][0]->username;
						//echo $username;die;	
			
						$userdata = array(
						  'username'  => $uname,
						  'logged_in' => TRUE,
						  'id' => $id
						);
						
						$this->session->set_userdata($userdata);
						//echo $this->session->userdata('userdata');die;
						$datacart=$this->sign_model->get_cart($this->session->userdata('id'));
						//print_r($datacart);die;
						foreach($datacart as $datacart){
						$datacartins = array('id'     => $datacart->pid,
											'qty'     => $datacart->qty,
											'price'   => $datacart->price,
											'name'    => $datacart->name,
											'status'  =>$datacart->status,
											'image'     => $datacart->image,
											'to_date'=>$datacart->to_date
											);
        				$this->cart->insert($datacartins);
						}
						$data=$this->sign_model->del_cart($this->session->userdata('id'));
						//print_r($datacart);die;
						//echo "<pre>";print_r($this->cart->contents());die;
						 redirect('useraccount');
						
						
							
							
						  //$data['page'] = 'home';
						  	//$this->load->view('templetes_user/content',$data);
					}
					else
					{
					
						$this->session->set_userdata('errlogin','Invalid UserName or Password');
						$data['title'] = "Ranade Furniture|Login";
						$data['page']='pages/view_login';
						$this->load->view('templates/content',$data);					
					}
		}
	}
	public function update_user()
	{
		
		//$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]|max_length[12]|is_unique[regi.username]');
		$this->form_validation->set_rules('firstname', 'First Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('lastname', 'Last Name', 'trim|required|min_length[3]');
		$this->form_validation->set_rules('email', 'Email', 'trim|valid_email');
		$this->form_validation->set_rules('mobile', 'Mobile No', 'trim|required|min_length[10]|max_length[13]');
		
		
		if ($this->form_validation->run() == FALSE)
		{
			//echo "noooooooooo";die;
			$this->session->set_userdata('validation_errors',validation_errors());
			$this->load->model('sign_model');
		$data['user_data'] = $this->sign_model->display_user();
		$data['title'] = "Ranade Furniture|Setting";
		$data['page'] = 'pages/setting';
		$this->load->view('templates/content',$data);

		}
		else
		{
			//echo "goooooooooooood";die;
			$this->load->model('sign_model');
		
			$data=array('username'=>$this->input->post('username'),
						'firstname'=>$this->input->post('firstname'),
						'lastname'=>$this->input->post('lastname'),
						'email'=>$this->input->post('email'),
						'mobile_no'=>$this->input->post('mobile'),
						);

			$res=$this->sign_model->update_user($data);
			if($res)
			{
				//echo "well GOOOOOOOOOOOOOOOOd";die;
				$this->session->set_userdata('msg','Change Successfully');
				redirect('useraccount');	
			}
		}
		
	}
	
	public function chpwds_view()
	{
		$data['title'] = "Ranade Furniture|Change Password";
		$data['page'] = 'pages/change_pass';
		$this->load->view('templates/content',$data);
		//$this->load->model('regi_model');
		//$res=$this->regi_model->ckh_crnt_pwd();;
	}
	public function chang_ppwd()
	{
		$this->form_validation->set_rules('current_pwd', 'Current Password', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->session->set_userdata('validation_errors',validation_errors());
			$data['title'] = "Ranade Furniture|Change Password";
			$data['page'] = 'pages/change_pass';
			$this->load->view('templates/content',$data);
		}
		else
		{
			$this->load->model('sign_model');
			$chk = $this->sign_model->chkpwd();
			if($chk)
			{
					$this->form_validation->set_rules('new_pwd', 'New Password', 'trim|required|matches[confirm_pwd]');
		$this->form_validation->set_rules('confirm_pwd', 'Confirm Password', 'trim|required');
					if ($this->form_validation->run() == FALSE)
					{
						//echo "hiiii";die;
						redirect('signin/chang_ppwd');
					}
					else
					{
						//echo "byyyyyy";die;
						$this->load->model('sign_model');
						$chk = $this->sign_model->updpwd();
						if($chk)
						{
							$this->session->set_userdata('msg', 'Your Password Is Updated');
							redirect('signin/chpwds_view');
						}
						else
						{
							$this->session->set_userdata('err', 'Your Password Is Not Updated');
							redirect('signin/chpwds_view');
						}
					}
							
			}
			else
			{
				$this->session->set_userdata('err', 'Current Password Not Match!!!');
				redirect('signin/chpwds_view');
			}
		
		
		}
	}
	public function regi()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]|max_length[12]|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|matches[cpassword]');
		$this->form_validation->set_rules('cpassword', 'Password Confirmation', 'trim|required|matches[password]');
		$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|is_unique[register.email]');
		$this->form_validation->set_rules('mo_no', 'Mobile No', 'trim|required|min_length[10]|max_length[13]|xss_clean');
		
		if ($this->form_validation->run() == FALSE)
		{
			redirect('signin');
			/*$this->session->set_userdata('err','');
			$data['page'] = 'register';
			$this->load->view('templetes/content',$data );*/
		}
		else
		{
			$data=array('username'=>$this->input->post('username'),
						'email'=>$this->input->post('email'),
						'mobile_no'=>$this->input->post('mo_no'),
						'password'=>$this->input->post('password'));
			$this->load->model('regi_model');
			$res=$this->regi_model->register($data);
			if($res)
			{
				$this->session->set_userdata('msg','Register Successfully');
				redirect('signin');	
			}
		}
	}
	public function setting()
	{
		$this->load->model('sign_model');
		$data['user_data'] = $this->sign_model->display_user();
		$data['title'] = "Ranade Furniture|Setting";
		$data['page'] = 'pages/setting';
		$this->load->view('templates/content',$data);
	}
	
	public function logout()
	{
		$data=$this->cart->contents();
		//echo "<pre>";print_r($data);die;
		//$id = $this->session->userdata('username');
		$this->load->model('sign_model');
		foreach($data as $data)
		{
			$id=$this->session->userdata('id');
			$din=array(
						'id'=>$this->session->userdata('id'),
						'pid'=>$data['id'],
						'username'=>$this->session->userdata('username'),
						'name'=>$data['name'],
						'qty'=>$data['qty'],
						'price'=>$data['price'],
						
						'image'=>$data['image'],
						'subtotal'=>$data['subtotal'],
						'to_date'=>''
						);
			$d=$this->sign_model->in_cart($din);
						
		}
		$this->cart->destroy();
		//print_r($d);die;
		$this->session->unset_userdata('id');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('logged_in');
		//$this->session->unset_userdata('email');
		redirect('home');	
	}
	
	public function ship()
    { 
 		 $this->load->library('form_validation');
		 $this->form_validation->set_rules('pass', 'Password', 'trim|required');
		
		//$this->form_validation->set_rules('cpass', 'Password Confirmation', 'trim|required|md5');
		$this->form_validation->set_rules('email', 'Email', 'trim|valid_email');
  		if ($this->form_validation->run() == FALSE)
		{
			$this->session->set_userdata('err','');
			$data['page'] = 'signin';
			$this->load->view('templetes/content',$data );
		}
		else
		{
			
					//'username'=>$this->input->post('username'),
								$email=$this->input->post('email');
								//'mobile_no'=>$this->input->post('mo_no'),
								$pass=$this->input->post('pass');
					//print_r($data);die;
					$data=$this->sign_model->cheak_login($email,$pass);
					//print_r($data);die;
					if($data)
					{
							$res['uname']=$this->sign_model->uname($email,$pass);
							$uname=$res['uname']->username;
						//$this->session->set_userdata('succ','You have successfull Register');
						//$username=$data['info'][0]->username;
						//echo $username;die;	
			
						$userdata = array(
						  'username'  => $uname,
						  'logged_in' => TRUE
						
						);
						$this->session->set_userdata($userdata);
						redirect('shiping/step_1');
						  	//$data['page'] = 'shiping';
						  	//$this->load->view('templetes_user/content',$data);
					}
					else
					{
					
						$this->session->set_userdata('errlogin','Invalid Email Id or Password');
						$data['page']='signin';
						$this->load->view('templetes/content',$data);
					}
		}
	}
	
}