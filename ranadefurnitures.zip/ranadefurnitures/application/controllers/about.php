<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php

	class About extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('cms_model');
		}
		
		function index()
		{
		$data['content'] = $this->cms_model->get_content();
		$data['title'] = "Ranade Furniture|About";
		
		$data['page'] = 'pages/about';
		$this->load->view('templates/content',$data);	
		}
	}

?>