<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Product extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('product_model');
			$this->load->model('categories_model');
		}
		public function index()
		{
			
			$this->load->library('pagination');
			$config['base_url']= site_url()."/product/index/";
			$config['total_rows']=$this->categories_model->get_numrows();
			$config['per_page']=9;
			$config['cur_tag_open']='<a class="pagination">';
			$config['cur_tag_close'] = '</a>';
			$this->pagination->initialize($config);
			
			$data['categories'] = $this->categories_model->get_parent_category();
			//echo "<pre>";print_r($data['categories']);die;
			
			foreach($data['categories'] as $val)
			{
				//echo "<pre>";print_r($val);
				
				$child_cat[]=$this->categories_model->get_child_category($val->c_id);
			}
			$data['child_cat'] = $child_cat;
			//$data['product'] = $this->product_model->get_product();
			$data['categories_data'] = $this->categories_model->view_categories($config['per_page'],$this->uri->segment(3));
			$data['link']=$this->pagination->create_links();
			$data['title'] = "Ranade Furniture|Product";
			$data['page']='pages/categories_view';
			$this->load->view('templates/content',$data);
		}
		public function product()
		{
		
					
			$data['title'] = "Ranade Furniture|Product";
			$data['page']='pages/gallery';
			$this->load->view('templates/content',$data);
		}
		public function view_product($id=NULL)
		{
			
			if($id == "")
			{
				redirect('product');
			}
			else
			{
				$this->load->library('pagination');
				$config['base_url']= site_url()."/product/view_product/$id";
				$config['total_rows']=$this->product_model->get_numrows();
				$config['per_page']=9;
				$this->pagination->initialize($config);
				
				
				$data['categories'] = $this->categories_model->get_parent_category();
				//echo "<pre>";print_r($data['categories']);die;
				
				foreach($data['categories'] as $val)
				{
					//echo "<pre>";print_r($val);
					
					$child_cat[]=$this->categories_model->get_child_category($val->c_id);
				}
				$data['child_cat'] = $child_cat;
				//$data['cat'] = $this->categories_model->view_cat($id);
				$data['product'] = $this->product_model->view_product($id,$config['per_page'],$this->uri->segment(4));
				//$data['categories_data'] = $this->categories_model->view_categories();
				$data['link']=$this->pagination->create_links();
				$data['title'] = "Ranade Furniture|Product";
				$data['page']='pages/gallery';
				$this->load->view('templates/content',$data);
			}			
		}
		public function all_categories()
		{
			$data['categories'] = $this->categories_model->get_parent_category();
			//echo "<pre>";print_r($data['categories']);die;
			
			foreach($data['categories'] as $val)
			{
				//echo "<pre>";print_r($val);
				
				$child_cat[]=$this->categories_model->get_child_category($val->c_id);
			}
			$data['child_cat'] = $child_cat;
			//$data['cat'] = $this->categories_model->view_cat($id);
			$data['categories_data'] = $this->categories_model->view_categories();
			
			$data['title'] = "Ranade Furniture|Product";
			$data['page']='pages/gallery';
			$this->load->view('templates/content',$data);
		}
		public function product_view_subcategories($id=NULL)
		{
		
			if($id == "")
			{
				redirect('product');
			}
			else
			{
				$this->load->library('pagination');
				$config['base_url']= site_url()."/product/product_view_subcategories/$id/";
				$config['total_rows']=$this->product_model->get_numrows();
				$config['per_page']=9;
				$this->pagination->initialize($config);
				
				
				$data['categories'] = $this->categories_model->get_parent_category();
				//echo "<pre>";print_r($data['categories']);die;
				
				foreach($data['categories'] as $val)
				{
					//echo "<pre>";print_r($val);
					
					$child_cat[]=$this->categories_model->get_child_category($val->c_id);
				}
				$data['child_cat'] = $child_cat;
				//$data['cat'] = $this->categories_model->view_cat($id);
				$data['prodcut_data'] = $this->product_model->view_product($id,$config['per_page'],$this->uri->segment(4));
				//echo "<pre>";print_r($data['prodcut_data']);die;
				
				$data['link']=$this->pagination->create_links();
				//echo "<pre>";print_r($data['link']);die;
				$data['title'] = "Ranade Furniture|Product";
				$data['page']='pages/product_of_subcategories';
				$this->load->view('templates/content',$data);
			}
		}	
	}
