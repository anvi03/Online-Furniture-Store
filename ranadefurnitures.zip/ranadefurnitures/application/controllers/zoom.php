<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class Zoom extends CI_Controller{
	
	public function construct()
	{
		parent::__construct();
		$this->load->model('zoom_model');
	}
	public function index()
	{
		$data['title'] = 'Ranade Furniture|Products';
		$data['page']='pages/singlei_view';
		$this->load->view('templates/content',$data);
	}

	public function view($id)
	{
		//echo"hi";die;
		$this->load->model('zoom_model');
		$data['product']=$this->zoom_model->get_product($id);
		$data['title'] = 'Ranade Furniture|Products';
		$data['page']='pages/zoom_view';
		$this->load->view('templates/content',$data);
		
	}

}
?>