<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Single extends CI_Controller{
	
	public function __construct()
		{
			parent::__construct();
			$this->load->library('pagination');
			$this->load->library('table');
			
			$this->load->model('single_model');
		}
		public function pagination($id,$offset)
		{
			$this->load->model('single_model');
			$query=$this->single_model->get_num($id,$offset);
			$config['base_url']='http://localhost/ranadefurnitures123/index.php/single/index/'.$id.'/';
			$config['total_rows']=$query->num_rows();
			$config['per_page']=3;
			$config['uri_segment']=4;
			$config['num_links']=5;
			
			$this->pagination->initialize($config);
		
		}
		public function index($id=NULL)
		{
			if($id == "")
			{
				redirect('product');
			}
			else
			{
				$data['product'] = $this->single_model->get_product($id);
				$data['product_images'] = $this->single_model->get_images($id);
				$data['title'] = "RanadaFurniture|product";
				//echo "<pre>";print_r($data['product_images']);die;
				$data['page']='pages/singlei_view';
				$this->load->view('templates/content',$data);
			}	
		}

	

}
?>