<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class Contactus extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('contactus_model');
	}
	/*public function index($page = 'contactus')
	{	
			$data['title'] = ucfirst($page); // Capitalize the first letter
			
			$data['page'] = 'pages/'.$page;
			$this->load->view('templates/content',$data);
	}*/
	
	public function index()
	{
		//$this->load->helper('url');
		//$this->load->helper('form');
		$data['title'] = "Ranade Furniture|Contacts";
		$data['page'] = 'pages/contact';
		$this->load->view('templates/content',$data);
	}
	
	public function add()
	{
		
		//$this->load->library('form_validation');
	
		//$data['title'] = 'contactus';
		
		$this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[6]|max_length[30]');
		$this->form_validation->set_rules('email', 'E-mail', 'trim|required|valid_email');
		$this->form_validation->set_rules('company_name', 'Company Name', 'trim|required');
		$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->session->set_userdata('validation_errors',validation_errors());
			$data['title'] = "Ranade Furniture|Contacts";
			$data['page'] = 'pages/contact';
			$this->load->view('templates/content',$data);
		}
		else
		{
			
			$this->contactus_model->contactus();
			$this->session->set_userdata('msg',"Submited Successfull.");
			redirect('contactus');
		}	
	}
}
?>
