<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php
class Cart extends CI_Controller
{
		public function index()
		{
			if($this->input->post('wishlist'))
			{
				$pro_id=$this->input->post('id');
				redirect('wishlist/add_to_wishlist/'.$pro_id);
			}
			else
			{
				$pro_id=$this->input->post('id');
					//echo $pro_id;die;						
				$pro_name=$this->input->post('name');
				$pro_price=$this->input->post('price'); 
				$qty = $this->input->post('qty');
				//echo $qty;die;
				$img = $this->input->post('image');
				
				//$this->session->set_userdata('img',$img);		
				$pro_stock = $this->input->post('stock');
				//echo $pro_stock;die;
				if($qty>1)
				{
					
					$this->session->set_userdata('err','quantity must be greater then 0');
					redirect('product/view_product/'.$pro_id);
				}
				if($qty>$pro_stock)
				{
					//echo "stock ayaaaaaa";die;
					$this->session->set_userdata('err','quantity must be less then stock');
					redirect('product/view_product/'.$pro_id);
				}
				if($this->cart->contents())
				{
					
					$flg=false;
					$items=	$this->cart->contents();
					foreach($items as $i)
					{
						
						if($i['id']==$pro_id)
						{
							$arr=array(
								'rowid'=>$i['rowid'],
								'qty'=>$i['qty']+$qty,
							);	
							$this->cart->update($arr);
							$flg=true;
						}		
					}
					if($flg==false)
					{
					
						
						$product=array(
										'id'=>$pro_id,
										'qty'=>$qty,
										'price'=>$pro_price,
										'name'=>$pro_name,
										'image'=>$img
										);
					
					$this->cart->insert($product);	
							
					}
					//echo "<pre>";
					////print_r($product);
					//print_r($this->cart->contents());
					//die;	
					//die;
					
				}
				else
				{
					
					$product=array(
					'id'=>$pro_id,
					'qty'=>$qty,
					'price'=>$pro_price,
					'name'=>$pro_name,
					'image'=>$img
					);
					
					$this->cart->insert($product);
					//redirect(	
					//echo "<pre>";
					//print_r($product);
					//print_r($this->cart->contents());
					//die;
				}
				redirect('cart/show_cart');
			}	
			
	
		}
		public function show_cart()
		{
			if(!$this->cart->contents())
			{
				$this->session->set_userdata('message',"your cart is empty");																																																																
			}
			$data['cart']=$this->cart->contents();
			$data['title'] = "Ranade Furniture|Cart";
			//$this->load->view('templates/header_home' );
			//$this->load->view('pages/cart',$data);
			//$this->load->view('templates/footer');
			$data['page']='pages/cart';
			$this->load->view('templates/content',$data);
		}
		public function update()
		{
		
			if($this->input->post('empty'))
			{
				redirect('cart/empty_cart');	
			}
			if($this->input->post('checkout'))
			{
				redirect('cart/checkout');	
			}
			
			
				$cart_update=$this->input->post('qty');
				//echo $cart_update;die;
				$cart_id=$this->input->post('id');
				$items=$this->cart->contents();
				/*echo "<pre>";
				print_r($cart_update);
				echo "update";
				print_r($cart_id);
				echo "cart_id";
				print_r($items);echo "items";die;*/
				$ch=0;
				foreach($items as $i)
				{
						$arr=array(
						'rowid'=>$i['rowid'],
						'id'=>$cart_id[$ch],
						'qty'=>$cart_update[$ch]
						);
						/*echo "<pre>";
						print_r($arr);*/
						$this->cart->update($arr);	
						//echo "updated";
						$ch++;
				}
				redirect('cart/show_cart');
		}
		public function checkout_form()
		{
			$data['title'] = "Ranade Furniture|Billing Info";
			$data['page']='pages/checkout_form_view';
			$this->load->view('templates/content',$data);
		}
		public function checkout()
		{		
				
					if(!$this->session->userdata('username'))
					{
						redirect('signin/login');
					}
					else
					{
						if($this->input->post('change_billing'))
						{
							$data['title'] = "Ranade Furniture|Billing Info";
							$data['page']='pages/checkout_form_view';
							$this->load->view('templates/content',$data);
						}
						else
						{	
							$this->form_validation->set_rules('firstname', 'First Name', 'trim|required');
							$this->form_validation->set_rules('lastname', 'Last Name', 'trim|required');
							
							$this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
							$this->form_validation->set_rules('address1', 'Address', 'trim|required');
							$this->form_validation->set_rules('phone', 'Phone', 'trim|required|max_length[13]|numeric');
							
							$this->form_validation->set_rules('pin_code', 'Pin Code', 'trim|required');
							if($this->form_validation->run()==false)
							{
						
								$data['title'] = "Ranade Furniture|Billing Info";
								$data['page']='pages/checkout_form_view';
								$this->load->view('templates/content',$data);
							}
							else
							{
								$bill=array(
								'fisrtname'=>$this->input->post('firstname'),
								'lastname'=>$this->input->post('lastname'),
								'email'=>$this->input->post('email'),
								'phone'=>$this->input->post('phone'),
								'address1'=>$this->input->post('address1'),
								'address2'=>$this->input->post('address2'),
								'pin_code'=>$this->input->post('pin_code'),
								'shipping_method'=>$this->input->post('exprship')
								);
								$this->session->set_userdata('bill',$bill);
								//echo "<pre>";
								//print_r($bill);die;
								if($this->input->post('chk'))
								{
									$ship=array(
													'fisrtname'=>$this->input->post('firstname'),
													'lastname'=>$this->input->post('lastname'),
													'email'=>$this->input->post('email'),
													'phone'=>$this->input->post('phone'),
													'address1'=>$this->input->post('address1'),
													'address2'=>$this->input->post('address2'),
													'pin_code'=>$this->input->post('pin_code')
												);
									$this->session->set_userdata('ship',$ship);
									/*echo "<pre>";
									print_r($this->session->userdata('ship'));
									die;*/	
									redirect('cart/place_order');
								}
								else
								{
									
									redirect('cart/shipping');
								}
								
								
							}
						}
					}		
			
			
			
		}
		public function shipping()
		{
				
				
				
					if($this->input->post('change_shipping'))
					{
						$data['title'] = "Ranade Furniture|Shipping Info";
						$data['page']='pages/checkout_shipping_form';
						$this->load->view('templates/content',$data);
					}
					else
					{
						$this->form_validation->set_rules('firstname', 'First Name', 'trim|required');
						$this->form_validation->set_rules('lastname', 'Last Name', 'trim|required');
						
						$this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
						$this->form_validation->set_rules('address1', 'Address', 'trim|required');
						$this->form_validation->set_rules('phone', 'Phone', 'trim|required|max_length[13]|numeric');
						
						$this->form_validation->set_rules('pin_code', 'Pin Code', 'trim|required');
						if($this->form_validation->run() == FALSE)
						{
					
							$data['title'] = "Ranade Furniture|Shipping Info";
							$data['page']='pages/checkout_shipping_form';
							$this->load->view('templates/content',$data);
						}
						else
						{
							$ship=array(
							'fisrtname'=>$this->input->post('firstname'),
							'lastname'=>$this->input->post('lastname'),
							'email'=>$this->input->post('email'),
							'phone'=>$this->input->post('phone'),
							'address1'=>$this->input->post('address1'),
							'address2'=>$this->input->post('address2'),
							'pin_code'=>$this->input->post('pin_code')
							);
							$this->session->set_userdata('ship',$ship);
							//echo "<pre>";
							//print_r($ship);die;
							redirect('cart/place_order');
							
						}
					}
					
						
		}
		public function place_order()
		{
			if(!$this->session->userdata('bill'))
			{
				
				redirect('cart/checkout');
			}
			else
			{
				if($this->input->post('change_billing'))
				{
					$data['title'] = "Ranade Furniture|Billing Info";
					$data['page']='pages/checkout_form_view';
					$this->load->view('templates/content',$data);
				}
				else
				{
					$data['title'] = "Ranade Furniture|Bill";
					$data['page']='pages/checkout_process';
					$this->load->view('templates/content',$data);
				}	
			}	
		}
		public function remove($id=NULL)
		{
			if($id=="")
			{
				redirect('home');	
			}
			$items=$this->cart->contents();
			foreach($items as $i)
			{
				if($i['id']==$id)
				{
					$arr=array(
					'rowid'=>$i['rowid'],
					'qty'=>0
					);
					$this->cart->update($arr);
					redirect('cart/show_cart');
				}	
			}
		}
		public function empty_cart()
		{
			$this->cart->destroy();	
			redirect('cart/show_cart');
		}
		
		
		
		public function order()
		{
			$this->load->model('order_model');
			$bill=$this->session->userdata('bill');
			$ship=$this->session->userdata('ship');
			//echo "<pre>";
			//print_r($bill);
			//print_r($ship);die;
			foreach($ship as $c)
			{
				$arr[]=$c;	
			}
			foreach($bill as $b)
			{
				$arr[]=$b;	
			}
			if($arr[14] == 1)
			{
				$total = $this->cart->total();	
				$cc = $total*5/100;
			}
			else
			{
				$cc = $arr[14];
			}
			
			//print_r($arr);
			$order_no=random_string('numeric');
			$this->session->set_userdata('order_no',$order_no);
			$result = $this->order_model->get_cust_id($this->session->userdata('username'));
			$cust_id = $result->id;
			
			//$date=date('Y-m-d');
			//echo $date;
			$detail=array(
			'order_no'=>$order_no,
			
			'customer_id'=>$cust_id,
			'shipped_on'=>'',
			'total'=>$this->cart->total(),
			'ship_firstname'=>$arr[0],
			'ship_lastname'=>$arr[1],
			'ship_email'=>$arr[2],
			'ship_phone'=>$arr[3],
			'ship_address1'=>$arr[4],
			'ship_city'=>'',
			'bill_firstname'=>$arr[7],
			'bill_lastname'=>$arr[8],
			'bill_email'=>$arr[9],
			'bill_phone'=>$arr[10],
			'bill_address1'=>$arr[11],
			'shipping_method'=>$cc
			);
			//echo "<pre>";print_r($detail);die;
			$this->order_model->inert_detail($detail);
			
			//print_r($detail);
			$cart=$this->cart->contents();
			//echo "<pre>";print_r($cart);die;
			$cnt=0;
			foreach($cart as $rec)
			{
				$ar['order_id']=$order_no;
				$ar['product_id']=$rec['id'];
				$ar['quantity']=$rec['qty'];
				//echo "<pre>";print_r($ar);die;
				$res=$this->order_model->insert_product($ar);
				
				
			}
			
						
			
			$this->load->model('pages_model');
			foreach($cart as $c)
			{
				
				$id=$c['id']=$c['id'];
				
				$result=$this->pages_model->get_stock($id);
				
				//echo "<pre>";print_r($result);die;
				
				$qty=$result[0]['p_qty'];
					
				$qty-=$c['qty'];
				$this->pages_model->update_stock($id,$qty);
				
			}
			
				
			redirect('cart/billing');
			//print_r($ar);
		} 
		public function billing()
		{
			
			$order_no = $this->session->userdata('order_no');
			$this->load->model('order_model');
			$data['order'] = $this->order_model->order_details($order_no);
			//echo "<pre>";print_r($data['order']);die;
			foreach($data['order'] as $val)
			{
				 $order = $val->order_no;
				 $res[] = $this->order_model->get_order_no($order); 
			}
			//echo "<pre>";print_r($res);die;
			$data['qty'] = $res;
			$i= 0 ;
			//echo "<pre>";
			//print_r($data['qty']);
			//echo $data['qty'][0][1]['quantity'];
			$ch = 0;
			foreach($data['qty'] as $q)
			{
				foreach($q as $qt)
				{
					$arr[] = $q[$ch]['quantity'];
					$ch++;
				}
			}
			$data['arr'] = $arr;
			
			foreach($data['qty'] as $value)
			{
				foreach($value as $v)
				{
					//echo "<pre>";print_r($v);
					$id_product = $v['product_id'];
					//echo $id_product;
					$productlst[] = $this->order_model->get_product($id_product);
				//echo "<pre>";print_r($productlst);
				
					//$i++;
				}
			}
			//echo "<pre>";
			$cart=$this->cart->contents();
			foreach($cart as $c)
			{
				$arr1[]=$c['subtotal'];
			}
			$data['total']=$arr1;
			//print_r($arr1);
			//echo "<pre>";print_r($arr1);die;
			$data['product_lst'] = $productlst;
			$data['title']  = "Ranade Furniture|Bill"; 
			$data['page']='pages/billing_view';
			$this->load->view('templates/content',$data);
			$this->session->unset_userdata('bill');
			$this->session->unset_userdata('ship');	
			$this->cart->destroy();
		}
}
?>