<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Services extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->model('services_model');
		}
		
		function index()
		{
			$data['content'] = $this->services_model->get_content();
			$data['title'] = "Ranade Furniture|Services";
		//print_r($data['content']);die;
		$data['page'] = 'pages/services';
		$this->load->view('templates/content',$data);	
		}
	}

?>