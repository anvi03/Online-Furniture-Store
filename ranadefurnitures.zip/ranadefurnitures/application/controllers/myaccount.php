<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Myaccount extends CI_Controller{
	
	/*public function view($page = 'home')
	{
		$this->load->helper('url');
		if ( ! file_exists(APPPATH.'/views/pages/'.$page.'.php'))
		{
			echo " Whoops, we don't have a page for that!";
			show_404();
		}
	
		$data['title'] = ucfirst($page); // Capitalize the first letter
		$data['page'] = 'pages/'.$page;
		$this->load->view('templates/content',$data);
	}*/
	public function account_view()
	{
		
		$this->load->model('order_model');
		$data['product']=$this->order_model->get_order();
		$data['prod_detail']=$this->order_model->get_order_details();
		$data['title']='Ranade Furniture|Account';
		$this->load->model('myaccount_model');
		$data['user_data']=$this->myaccount_model->get_details();
		//$data['page'] = 'pages/myaccount_wel';
		$this->load->view('templates/header',$data);
		$this->load->view('pages/my_account',$data);
		$this->load->view('templates/footer');
	}
	public function view_cust_order($order=NULL)
	{
	
		if($order=="")
		{
			redirect('myaccount/account_view');	
		}	
		$this->load->model('order_model');
		$order=$this->order_model->get_cust_order($order);
		foreach($order as $d)
		{
			$p[]=$d['product_id'];	
			$q[]=$d['quantity'];
		}
		/*echo "<pre>";
		print_r($p);
		print_r($q);*/
		$data['qty']=$q;
		$this->load->model('pages_model');
		$data['result']=$this->pages_model->get_ordered_product($p);
		$this->load->view('templates/header');
		$this->load->view('pages/view_cust_order',$data);
		$this->load->view('templates/footer');
	}
	public function change_pwd()
	{
		$data['title']='Ranade Furniture|Change Password';
		$this->load->model('myaccount_model');
		//$data['user_data']=$this->myaccount_model->get_details();
		//$data['page'] = 'pages/change_pwd';
		$this->load->view('templates/header');
		$this->load->view('pages/change_password');
		$this->load->view('templates/footer');
			
	}
	public function chkpwd()
	{
		
		$this->load->model('myaccount_model');
		$number=$this->myaccount_model->checkoldpwd();
		
		if($number == "1")
		{
			$this->load->library("form_validation");
			$this->form_validation->set_rules('old_password','old Password','trim|required|min_length[5]|max_length[12]');
			$this->form_validation->set_rules('new_password','old Password','trim|required|min_length[5]|max_length[12]');
		    $this->form_validation->set_rules('confirm_password','Confirm New Password','trim|required|matches[NewPassword]|min_length[6]|max_length[12]');
			
			if($this->form_validation->run() == TRUE)
			{
				$this->myaccount_model->update_password();
				//redirect('dashboard');
				$this->session->set_userdata('succ','Password updated successfully');
				redirect('myaccount/change_pwd');
			}
			else
			{
				$this->session->set_userdata('validation_errors',validation_errors());
				redirect('myaccount/change_pwd');
			}
		}
		else
		{
			$this->session->set_userdata('errr',"Invalid data....!");
			redirect('myaccount/change_pwd');
		}
	}
	public function subscription()
	{
		//echo "subscription";
		//die;
		//$data['title']='Subscribe';
		$this->load->model('myaccount_model');
		$data['user_data']=$this->myaccount_model->get_regi_details();
		$data['status']=$data['user_data'][0]['subscription'];
		/*echo "<pre>";
		print_r($data['status']);
		die;*/
		//$data['page'] = 'pages/subscribe';
		$this->load->view('templates/header');
		$this->load->view('pages/subscription',$data);
		$this->load->view('templates/footer');
	}
	public function subscribe_me()
	{
		if($this->input->post('sbtn'))
		{
			$uname=$this->session->userdata('username');
			$this->load->model('myaccount_model');
			$flag=$this->myaccount_model->subscribe($uname);
			if($flag)
			{
				$this->session->set_userdata('succ',"Thank you for Subscription....!");
				redirect('myaccount/account_view');
			}	
		}
		else
		{
			
			$uname=$this->session->userdata('username');
			$this->load->model('myaccount_model');
			$flag=$this->myaccount_model->unsubscribe($uname);
			if($flag)
			{
				$this->session->set_userdata('succ',"Successfully Unsubscribed....!");
				redirect('myaccount/account_view');
			}		
		}
	}
	public function get_users_wishlist()
	{
		$this->load->model('myaccount_model');
		$data['result']=$this->myaccount_model->get_all_wishlist();	
		if($data['result']==false)
		{
			$data['no_record']="there is no product in your wishlist";	
		}
		$data['title'] = "Ranade Furniture|Wishlist";
		$this->load->view('templates/header');
		$this->load->view('pages/wishlist',$data);
		$this->load->view('templates/footer');
	}
	public function remove_wish($id=NULL)
	{
		if($id=="")
		{
			redirect('myaccount/get_users_wishlist');	
		}
		$this->load->model('myaccount_model');
		$res=$this->myaccount_model->remove_product_wishlist($id);
		if($res)
		{
			$this->session->set_userdata('succ','product remove from your wishlist');	
		}
		else
		{
			$this->session->set_userdata('err','something went wrong please try again');	
		}
		redirect('myaccount/get_users_wishlist');
	}
	  
	
	public function add_to_wishlist($id=NULL)
	{
		if($id=="")
		{
			redirect('home');	
		}
		if(!$this->session->userdata('username'))
		{
			$this->session->set_userdata('err','you must login first to add product in your wishlist');
			redirect('login');	
		}
		$this->load->model('myaccount_model');
		$this->myaccount_model->add_wish($id);
		redirect('preview/get_product/'.$id);
	}
	public function my_whish()
	{
		$this->load->model('myaccount_model');
		$uname=$this->session->userdata('username');
		$data['arr_obj']=$this->myaccount_model->my_whishes($uname);
		$i=0;
		foreach($data['arr_obj'] as $d)
		{
			$ar[$i]= $d['product_id'];
			$i++;
		}
		$this->load->model('category_model');
		$data['whishlist']=$this->category_model->get_whishlist_products($ar);
		$data['title']='Ranade Furniture|Whishlist';
		$data['page'] = 'pages/myaccount_whishlist';
		$this->load->view('templates/content',$data);

	}
	
	
	public function accountdata()
	{
		
		//$data['title']='My Account';
		$this->load->model('myaccount_model');
		$data['user_data']=$this->myaccount_model->get_details();
		//$data['page'] = 'pages/myaccount';
		$this->load->view('templates/header');
		$this->load->view('pages/user_profile',$data);
		$this->load->view('templates/footer');
	}
	public function update_user()
	{
		
		$this->load->library("form_validation");
	 	$this->form_validation->set_rules('f_name','first name','trim|required');
	  	$this->form_validation->set_rules('l_name','last Name','trim|required');
		$this->form_validation->set_rules('mobile_no','mobile no','trim|required|numeric');
		
		$this->form_validation->set_rules('email','email','trim|required|valid_email');
	 	$this->form_validation->set_rules('address','address','trim|required|min_length[4]|max_length[15]');
		if ($this->form_validation->run()== FALSE)
	 	{		
			$this->session->set_userdata('validation_errors',validation_errors());
			//echo "hi"; die;
			$this->load->model('myaccount_model');
			$data['user_data']=$this->myaccount_model->get_details();
			//$data['page'] = 'pages/my_account';
		$this->load->view('templates/header');
		$this->load->view('pages/user_profile',$data);
		$this->load->view('templates/footer');
		//redirect ('myaccount/account_view');
		}
		else
		{
			$this->load->model('myaccount_model');
			$result=$this->myaccount_model->update_user();
			if($result)
			{
				$this->session->set_userdata('succ','Your profile updated successfully');
				redirect('myaccount/account_view');	
			}
			//redirect('myaccount/accountdata');
		}
		
	}
	
	
	public function category_list()
	{
		
		$data['title']='Jewellery';
		$this->load->model('category_model');
		$data['datacategory']=$this->category_model->get_parent_category();
		foreach($data['datacategory'] as $value)
		{
			$child_cat[]=$this->category_model->get_child_category($value['cat_id']);
		}
		$data['child_cat']=$child_cat;
		$data['dataproduct']=$this->category_model->get_allproduct();
		//$this->load->view('news_view',$result);
		$data['page'] = 'pages/shop';
		$this->load->view('templates/content',$data);
		
	}
	public function single($id)
	{
		//echo $id;die;
		$this->load->model('category_model');
		$data['datapro']=$this->category_model->get_product($id);
		$data['dataproduct']=$this->category_model->single_view($id);
		$data['dataimg']=$this->category_model->single_view_img($id);
		$data['title']='Jewellery';
		$data['page'] = 'pages/single';
		$this->load->view('templates/content',$data);
	}
	public function product_view($id)
	{
		$this->load->model('category_model');
		$data['datacategory']=$this->category_model->get_parent_category();
		foreach($data['datacategory'] as $value)
		{
			$child_cat[]=$this->category_model->get_child_category($value['cat_id']);
		}
		$data['child_cat']=$child_cat;
		//$data['datapro']=$this->category_model->get_product($id);
		$data['dataproduct']=$this->category_model->single_view($id);
	//	$data['dataproduct']=$this->category_model->single_product_view($id);
		//$data['dataproduct']=$this->category_model->get_id_product($id);
		//$data['dataimg']=$this->category_model->single_view_img($id);
		$data['title']='Jewellery';
		//$data['page'] = 'pages/single';
		//$this->load->view('templates/content',$data);
		$data['page'] = 'pages/shop';
		$this->load->view('templates/content',$data);
	}
}
?>